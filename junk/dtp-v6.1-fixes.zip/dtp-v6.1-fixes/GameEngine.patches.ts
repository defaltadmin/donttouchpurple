// engine/GameEngine.patches.ts
// OPENCODE PATCH FILE — apply all str_replace blocks in order.
// Each patch shows FILE, exact FIND text, exact REPLACE WITH text.

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 1 — Add SessionPersistor import
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
import {
  getNextBossEventType, getBossDuration, getBossLabel, getBossDoneLabel,
  getNextBossTriggerScore, shouldTriggerBossEvent, shouldTriggerShieldBoss,
} from "./subsystems/EventOrchestrator";

REPLACE WITH:
import {
  getNextBossEventType, getBossDuration, getBossLabel, getBossDoneLabel,
  getNextBossTriggerScore, shouldTriggerBossEvent, shouldTriggerShieldBoss,
} from "./subsystems/EventOrchestrator";
import { SessionPersistor } from "./subsystems/SessionPersistor";
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 2 — Add _rngCallCount private field
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
  private dda = new DynamicDifficulty(1200);
  private daily = new DailyChallenge();

REPLACE WITH:
  private dda = new DynamicDifficulty(1200);
  private daily = new DailyChallenge();
  private _rngCallCount = 0;
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 3 — Wrap rng to count calls in start()
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
    this.gameSeed   = forceSeed ?? seedManager.initOrRestore();
    this.rng        = mulberry32(this.gameSeed);

REPLACE WITH:
    this.gameSeed      = forceSeed ?? seedManager.initOrRestore();
    this._rngCallCount = 0;
    const _rawRng      = mulberry32(this.gameSeed);
    this.rng           = () => { this._rngCallCount++; return _rawRng(); };
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 4 — Fix restoreSessionSnapshot: fast-forward PRNG to snapshot state
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
      this.gameSeed = data.gameSeed as number;
      this.rng = mulberry32(this.gameSeed);

REPLACE WITH:
      this.gameSeed = data.gameSeed as number;
      {
        const _rawRng    = mulberry32(this.gameSeed);
        const savedCalls = (data.rngCallCount as number) ?? 0;
        for (let i = 0; i < savedCalls; i++) _rawRng();
        this._rngCallCount = savedCalls;
        this.rng = () => { this._rngCallCount++; return _rawRng(); };
      }
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 5 — Add rngCallCount to getSessionSnapshot()
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
      ddaSpawnRate: this.dda.spawnRate,

REPLACE WITH:
      ddaSpawnRate: this.dda.spawnRate,
      rngCallCount: this._rngCallCount,
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 6 — Replace autoSaveSession body with SessionPersistor
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
  private autoSaveSession(): void {
    if (this.phase !== "playing" || this.paused) return;
    try {
      sessionStorage.setItem(this.SESSION_KEY, JSON.stringify(this.getSessionSnapshot()));
    } catch {}
  }

REPLACE WITH:
  private autoSaveSession(): void {
    SessionPersistor.save({ ...this.getSessionSnapshot(), phase: this.phase });
  }
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 7 — Replace both sessionStorage.removeItem(this.SESSION_KEY) calls
// FILE: engine/GameEngine.ts (two occurrences: start() and safeReset())
// Apply str_replace to EACH occurrence separately.
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND (each occurrence):
    sessionStorage.removeItem(this.SESSION_KEY);

REPLACE WITH:
    SessionPersistor.clear();
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 8 — submitScoreToLeaderboard: pass tickCount
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
  submitScoreToLeaderboard(score: number): void {
    scoreSync.queue(score);
  }

REPLACE WITH:
  submitScoreToLeaderboard(score: number): void {
    scoreSync.queue(score, this.tickCount);
  }
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 9a — DDA shield fix: cell-expiry miss path
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
        if (isMiss) {
          this.dda.recordAttempt(false, 0, true);
          const dmg = mode === "evolve" ? 0.5 : 1;
          if (!this.devGodMode) {
            if (ref.shieldCount > 0) { ref.shieldCount -= 1; ref.shield = ref.shieldCount > 0; }
            else {
              ref.health = Math.max(0, ref.health - dmg); ref.shield = false;

REPLACE WITH:
        if (isMiss) {
          const dmg = mode === "evolve" ? 0.5 : 1;
          if (!this.devGodMode) {
            if (ref.shieldCount > 0) {
              ref.shieldCount -= 1; ref.shield = ref.shieldCount > 0;
              this.dda.recordAttempt(false, 0, false);
            } else {
              this.dda.recordAttempt(false, 0, true);
              ref.health = Math.max(0, ref.health - dmg); ref.shield = false;
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 9b — DDA shield fix: tap-danger path
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
      if (tappedIsDanger) {
        cell.clicked = true;
        this.dda.recordAttempt(false, 0, true);
        if (!this.devGodMode) {
          if (ref.shieldCount > 0) { ref.shieldCount -= 1; ref.shield = ref.shieldCount > 0; this.emit({ type: "sound", name: "ok" }); this.triggerCellAnim(player, idx, "pop"); }
          else {

REPLACE WITH:
      if (tappedIsDanger) {
        cell.clicked = true;
        if (!this.devGodMode) {
          if (ref.shieldCount > 0) {
            ref.shieldCount -= 1; ref.shield = ref.shieldCount > 0;
            this.dda.recordAttempt(false, 0, false);
            this.emit({ type: "sound", name: "ok" }); this.triggerCellAnim(player, idx, "pop");
          } else {
            this.dda.recordAttempt(false, 0, true);
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 10 — Kick off daily.init() in constructor
// FILE: engine/GameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
    audioEngine.init();
    import('../utils/settings').then(m => {

REPLACE WITH:
    audioEngine.init();
    this.daily.init().catch(e => logError('DailyChallenge.init failed', e));
    import('../utils/settings').then(m => {
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 11 — Fix hardcoded session key in restoreSession
// FILE: hooks/useGameEngine.ts
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
    const raw = sessionStorage.getItem('dtp:session');
    if (!raw || !engineRef.current) return false;
    try {
      const { engineSnapshot } = JSON.parse(raw);

REPLACE WITH:
    const raw = sessionStorage.getItem('dtp:session-ui');
    if (!raw || !engineRef.current) return false;
    try {
      const { engineSnapshot } = JSON.parse(raw);
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 12 — Fix App.tsx challenge URL detection (async parseAndVerify)
// FILE: App.tsx
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
    const { isChallenge, seed } = challengeLink.parse();
    if (isChallenge && seed) {
      logger.info('Challenge link loaded', { seed });
    }

REPLACE WITH:
    challengeLink.parseAndVerify().then(({ isChallenge, valid, seed }) => {
      if (isChallenge && seed) {
        if (!valid) logger.warn('Challenge link signature invalid — score claim untrusted');
        logger.info('Challenge link loaded', { seed, valid });
      }
    });
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 13 — Fix handleCopyChallenge (remove dead generateChallengeUrl call)
// FILE: App.tsx
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
  const handleCopyChallenge = useCallback(async () => {
    const url = generateChallengeUrl();
    if (!url) return;
    const ok = await challengeLink.copyToClipboard(snapshot?.p1.score ?? 0, String(snapshot?.gameSeed ?? 0), snapshot?.p1.health ?? 3);
    setShareToast(true);
    setTimeout(() => setShareToast(false), 2000);
  }, [generateChallengeUrl, snapshot]);

REPLACE WITH:
  const handleCopyChallenge = useCallback(async () => {
    if (!snapshot) return;
    const ok = await challengeLink.copyToClipboard(
      snapshot.p1.score,
      String(snapshot.gameSeed),
      snapshot.p1.health,
    );
    if (ok) {
      setShareToast(true);
      setTimeout(() => setShareToast(false), 2000);
    }
  }, [snapshot]);
*/

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 14 — Resume detection in App.tsx: read from correct key
// FILE: App.tsx
// ═══════════════════════════════════════════════════════════════════════════
// NOTE: The resume detection at line ~894 reads 'dtp:session' directly
// via sessionStorage.getItem('dtp:session') and checks for gameSeed.
// This is the FULL snapshot key written by autoSaveSession — this is CORRECT.
// No change needed here. The collision fix (session.ts -> 'dtp:session-ui')
// means sessionManager.save() no longer overwrites the full snapshot.
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// PATCH 15 — Workers: make tick + sessionId required
// FILE: workers/score-validator.js
// ═══════════════════════════════════════════════════════════════════════════
/*
FIND:
      if (data.tick && data.score > data.tick * 15 + 300) {
        return new Response(JSON.stringify({ error: "Impossible score" }), { status: 400 });
      }

REPLACE WITH:
      if (typeof data.tick !== "number" || data.tick < 0) {
        return new Response(JSON.stringify({ error: "Missing tick" }), { status: 400 });
      }
      if (data.score > data.tick * 15 + 300) {
        return new Response(JSON.stringify({ error: "Impossible score" }), { status: 400 });
      }
      if (typeof data.sessionId !== "string" || data.sessionId.length < 8) {
        return new Response(JSON.stringify({ error: "Missing session" }), { status: 400 });
      }
*/

// Also add to payload.fields in the Firebase write:
/*
FIND:
          mode: { stringValue: data.mode },

REPLACE WITH:
          mode: { stringValue: data.mode },
          sessionId: { stringValue: data.sessionId },
*/
