export function logError(...args: Parameters<typeof console.error>) {
  if (import.meta.env.DEV) {
    console.error(...args);
  }
}
