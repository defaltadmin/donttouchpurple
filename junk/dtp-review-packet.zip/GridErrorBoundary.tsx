import React, { Component, ReactNode } from 'react';

interface Props { children: ReactNode; }
interface State { hasError: boolean; }

export class GridErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[DTP] Grid render error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ color: 'var(--muted)', textAlign: 'center', padding: 20, fontSize: 14, fontFamily: 'var(--font-ui)' }}>
          🛟 Grid display error<br />Please click the pause button or restart the game.
        </div>
      );
    }
    return this.props.children;
  }
}
