import { useEffect, useRef, useCallback } from 'react';
import { useBackgroundController } from '../../hooks/useBackground';

const COLORS = ['#c026d3','#a21caf','#7c3aed','#9333ea','#3b82f6','#db2777'];
const CELL = 14; const GAP = 3;

interface Column { x:number; cells:{y:number; color:string; opacity:number}[]; speed:number; }

export default function DataStream() {
  const ref = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const drawRef = useRef<(() => void) | null>(null);
  const { register } = useBackgroundController(true);

  const pause = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = 0;
    }
  }, []);

  const resume = useCallback(() => {
    if (!rafRef.current && drawRef.current) {
      rafRef.current = requestAnimationFrame(drawRef.current);
    }
  }, []);

  useEffect(() => {
    const unregister = register({ pause, resume });
    return unregister;
  }, [register, pause, resume]);

  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d')!;
    const cols: Column[] = [];
    const buildCols = () => {
      cols.length = 0;
      for (let x=0; x<c.width; x+=CELL+GAP) {
        const len = 3+Math.floor(Math.random()*6);
        cols.push({
          x,
          cells: Array.from({length:len},(_,i)=>({
            y: -i*(CELL+GAP)-Math.random()*c.height,
            color: COLORS[Math.floor(Math.random()*COLORS.length)],
            opacity: (len-i)/len,
          })),
          speed: 1+Math.random()*1.5,
        });
      }
    };
    const resize = () => { c.width=window.innerWidth; c.height=window.innerHeight; buildCols(); };
    resize(); window.addEventListener('resize',resize);

    const draw = () => {
      ctx.clearRect(0,0,c.width,c.height);
      for (const col of cols) {
        for (const cell of col.cells) {
          cell.y += col.speed;
          if (cell.y > c.height+CELL) cell.y = -CELL - Math.random()*c.height*0.5;
          ctx.globalAlpha = cell.opacity * 0.5;
          ctx.fillStyle = cell.color;
          ctx.fillRect(col.x, cell.y, CELL, CELL);
        }
      }
      ctx.globalAlpha=1; rafRef.current=requestAnimationFrame(draw);
    };
    drawRef.current = draw;
    draw();
    return () => { cancelAnimationFrame(rafRef.current); window.removeEventListener('resize',resize); };
  }, []);
  return <canvas ref={ref} className="background-canvas" style={{opacity:0.45}} />;
}
