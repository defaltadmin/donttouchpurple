(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))r(s);new MutationObserver(s=>{for(const i of s)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&r(o)}).observe(document,{childList:!0,subtree:!0});function n(s){const i={};return s.integrity&&(i.integrity=s.integrity),s.referrerPolicy&&(i.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?i.credentials="include":s.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(s){if(s.ep)return;s.ep=!0;const i=n(s);fetch(s.href,i)}})();function f_(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var Xg={exports:{}},Au={},Jg={exports:{}},ae={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var xa=Symbol.for("react.element"),p_=Symbol.for("react.portal"),m_=Symbol.for("react.fragment"),g_=Symbol.for("react.strict_mode"),y_=Symbol.for("react.profiler"),v_=Symbol.for("react.provider"),__=Symbol.for("react.context"),w_=Symbol.for("react.forward_ref"),x_=Symbol.for("react.suspense"),E_=Symbol.for("react.memo"),T_=Symbol.for("react.lazy"),_p=Symbol.iterator;function b_(t){return t===null||typeof t!="object"?null:(t=_p&&t[_p]||t["@@iterator"],typeof t=="function"?t:null)}var Zg={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},e0=Object.assign,t0={};function Fi(t,e,n){this.props=t,this.context=e,this.refs=t0,this.updater=n||Zg}Fi.prototype.isReactComponent={};Fi.prototype.setState=function(t,e){if(typeof t!="object"&&typeof t!="function"&&t!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,t,e,"setState")};Fi.prototype.forceUpdate=function(t){this.updater.enqueueForceUpdate(this,t,"forceUpdate")};function n0(){}n0.prototype=Fi.prototype;function wh(t,e,n){this.props=t,this.context=e,this.refs=t0,this.updater=n||Zg}var xh=wh.prototype=new n0;xh.constructor=wh;e0(xh,Fi.prototype);xh.isPureReactComponent=!0;var wp=Array.isArray,r0=Object.prototype.hasOwnProperty,Eh={current:null},s0={key:!0,ref:!0,__self:!0,__source:!0};function i0(t,e,n){var r,s={},i=null,o=null;if(e!=null)for(r in e.ref!==void 0&&(o=e.ref),e.key!==void 0&&(i=""+e.key),e)r0.call(e,r)&&!s0.hasOwnProperty(r)&&(s[r]=e[r]);var l=arguments.length-2;if(l===1)s.children=n;else if(1<l){for(var u=Array(l),d=0;d<l;d++)u[d]=arguments[d+2];s.children=u}if(t&&t.defaultProps)for(r in l=t.defaultProps,l)s[r]===void 0&&(s[r]=l[r]);return{$$typeof:xa,type:t,key:i,ref:o,props:s,_owner:Eh.current}}function S_(t,e){return{$$typeof:xa,type:t.type,key:e,ref:t.ref,props:t.props,_owner:t._owner}}function Th(t){return typeof t=="object"&&t!==null&&t.$$typeof===xa}function k_(t){var e={"=":"=0",":":"=2"};return"$"+t.replace(/[=:]/g,function(n){return e[n]})}var xp=/\/+/g;function yc(t,e){return typeof t=="object"&&t!==null&&t.key!=null?k_(""+t.key):e.toString(36)}function xl(t,e,n,r,s){var i=typeof t;(i==="undefined"||i==="boolean")&&(t=null);var o=!1;if(t===null)o=!0;else switch(i){case"string":case"number":o=!0;break;case"object":switch(t.$$typeof){case xa:case p_:o=!0}}if(o)return o=t,s=s(o),t=r===""?"."+yc(o,0):r,wp(s)?(n="",t!=null&&(n=t.replace(xp,"$&/")+"/"),xl(s,e,n,"",function(d){return d})):s!=null&&(Th(s)&&(s=S_(s,n+(!s.key||o&&o.key===s.key?"":(""+s.key).replace(xp,"$&/")+"/")+t)),e.push(s)),1;if(o=0,r=r===""?".":r+":",wp(t))for(var l=0;l<t.length;l++){i=t[l];var u=r+yc(i,l);o+=xl(i,e,n,u,s)}else if(u=b_(t),typeof u=="function")for(t=u.call(t),l=0;!(i=t.next()).done;)i=i.value,u=r+yc(i,l++),o+=xl(i,e,n,u,s);else if(i==="object")throw e=String(t),Error("Objects are not valid as a React child (found: "+(e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)+"). If you meant to render a collection of children, use an array instead.");return o}function Qa(t,e,n){if(t==null)return t;var r=[],s=0;return xl(t,r,"","",function(i){return e.call(n,i,s++)}),r}function I_(t){if(t._status===-1){var e=t._result;e=e(),e.then(function(n){(t._status===0||t._status===-1)&&(t._status=1,t._result=n)},function(n){(t._status===0||t._status===-1)&&(t._status=2,t._result=n)}),t._status===-1&&(t._status=0,t._result=e)}if(t._status===1)return t._result.default;throw t._result}var It={current:null},El={transition:null},A_={ReactCurrentDispatcher:It,ReactCurrentBatchConfig:El,ReactCurrentOwner:Eh};function o0(){throw Error("act(...) is not supported in production builds of React.")}ae.Children={map:Qa,forEach:function(t,e,n){Qa(t,function(){e.apply(this,arguments)},n)},count:function(t){var e=0;return Qa(t,function(){e++}),e},toArray:function(t){return Qa(t,function(e){return e})||[]},only:function(t){if(!Th(t))throw Error("React.Children.only expected to receive a single React element child.");return t}};ae.Component=Fi;ae.Fragment=m_;ae.Profiler=y_;ae.PureComponent=wh;ae.StrictMode=g_;ae.Suspense=x_;ae.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=A_;ae.act=o0;ae.cloneElement=function(t,e,n){if(t==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+t+".");var r=e0({},t.props),s=t.key,i=t.ref,o=t._owner;if(e!=null){if(e.ref!==void 0&&(i=e.ref,o=Eh.current),e.key!==void 0&&(s=""+e.key),t.type&&t.type.defaultProps)var l=t.type.defaultProps;for(u in e)r0.call(e,u)&&!s0.hasOwnProperty(u)&&(r[u]=e[u]===void 0&&l!==void 0?l[u]:e[u])}var u=arguments.length-2;if(u===1)r.children=n;else if(1<u){l=Array(u);for(var d=0;d<u;d++)l[d]=arguments[d+2];r.children=l}return{$$typeof:xa,type:t.type,key:s,ref:i,props:r,_owner:o}};ae.createContext=function(t){return t={$$typeof:__,_currentValue:t,_currentValue2:t,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},t.Provider={$$typeof:v_,_context:t},t.Consumer=t};ae.createElement=i0;ae.createFactory=function(t){var e=i0.bind(null,t);return e.type=t,e};ae.createRef=function(){return{current:null}};ae.forwardRef=function(t){return{$$typeof:w_,render:t}};ae.isValidElement=Th;ae.lazy=function(t){return{$$typeof:T_,_payload:{_status:-1,_result:t},_init:I_}};ae.memo=function(t,e){return{$$typeof:E_,type:t,compare:e===void 0?null:e}};ae.startTransition=function(t){var e=El.transition;El.transition={};try{t()}finally{El.transition=e}};ae.unstable_act=o0;ae.useCallback=function(t,e){return It.current.useCallback(t,e)};ae.useContext=function(t){return It.current.useContext(t)};ae.useDebugValue=function(){};ae.useDeferredValue=function(t){return It.current.useDeferredValue(t)};ae.useEffect=function(t,e){return It.current.useEffect(t,e)};ae.useId=function(){return It.current.useId()};ae.useImperativeHandle=function(t,e,n){return It.current.useImperativeHandle(t,e,n)};ae.useInsertionEffect=function(t,e){return It.current.useInsertionEffect(t,e)};ae.useLayoutEffect=function(t,e){return It.current.useLayoutEffect(t,e)};ae.useMemo=function(t,e){return It.current.useMemo(t,e)};ae.useReducer=function(t,e,n){return It.current.useReducer(t,e,n)};ae.useRef=function(t){return It.current.useRef(t)};ae.useState=function(t){return It.current.useState(t)};ae.useSyncExternalStore=function(t,e,n){return It.current.useSyncExternalStore(t,e,n)};ae.useTransition=function(){return It.current.useTransition()};ae.version="18.3.1";Jg.exports=ae;var D=Jg.exports;const C_=f_(D);/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var R_=D,P_=Symbol.for("react.element"),N_=Symbol.for("react.fragment"),V_=Object.prototype.hasOwnProperty,D_=R_.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,M_={key:!0,ref:!0,__self:!0,__source:!0};function a0(t,e,n){var r,s={},i=null,o=null;n!==void 0&&(i=""+n),e.key!==void 0&&(i=""+e.key),e.ref!==void 0&&(o=e.ref);for(r in e)V_.call(e,r)&&!M_.hasOwnProperty(r)&&(s[r]=e[r]);if(t&&t.defaultProps)for(r in e=t.defaultProps,e)s[r]===void 0&&(s[r]=e[r]);return{$$typeof:P_,type:t,key:i,ref:o,props:s,_owner:D_.current}}Au.Fragment=N_;Au.jsx=a0;Au.jsxs=a0;Xg.exports=Au;var p=Xg.exports,ed={},l0={exports:{}},Bt={},u0={exports:{}},c0={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(t){function e(H,Y){var ne=H.length;H.push(Y);e:for(;0<ne;){var ie=ne-1>>>1,Te=H[ie];if(0<s(Te,Y))H[ie]=Y,H[ne]=Te,ne=ie;else break e}}function n(H){return H.length===0?null:H[0]}function r(H){if(H.length===0)return null;var Y=H[0],ne=H.pop();if(ne!==Y){H[0]=ne;e:for(var ie=0,Te=H.length,ln=Te>>>1;ie<ln;){var be=2*(ie+1)-1,un=H[be],Tt=be+1,qt=H[Tt];if(0>s(un,ne))Tt<Te&&0>s(qt,un)?(H[ie]=qt,H[Tt]=ne,ie=Tt):(H[ie]=un,H[be]=ne,ie=be);else if(Tt<Te&&0>s(qt,ne))H[ie]=qt,H[Tt]=ne,ie=Tt;else break e}}return Y}function s(H,Y){var ne=H.sortIndex-Y.sortIndex;return ne!==0?ne:H.id-Y.id}if(typeof performance=="object"&&typeof performance.now=="function"){var i=performance;t.unstable_now=function(){return i.now()}}else{var o=Date,l=o.now();t.unstable_now=function(){return o.now()-l}}var u=[],d=[],f=1,m=null,v=3,I=!1,A=!1,P=!1,M=typeof setTimeout=="function"?setTimeout:null,S=typeof clearTimeout=="function"?clearTimeout:null,x=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function k(H){for(var Y=n(d);Y!==null;){if(Y.callback===null)r(d);else if(Y.startTime<=H)r(d),Y.sortIndex=Y.expirationTime,e(u,Y);else break;Y=n(d)}}function V(H){if(P=!1,k(H),!A)if(n(u)!==null)A=!0,Et(F);else{var Y=n(d);Y!==null&&je(V,Y.startTime-H)}}function F(H,Y){A=!1,P&&(P=!1,S(y),y=-1),I=!0;var ne=v;try{for(k(Y),m=n(u);m!==null&&(!(m.expirationTime>Y)||H&&!b());){var ie=m.callback;if(typeof ie=="function"){m.callback=null,v=m.priorityLevel;var Te=ie(m.expirationTime<=Y);Y=t.unstable_now(),typeof Te=="function"?m.callback=Te:m===n(u)&&r(u),k(Y)}else r(u);m=n(u)}if(m!==null)var ln=!0;else{var be=n(d);be!==null&&je(V,be.startTime-Y),ln=!1}return ln}finally{m=null,v=ne,I=!1}}var B=!1,w=null,y=-1,_=5,T=-1;function b(){return!(t.unstable_now()-T<_)}function C(){if(w!==null){var H=t.unstable_now();T=H;var Y=!0;try{Y=w(!0,H)}finally{Y?E():(B=!1,w=null)}}else B=!1}var E;if(typeof x=="function")E=function(){x(C)};else if(typeof MessageChannel<"u"){var J=new MessageChannel,Pe=J.port2;J.port1.onmessage=C,E=function(){Pe.postMessage(null)}}else E=function(){M(C,0)};function Et(H){w=H,B||(B=!0,E())}function je(H,Y){y=M(function(){H(t.unstable_now())},Y)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(H){H.callback=null},t.unstable_continueExecution=function(){A||I||(A=!0,Et(F))},t.unstable_forceFrameRate=function(H){0>H||125<H?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):_=0<H?Math.floor(1e3/H):5},t.unstable_getCurrentPriorityLevel=function(){return v},t.unstable_getFirstCallbackNode=function(){return n(u)},t.unstable_next=function(H){switch(v){case 1:case 2:case 3:var Y=3;break;default:Y=v}var ne=v;v=Y;try{return H()}finally{v=ne}},t.unstable_pauseExecution=function(){},t.unstable_requestPaint=function(){},t.unstable_runWithPriority=function(H,Y){switch(H){case 1:case 2:case 3:case 4:case 5:break;default:H=3}var ne=v;v=H;try{return Y()}finally{v=ne}},t.unstable_scheduleCallback=function(H,Y,ne){var ie=t.unstable_now();switch(typeof ne=="object"&&ne!==null?(ne=ne.delay,ne=typeof ne=="number"&&0<ne?ie+ne:ie):ne=ie,H){case 1:var Te=-1;break;case 2:Te=250;break;case 5:Te=1073741823;break;case 4:Te=1e4;break;default:Te=5e3}return Te=ne+Te,H={id:f++,callback:Y,priorityLevel:H,startTime:ne,expirationTime:Te,sortIndex:-1},ne>ie?(H.sortIndex=ne,e(d,H),n(u)===null&&H===n(d)&&(P?(S(y),y=-1):P=!0,je(V,ne-ie))):(H.sortIndex=Te,e(u,H),A||I||(A=!0,Et(F))),H},t.unstable_shouldYield=b,t.unstable_wrapCallback=function(H){var Y=v;return function(){var ne=v;v=Y;try{return H.apply(this,arguments)}finally{v=ne}}}})(c0);u0.exports=c0;var L_=u0.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var j_=D,Ut=L_;function U(t){for(var e="https://reactjs.org/docs/error-decoder.html?invariant="+t,n=1;n<arguments.length;n++)e+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+t+"; visit "+e+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var d0=new Set,Wo={};function Ds(t,e){ki(t,e),ki(t+"Capture",e)}function ki(t,e){for(Wo[t]=e,t=0;t<e.length;t++)d0.add(e[t])}var Xn=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),td=Object.prototype.hasOwnProperty,O_=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Ep={},Tp={};function F_(t){return td.call(Tp,t)?!0:td.call(Ep,t)?!1:O_.test(t)?Tp[t]=!0:(Ep[t]=!0,!1)}function z_(t,e,n,r){if(n!==null&&n.type===0)return!1;switch(typeof e){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(t=t.toLowerCase().slice(0,5),t!=="data-"&&t!=="aria-");default:return!1}}function U_(t,e,n,r){if(e===null||typeof e>"u"||z_(t,e,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!e;case 4:return e===!1;case 5:return isNaN(e);case 6:return isNaN(e)||1>e}return!1}function At(t,e,n,r,s,i,o){this.acceptsBooleans=e===2||e===3||e===4,this.attributeName=r,this.attributeNamespace=s,this.mustUseProperty=n,this.propertyName=t,this.type=e,this.sanitizeURL=i,this.removeEmptyString=o}var ft={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t){ft[t]=new At(t,0,!1,t,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(t){var e=t[0];ft[e]=new At(e,1,!1,t[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(t){ft[t]=new At(t,2,!1,t.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(t){ft[t]=new At(t,2,!1,t,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t){ft[t]=new At(t,3,!1,t.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(t){ft[t]=new At(t,3,!0,t,null,!1,!1)});["capture","download"].forEach(function(t){ft[t]=new At(t,4,!1,t,null,!1,!1)});["cols","rows","size","span"].forEach(function(t){ft[t]=new At(t,6,!1,t,null,!1,!1)});["rowSpan","start"].forEach(function(t){ft[t]=new At(t,5,!1,t.toLowerCase(),null,!1,!1)});var bh=/[\-:]([a-z])/g;function Sh(t){return t[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t){var e=t.replace(bh,Sh);ft[e]=new At(e,1,!1,t,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t){var e=t.replace(bh,Sh);ft[e]=new At(e,1,!1,t,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(t){var e=t.replace(bh,Sh);ft[e]=new At(e,1,!1,t,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(t){ft[t]=new At(t,1,!1,t.toLowerCase(),null,!1,!1)});ft.xlinkHref=new At("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(t){ft[t]=new At(t,1,!1,t.toLowerCase(),null,!0,!0)});function kh(t,e,n,r){var s=ft.hasOwnProperty(e)?ft[e]:null;(s!==null?s.type!==0:r||!(2<e.length)||e[0]!=="o"&&e[0]!=="O"||e[1]!=="n"&&e[1]!=="N")&&(U_(e,n,s,r)&&(n=null),r||s===null?F_(e)&&(n===null?t.removeAttribute(e):t.setAttribute(e,""+n)):s.mustUseProperty?t[s.propertyName]=n===null?s.type===3?!1:"":n:(e=s.attributeName,r=s.attributeNamespace,n===null?t.removeAttribute(e):(s=s.type,n=s===3||s===4&&n===!0?"":""+n,r?t.setAttributeNS(r,e,n):t.setAttribute(e,n))))}var sr=j_.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,Ya=Symbol.for("react.element"),ni=Symbol.for("react.portal"),ri=Symbol.for("react.fragment"),Ih=Symbol.for("react.strict_mode"),nd=Symbol.for("react.profiler"),h0=Symbol.for("react.provider"),f0=Symbol.for("react.context"),Ah=Symbol.for("react.forward_ref"),rd=Symbol.for("react.suspense"),sd=Symbol.for("react.suspense_list"),Ch=Symbol.for("react.memo"),Er=Symbol.for("react.lazy"),p0=Symbol.for("react.offscreen"),bp=Symbol.iterator;function po(t){return t===null||typeof t!="object"?null:(t=bp&&t[bp]||t["@@iterator"],typeof t=="function"?t:null)}var Me=Object.assign,vc;function bo(t){if(vc===void 0)try{throw Error()}catch(n){var e=n.stack.trim().match(/\n( *(at )?)/);vc=e&&e[1]||""}return`
`+vc+t}var _c=!1;function wc(t,e){if(!t||_c)return"";_c=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(e)if(e=function(){throw Error()},Object.defineProperty(e.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(e,[])}catch(d){var r=d}Reflect.construct(t,[],e)}else{try{e.call()}catch(d){r=d}t.call(e.prototype)}else{try{throw Error()}catch(d){r=d}t()}}catch(d){if(d&&r&&typeof d.stack=="string"){for(var s=d.stack.split(`
`),i=r.stack.split(`
`),o=s.length-1,l=i.length-1;1<=o&&0<=l&&s[o]!==i[l];)l--;for(;1<=o&&0<=l;o--,l--)if(s[o]!==i[l]){if(o!==1||l!==1)do if(o--,l--,0>l||s[o]!==i[l]){var u=`
`+s[o].replace(" at new "," at ");return t.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",t.displayName)),u}while(1<=o&&0<=l);break}}}finally{_c=!1,Error.prepareStackTrace=n}return(t=t?t.displayName||t.name:"")?bo(t):""}function B_(t){switch(t.tag){case 5:return bo(t.type);case 16:return bo("Lazy");case 13:return bo("Suspense");case 19:return bo("SuspenseList");case 0:case 2:case 15:return t=wc(t.type,!1),t;case 11:return t=wc(t.type.render,!1),t;case 1:return t=wc(t.type,!0),t;default:return""}}function id(t){if(t==null)return null;if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case ri:return"Fragment";case ni:return"Portal";case nd:return"Profiler";case Ih:return"StrictMode";case rd:return"Suspense";case sd:return"SuspenseList"}if(typeof t=="object")switch(t.$$typeof){case f0:return(t.displayName||"Context")+".Consumer";case h0:return(t._context.displayName||"Context")+".Provider";case Ah:var e=t.render;return t=t.displayName,t||(t=e.displayName||e.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case Ch:return e=t.displayName||null,e!==null?e:id(t.type)||"Memo";case Er:e=t._payload,t=t._init;try{return id(t(e))}catch{}}return null}function $_(t){var e=t.type;switch(t.tag){case 24:return"Cache";case 9:return(e.displayName||"Context")+".Consumer";case 10:return(e._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return t=e.render,t=t.displayName||t.name||"",e.displayName||(t!==""?"ForwardRef("+t+")":"ForwardRef");case 7:return"Fragment";case 5:return e;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return id(e);case 8:return e===Ih?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e}return null}function Br(t){switch(typeof t){case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function m0(t){var e=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(e==="checkbox"||e==="radio")}function q_(t){var e=m0(t)?"checked":"value",n=Object.getOwnPropertyDescriptor(t.constructor.prototype,e),r=""+t[e];if(!t.hasOwnProperty(e)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var s=n.get,i=n.set;return Object.defineProperty(t,e,{configurable:!0,get:function(){return s.call(this)},set:function(o){r=""+o,i.call(this,o)}}),Object.defineProperty(t,e,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(o){r=""+o},stopTracking:function(){t._valueTracker=null,delete t[e]}}}}function Xa(t){t._valueTracker||(t._valueTracker=q_(t))}function g0(t){if(!t)return!1;var e=t._valueTracker;if(!e)return!0;var n=e.getValue(),r="";return t&&(r=m0(t)?t.checked?"true":"false":t.value),t=r,t!==n?(e.setValue(t),!0):!1}function Fl(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}function od(t,e){var n=e.checked;return Me({},e,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??t._wrapperState.initialChecked})}function Sp(t,e){var n=e.defaultValue==null?"":e.defaultValue,r=e.checked!=null?e.checked:e.defaultChecked;n=Br(e.value!=null?e.value:n),t._wrapperState={initialChecked:r,initialValue:n,controlled:e.type==="checkbox"||e.type==="radio"?e.checked!=null:e.value!=null}}function y0(t,e){e=e.checked,e!=null&&kh(t,"checked",e,!1)}function ad(t,e){y0(t,e);var n=Br(e.value),r=e.type;if(n!=null)r==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+n):t.value!==""+n&&(t.value=""+n);else if(r==="submit"||r==="reset"){t.removeAttribute("value");return}e.hasOwnProperty("value")?ld(t,e.type,n):e.hasOwnProperty("defaultValue")&&ld(t,e.type,Br(e.defaultValue)),e.checked==null&&e.defaultChecked!=null&&(t.defaultChecked=!!e.defaultChecked)}function kp(t,e,n){if(e.hasOwnProperty("value")||e.hasOwnProperty("defaultValue")){var r=e.type;if(!(r!=="submit"&&r!=="reset"||e.value!==void 0&&e.value!==null))return;e=""+t._wrapperState.initialValue,n||e===t.value||(t.value=e),t.defaultValue=e}n=t.name,n!==""&&(t.name=""),t.defaultChecked=!!t._wrapperState.initialChecked,n!==""&&(t.name=n)}function ld(t,e,n){(e!=="number"||Fl(t.ownerDocument)!==t)&&(n==null?t.defaultValue=""+t._wrapperState.initialValue:t.defaultValue!==""+n&&(t.defaultValue=""+n))}var So=Array.isArray;function mi(t,e,n,r){if(t=t.options,e){e={};for(var s=0;s<n.length;s++)e["$"+n[s]]=!0;for(n=0;n<t.length;n++)s=e.hasOwnProperty("$"+t[n].value),t[n].selected!==s&&(t[n].selected=s),s&&r&&(t[n].defaultSelected=!0)}else{for(n=""+Br(n),e=null,s=0;s<t.length;s++){if(t[s].value===n){t[s].selected=!0,r&&(t[s].defaultSelected=!0);return}e!==null||t[s].disabled||(e=t[s])}e!==null&&(e.selected=!0)}}function ud(t,e){if(e.dangerouslySetInnerHTML!=null)throw Error(U(91));return Me({},e,{value:void 0,defaultValue:void 0,children:""+t._wrapperState.initialValue})}function Ip(t,e){var n=e.value;if(n==null){if(n=e.children,e=e.defaultValue,n!=null){if(e!=null)throw Error(U(92));if(So(n)){if(1<n.length)throw Error(U(93));n=n[0]}e=n}e==null&&(e=""),n=e}t._wrapperState={initialValue:Br(n)}}function v0(t,e){var n=Br(e.value),r=Br(e.defaultValue);n!=null&&(n=""+n,n!==t.value&&(t.value=n),e.defaultValue==null&&t.defaultValue!==n&&(t.defaultValue=n)),r!=null&&(t.defaultValue=""+r)}function Ap(t){var e=t.textContent;e===t._wrapperState.initialValue&&e!==""&&e!==null&&(t.value=e)}function _0(t){switch(t){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function cd(t,e){return t==null||t==="http://www.w3.org/1999/xhtml"?_0(e):t==="http://www.w3.org/2000/svg"&&e==="foreignObject"?"http://www.w3.org/1999/xhtml":t}var Ja,w0=function(t){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(e,n,r,s){MSApp.execUnsafeLocalFunction(function(){return t(e,n,r,s)})}:t}(function(t,e){if(t.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in t)t.innerHTML=e;else{for(Ja=Ja||document.createElement("div"),Ja.innerHTML="<svg>"+e.valueOf().toString()+"</svg>",e=Ja.firstChild;t.firstChild;)t.removeChild(t.firstChild);for(;e.firstChild;)t.appendChild(e.firstChild)}});function Go(t,e){if(e){var n=t.firstChild;if(n&&n===t.lastChild&&n.nodeType===3){n.nodeValue=e;return}}t.textContent=e}var No={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},H_=["Webkit","ms","Moz","O"];Object.keys(No).forEach(function(t){H_.forEach(function(e){e=e+t.charAt(0).toUpperCase()+t.substring(1),No[e]=No[t]})});function x0(t,e,n){return e==null||typeof e=="boolean"||e===""?"":n||typeof e!="number"||e===0||No.hasOwnProperty(t)&&No[t]?(""+e).trim():e+"px"}function E0(t,e){t=t.style;for(var n in e)if(e.hasOwnProperty(n)){var r=n.indexOf("--")===0,s=x0(n,e[n],r);n==="float"&&(n="cssFloat"),r?t.setProperty(n,s):t[n]=s}}var W_=Me({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function dd(t,e){if(e){if(W_[t]&&(e.children!=null||e.dangerouslySetInnerHTML!=null))throw Error(U(137,t));if(e.dangerouslySetInnerHTML!=null){if(e.children!=null)throw Error(U(60));if(typeof e.dangerouslySetInnerHTML!="object"||!("__html"in e.dangerouslySetInnerHTML))throw Error(U(61))}if(e.style!=null&&typeof e.style!="object")throw Error(U(62))}}function hd(t,e){if(t.indexOf("-")===-1)return typeof e.is=="string";switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var fd=null;function Rh(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var pd=null,gi=null,yi=null;function Cp(t){if(t=ba(t)){if(typeof pd!="function")throw Error(U(280));var e=t.stateNode;e&&(e=Vu(e),pd(t.stateNode,t.type,e))}}function T0(t){gi?yi?yi.push(t):yi=[t]:gi=t}function b0(){if(gi){var t=gi,e=yi;if(yi=gi=null,Cp(t),e)for(t=0;t<e.length;t++)Cp(e[t])}}function S0(t,e){return t(e)}function k0(){}var xc=!1;function I0(t,e,n){if(xc)return t(e,n);xc=!0;try{return S0(t,e,n)}finally{xc=!1,(gi!==null||yi!==null)&&(k0(),b0())}}function Ko(t,e){var n=t.stateNode;if(n===null)return null;var r=Vu(n);if(r===null)return null;n=r[e];e:switch(e){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(t=t.type,r=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!r;break e;default:t=!1}if(t)return null;if(n&&typeof n!="function")throw Error(U(231,e,typeof n));return n}var md=!1;if(Xn)try{var mo={};Object.defineProperty(mo,"passive",{get:function(){md=!0}}),window.addEventListener("test",mo,mo),window.removeEventListener("test",mo,mo)}catch{md=!1}function G_(t,e,n,r,s,i,o,l,u){var d=Array.prototype.slice.call(arguments,3);try{e.apply(n,d)}catch(f){this.onError(f)}}var Vo=!1,zl=null,Ul=!1,gd=null,K_={onError:function(t){Vo=!0,zl=t}};function Q_(t,e,n,r,s,i,o,l,u){Vo=!1,zl=null,G_.apply(K_,arguments)}function Y_(t,e,n,r,s,i,o,l,u){if(Q_.apply(this,arguments),Vo){if(Vo){var d=zl;Vo=!1,zl=null}else throw Error(U(198));Ul||(Ul=!0,gd=d)}}function Ms(t){var e=t,n=t;if(t.alternate)for(;e.return;)e=e.return;else{t=e;do e=t,e.flags&4098&&(n=e.return),t=e.return;while(t)}return e.tag===3?n:null}function A0(t){if(t.tag===13){var e=t.memoizedState;if(e===null&&(t=t.alternate,t!==null&&(e=t.memoizedState)),e!==null)return e.dehydrated}return null}function Rp(t){if(Ms(t)!==t)throw Error(U(188))}function X_(t){var e=t.alternate;if(!e){if(e=Ms(t),e===null)throw Error(U(188));return e!==t?null:t}for(var n=t,r=e;;){var s=n.return;if(s===null)break;var i=s.alternate;if(i===null){if(r=s.return,r!==null){n=r;continue}break}if(s.child===i.child){for(i=s.child;i;){if(i===n)return Rp(s),t;if(i===r)return Rp(s),e;i=i.sibling}throw Error(U(188))}if(n.return!==r.return)n=s,r=i;else{for(var o=!1,l=s.child;l;){if(l===n){o=!0,n=s,r=i;break}if(l===r){o=!0,r=s,n=i;break}l=l.sibling}if(!o){for(l=i.child;l;){if(l===n){o=!0,n=i,r=s;break}if(l===r){o=!0,r=i,n=s;break}l=l.sibling}if(!o)throw Error(U(189))}}if(n.alternate!==r)throw Error(U(190))}if(n.tag!==3)throw Error(U(188));return n.stateNode.current===n?t:e}function C0(t){return t=X_(t),t!==null?R0(t):null}function R0(t){if(t.tag===5||t.tag===6)return t;for(t=t.child;t!==null;){var e=R0(t);if(e!==null)return e;t=t.sibling}return null}var P0=Ut.unstable_scheduleCallback,Pp=Ut.unstable_cancelCallback,J_=Ut.unstable_shouldYield,Z_=Ut.unstable_requestPaint,$e=Ut.unstable_now,ew=Ut.unstable_getCurrentPriorityLevel,Ph=Ut.unstable_ImmediatePriority,N0=Ut.unstable_UserBlockingPriority,Bl=Ut.unstable_NormalPriority,tw=Ut.unstable_LowPriority,V0=Ut.unstable_IdlePriority,Cu=null,Dn=null;function nw(t){if(Dn&&typeof Dn.onCommitFiberRoot=="function")try{Dn.onCommitFiberRoot(Cu,t,void 0,(t.current.flags&128)===128)}catch{}}var wn=Math.clz32?Math.clz32:iw,rw=Math.log,sw=Math.LN2;function iw(t){return t>>>=0,t===0?32:31-(rw(t)/sw|0)|0}var Za=64,el=4194304;function ko(t){switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return t&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return t}}function $l(t,e){var n=t.pendingLanes;if(n===0)return 0;var r=0,s=t.suspendedLanes,i=t.pingedLanes,o=n&268435455;if(o!==0){var l=o&~s;l!==0?r=ko(l):(i&=o,i!==0&&(r=ko(i)))}else o=n&~s,o!==0?r=ko(o):i!==0&&(r=ko(i));if(r===0)return 0;if(e!==0&&e!==r&&!(e&s)&&(s=r&-r,i=e&-e,s>=i||s===16&&(i&4194240)!==0))return e;if(r&4&&(r|=n&16),e=t.entangledLanes,e!==0)for(t=t.entanglements,e&=r;0<e;)n=31-wn(e),s=1<<n,r|=t[n],e&=~s;return r}function ow(t,e){switch(t){case 1:case 2:case 4:return e+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function aw(t,e){for(var n=t.suspendedLanes,r=t.pingedLanes,s=t.expirationTimes,i=t.pendingLanes;0<i;){var o=31-wn(i),l=1<<o,u=s[o];u===-1?(!(l&n)||l&r)&&(s[o]=ow(l,e)):u<=e&&(t.expiredLanes|=l),i&=~l}}function yd(t){return t=t.pendingLanes&-1073741825,t!==0?t:t&1073741824?1073741824:0}function D0(){var t=Za;return Za<<=1,!(Za&4194240)&&(Za=64),t}function Ec(t){for(var e=[],n=0;31>n;n++)e.push(t);return e}function Ea(t,e,n){t.pendingLanes|=e,e!==536870912&&(t.suspendedLanes=0,t.pingedLanes=0),t=t.eventTimes,e=31-wn(e),t[e]=n}function lw(t,e){var n=t.pendingLanes&~e;t.pendingLanes=e,t.suspendedLanes=0,t.pingedLanes=0,t.expiredLanes&=e,t.mutableReadLanes&=e,t.entangledLanes&=e,e=t.entanglements;var r=t.eventTimes;for(t=t.expirationTimes;0<n;){var s=31-wn(n),i=1<<s;e[s]=0,r[s]=-1,t[s]=-1,n&=~i}}function Nh(t,e){var n=t.entangledLanes|=e;for(t=t.entanglements;n;){var r=31-wn(n),s=1<<r;s&e|t[r]&e&&(t[r]|=e),n&=~s}}var ve=0;function M0(t){return t&=-t,1<t?4<t?t&268435455?16:536870912:4:1}var L0,Vh,j0,O0,F0,vd=!1,tl=[],Cr=null,Rr=null,Pr=null,Qo=new Map,Yo=new Map,br=[],uw="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Np(t,e){switch(t){case"focusin":case"focusout":Cr=null;break;case"dragenter":case"dragleave":Rr=null;break;case"mouseover":case"mouseout":Pr=null;break;case"pointerover":case"pointerout":Qo.delete(e.pointerId);break;case"gotpointercapture":case"lostpointercapture":Yo.delete(e.pointerId)}}function go(t,e,n,r,s,i){return t===null||t.nativeEvent!==i?(t={blockedOn:e,domEventName:n,eventSystemFlags:r,nativeEvent:i,targetContainers:[s]},e!==null&&(e=ba(e),e!==null&&Vh(e)),t):(t.eventSystemFlags|=r,e=t.targetContainers,s!==null&&e.indexOf(s)===-1&&e.push(s),t)}function cw(t,e,n,r,s){switch(e){case"focusin":return Cr=go(Cr,t,e,n,r,s),!0;case"dragenter":return Rr=go(Rr,t,e,n,r,s),!0;case"mouseover":return Pr=go(Pr,t,e,n,r,s),!0;case"pointerover":var i=s.pointerId;return Qo.set(i,go(Qo.get(i)||null,t,e,n,r,s)),!0;case"gotpointercapture":return i=s.pointerId,Yo.set(i,go(Yo.get(i)||null,t,e,n,r,s)),!0}return!1}function z0(t){var e=_s(t.target);if(e!==null){var n=Ms(e);if(n!==null){if(e=n.tag,e===13){if(e=A0(n),e!==null){t.blockedOn=e,F0(t.priority,function(){j0(n)});return}}else if(e===3&&n.stateNode.current.memoizedState.isDehydrated){t.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Tl(t){if(t.blockedOn!==null)return!1;for(var e=t.targetContainers;0<e.length;){var n=_d(t.domEventName,t.eventSystemFlags,e[0],t.nativeEvent);if(n===null){n=t.nativeEvent;var r=new n.constructor(n.type,n);fd=r,n.target.dispatchEvent(r),fd=null}else return e=ba(n),e!==null&&Vh(e),t.blockedOn=n,!1;e.shift()}return!0}function Vp(t,e,n){Tl(t)&&n.delete(e)}function dw(){vd=!1,Cr!==null&&Tl(Cr)&&(Cr=null),Rr!==null&&Tl(Rr)&&(Rr=null),Pr!==null&&Tl(Pr)&&(Pr=null),Qo.forEach(Vp),Yo.forEach(Vp)}function yo(t,e){t.blockedOn===e&&(t.blockedOn=null,vd||(vd=!0,Ut.unstable_scheduleCallback(Ut.unstable_NormalPriority,dw)))}function Xo(t){function e(s){return yo(s,t)}if(0<tl.length){yo(tl[0],t);for(var n=1;n<tl.length;n++){var r=tl[n];r.blockedOn===t&&(r.blockedOn=null)}}for(Cr!==null&&yo(Cr,t),Rr!==null&&yo(Rr,t),Pr!==null&&yo(Pr,t),Qo.forEach(e),Yo.forEach(e),n=0;n<br.length;n++)r=br[n],r.blockedOn===t&&(r.blockedOn=null);for(;0<br.length&&(n=br[0],n.blockedOn===null);)z0(n),n.blockedOn===null&&br.shift()}var vi=sr.ReactCurrentBatchConfig,ql=!0;function hw(t,e,n,r){var s=ve,i=vi.transition;vi.transition=null;try{ve=1,Dh(t,e,n,r)}finally{ve=s,vi.transition=i}}function fw(t,e,n,r){var s=ve,i=vi.transition;vi.transition=null;try{ve=4,Dh(t,e,n,r)}finally{ve=s,vi.transition=i}}function Dh(t,e,n,r){if(ql){var s=_d(t,e,n,r);if(s===null)Nc(t,e,r,Hl,n),Np(t,r);else if(cw(s,t,e,n,r))r.stopPropagation();else if(Np(t,r),e&4&&-1<uw.indexOf(t)){for(;s!==null;){var i=ba(s);if(i!==null&&L0(i),i=_d(t,e,n,r),i===null&&Nc(t,e,r,Hl,n),i===s)break;s=i}s!==null&&r.stopPropagation()}else Nc(t,e,r,null,n)}}var Hl=null;function _d(t,e,n,r){if(Hl=null,t=Rh(r),t=_s(t),t!==null)if(e=Ms(t),e===null)t=null;else if(n=e.tag,n===13){if(t=A0(e),t!==null)return t;t=null}else if(n===3){if(e.stateNode.current.memoizedState.isDehydrated)return e.tag===3?e.stateNode.containerInfo:null;t=null}else e!==t&&(t=null);return Hl=t,null}function U0(t){switch(t){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(ew()){case Ph:return 1;case N0:return 4;case Bl:case tw:return 16;case V0:return 536870912;default:return 16}default:return 16}}var kr=null,Mh=null,bl=null;function B0(){if(bl)return bl;var t,e=Mh,n=e.length,r,s="value"in kr?kr.value:kr.textContent,i=s.length;for(t=0;t<n&&e[t]===s[t];t++);var o=n-t;for(r=1;r<=o&&e[n-r]===s[i-r];r++);return bl=s.slice(t,1<r?1-r:void 0)}function Sl(t){var e=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&e===13&&(t=13)):t=e,t===10&&(t=13),32<=t||t===13?t:0}function nl(){return!0}function Dp(){return!1}function $t(t){function e(n,r,s,i,o){this._reactName=n,this._targetInst=s,this.type=r,this.nativeEvent=i,this.target=o,this.currentTarget=null;for(var l in t)t.hasOwnProperty(l)&&(n=t[l],this[l]=n?n(i):i[l]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?nl:Dp,this.isPropagationStopped=Dp,this}return Me(e.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=nl)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=nl)},persist:function(){},isPersistent:nl}),e}var zi={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Lh=$t(zi),Ta=Me({},zi,{view:0,detail:0}),pw=$t(Ta),Tc,bc,vo,Ru=Me({},Ta,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:jh,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==vo&&(vo&&t.type==="mousemove"?(Tc=t.screenX-vo.screenX,bc=t.screenY-vo.screenY):bc=Tc=0,vo=t),Tc)},movementY:function(t){return"movementY"in t?t.movementY:bc}}),Mp=$t(Ru),mw=Me({},Ru,{dataTransfer:0}),gw=$t(mw),yw=Me({},Ta,{relatedTarget:0}),Sc=$t(yw),vw=Me({},zi,{animationName:0,elapsedTime:0,pseudoElement:0}),_w=$t(vw),ww=Me({},zi,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),xw=$t(ww),Ew=Me({},zi,{data:0}),Lp=$t(Ew),Tw={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},bw={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Sw={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function kw(t){var e=this.nativeEvent;return e.getModifierState?e.getModifierState(t):(t=Sw[t])?!!e[t]:!1}function jh(){return kw}var Iw=Me({},Ta,{key:function(t){if(t.key){var e=Tw[t.key]||t.key;if(e!=="Unidentified")return e}return t.type==="keypress"?(t=Sl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?bw[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:jh,charCode:function(t){return t.type==="keypress"?Sl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Sl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Aw=$t(Iw),Cw=Me({},Ru,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),jp=$t(Cw),Rw=Me({},Ta,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:jh}),Pw=$t(Rw),Nw=Me({},zi,{propertyName:0,elapsedTime:0,pseudoElement:0}),Vw=$t(Nw),Dw=Me({},Ru,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),Mw=$t(Dw),Lw=[9,13,27,32],Oh=Xn&&"CompositionEvent"in window,Do=null;Xn&&"documentMode"in document&&(Do=document.documentMode);var jw=Xn&&"TextEvent"in window&&!Do,$0=Xn&&(!Oh||Do&&8<Do&&11>=Do),Op=" ",Fp=!1;function q0(t,e){switch(t){case"keyup":return Lw.indexOf(e.keyCode)!==-1;case"keydown":return e.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function H0(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var si=!1;function Ow(t,e){switch(t){case"compositionend":return H0(e);case"keypress":return e.which!==32?null:(Fp=!0,Op);case"textInput":return t=e.data,t===Op&&Fp?null:t;default:return null}}function Fw(t,e){if(si)return t==="compositionend"||!Oh&&q0(t,e)?(t=B0(),bl=Mh=kr=null,si=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(e.ctrlKey||e.altKey||e.metaKey)||e.ctrlKey&&e.altKey){if(e.char&&1<e.char.length)return e.char;if(e.which)return String.fromCharCode(e.which)}return null;case"compositionend":return $0&&e.locale!=="ko"?null:e.data;default:return null}}var zw={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function zp(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e==="input"?!!zw[t.type]:e==="textarea"}function W0(t,e,n,r){T0(r),e=Wl(e,"onChange"),0<e.length&&(n=new Lh("onChange","change",null,n,r),t.push({event:n,listeners:e}))}var Mo=null,Jo=null;function Uw(t){ry(t,0)}function Pu(t){var e=ai(t);if(g0(e))return t}function Bw(t,e){if(t==="change")return e}var G0=!1;if(Xn){var kc;if(Xn){var Ic="oninput"in document;if(!Ic){var Up=document.createElement("div");Up.setAttribute("oninput","return;"),Ic=typeof Up.oninput=="function"}kc=Ic}else kc=!1;G0=kc&&(!document.documentMode||9<document.documentMode)}function Bp(){Mo&&(Mo.detachEvent("onpropertychange",K0),Jo=Mo=null)}function K0(t){if(t.propertyName==="value"&&Pu(Jo)){var e=[];W0(e,Jo,t,Rh(t)),I0(Uw,e)}}function $w(t,e,n){t==="focusin"?(Bp(),Mo=e,Jo=n,Mo.attachEvent("onpropertychange",K0)):t==="focusout"&&Bp()}function qw(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Pu(Jo)}function Hw(t,e){if(t==="click")return Pu(e)}function Ww(t,e){if(t==="input"||t==="change")return Pu(e)}function Gw(t,e){return t===e&&(t!==0||1/t===1/e)||t!==t&&e!==e}var Tn=typeof Object.is=="function"?Object.is:Gw;function Zo(t,e){if(Tn(t,e))return!0;if(typeof t!="object"||t===null||typeof e!="object"||e===null)return!1;var n=Object.keys(t),r=Object.keys(e);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var s=n[r];if(!td.call(e,s)||!Tn(t[s],e[s]))return!1}return!0}function $p(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function qp(t,e){var n=$p(t);t=0;for(var r;n;){if(n.nodeType===3){if(r=t+n.textContent.length,t<=e&&r>=e)return{node:n,offset:e-t};t=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=$p(n)}}function Q0(t,e){return t&&e?t===e?!0:t&&t.nodeType===3?!1:e&&e.nodeType===3?Q0(t,e.parentNode):"contains"in t?t.contains(e):t.compareDocumentPosition?!!(t.compareDocumentPosition(e)&16):!1:!1}function Y0(){for(var t=window,e=Fl();e instanceof t.HTMLIFrameElement;){try{var n=typeof e.contentWindow.location.href=="string"}catch{n=!1}if(n)t=e.contentWindow;else break;e=Fl(t.document)}return e}function Fh(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e&&(e==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||e==="textarea"||t.contentEditable==="true")}function Kw(t){var e=Y0(),n=t.focusedElem,r=t.selectionRange;if(e!==n&&n&&n.ownerDocument&&Q0(n.ownerDocument.documentElement,n)){if(r!==null&&Fh(n)){if(e=r.start,t=r.end,t===void 0&&(t=e),"selectionStart"in n)n.selectionStart=e,n.selectionEnd=Math.min(t,n.value.length);else if(t=(e=n.ownerDocument||document)&&e.defaultView||window,t.getSelection){t=t.getSelection();var s=n.textContent.length,i=Math.min(r.start,s);r=r.end===void 0?i:Math.min(r.end,s),!t.extend&&i>r&&(s=r,r=i,i=s),s=qp(n,i);var o=qp(n,r);s&&o&&(t.rangeCount!==1||t.anchorNode!==s.node||t.anchorOffset!==s.offset||t.focusNode!==o.node||t.focusOffset!==o.offset)&&(e=e.createRange(),e.setStart(s.node,s.offset),t.removeAllRanges(),i>r?(t.addRange(e),t.extend(o.node,o.offset)):(e.setEnd(o.node,o.offset),t.addRange(e)))}}for(e=[],t=n;t=t.parentNode;)t.nodeType===1&&e.push({element:t,left:t.scrollLeft,top:t.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<e.length;n++)t=e[n],t.element.scrollLeft=t.left,t.element.scrollTop=t.top}}var Qw=Xn&&"documentMode"in document&&11>=document.documentMode,ii=null,wd=null,Lo=null,xd=!1;function Hp(t,e,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;xd||ii==null||ii!==Fl(r)||(r=ii,"selectionStart"in r&&Fh(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Lo&&Zo(Lo,r)||(Lo=r,r=Wl(wd,"onSelect"),0<r.length&&(e=new Lh("onSelect","select",null,e,n),t.push({event:e,listeners:r}),e.target=ii)))}function rl(t,e){var n={};return n[t.toLowerCase()]=e.toLowerCase(),n["Webkit"+t]="webkit"+e,n["Moz"+t]="moz"+e,n}var oi={animationend:rl("Animation","AnimationEnd"),animationiteration:rl("Animation","AnimationIteration"),animationstart:rl("Animation","AnimationStart"),transitionend:rl("Transition","TransitionEnd")},Ac={},X0={};Xn&&(X0=document.createElement("div").style,"AnimationEvent"in window||(delete oi.animationend.animation,delete oi.animationiteration.animation,delete oi.animationstart.animation),"TransitionEvent"in window||delete oi.transitionend.transition);function Nu(t){if(Ac[t])return Ac[t];if(!oi[t])return t;var e=oi[t],n;for(n in e)if(e.hasOwnProperty(n)&&n in X0)return Ac[t]=e[n];return t}var J0=Nu("animationend"),Z0=Nu("animationiteration"),ey=Nu("animationstart"),ty=Nu("transitionend"),ny=new Map,Wp="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Yr(t,e){ny.set(t,e),Ds(e,[t])}for(var Cc=0;Cc<Wp.length;Cc++){var Rc=Wp[Cc],Yw=Rc.toLowerCase(),Xw=Rc[0].toUpperCase()+Rc.slice(1);Yr(Yw,"on"+Xw)}Yr(J0,"onAnimationEnd");Yr(Z0,"onAnimationIteration");Yr(ey,"onAnimationStart");Yr("dblclick","onDoubleClick");Yr("focusin","onFocus");Yr("focusout","onBlur");Yr(ty,"onTransitionEnd");ki("onMouseEnter",["mouseout","mouseover"]);ki("onMouseLeave",["mouseout","mouseover"]);ki("onPointerEnter",["pointerout","pointerover"]);ki("onPointerLeave",["pointerout","pointerover"]);Ds("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Ds("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Ds("onBeforeInput",["compositionend","keypress","textInput","paste"]);Ds("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Ds("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Ds("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Io="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Jw=new Set("cancel close invalid load scroll toggle".split(" ").concat(Io));function Gp(t,e,n){var r=t.type||"unknown-event";t.currentTarget=n,Y_(r,e,void 0,t),t.currentTarget=null}function ry(t,e){e=(e&4)!==0;for(var n=0;n<t.length;n++){var r=t[n],s=r.event;r=r.listeners;e:{var i=void 0;if(e)for(var o=r.length-1;0<=o;o--){var l=r[o],u=l.instance,d=l.currentTarget;if(l=l.listener,u!==i&&s.isPropagationStopped())break e;Gp(s,l,d),i=u}else for(o=0;o<r.length;o++){if(l=r[o],u=l.instance,d=l.currentTarget,l=l.listener,u!==i&&s.isPropagationStopped())break e;Gp(s,l,d),i=u}}}if(Ul)throw t=gd,Ul=!1,gd=null,t}function ke(t,e){var n=e[kd];n===void 0&&(n=e[kd]=new Set);var r=t+"__bubble";n.has(r)||(sy(e,t,2,!1),n.add(r))}function Pc(t,e,n){var r=0;e&&(r|=4),sy(n,t,r,e)}var sl="_reactListening"+Math.random().toString(36).slice(2);function ea(t){if(!t[sl]){t[sl]=!0,d0.forEach(function(n){n!=="selectionchange"&&(Jw.has(n)||Pc(n,!1,t),Pc(n,!0,t))});var e=t.nodeType===9?t:t.ownerDocument;e===null||e[sl]||(e[sl]=!0,Pc("selectionchange",!1,e))}}function sy(t,e,n,r){switch(U0(e)){case 1:var s=hw;break;case 4:s=fw;break;default:s=Dh}n=s.bind(null,e,n,t),s=void 0,!md||e!=="touchstart"&&e!=="touchmove"&&e!=="wheel"||(s=!0),r?s!==void 0?t.addEventListener(e,n,{capture:!0,passive:s}):t.addEventListener(e,n,!0):s!==void 0?t.addEventListener(e,n,{passive:s}):t.addEventListener(e,n,!1)}function Nc(t,e,n,r,s){var i=r;if(!(e&1)&&!(e&2)&&r!==null)e:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var l=r.stateNode.containerInfo;if(l===s||l.nodeType===8&&l.parentNode===s)break;if(o===4)for(o=r.return;o!==null;){var u=o.tag;if((u===3||u===4)&&(u=o.stateNode.containerInfo,u===s||u.nodeType===8&&u.parentNode===s))return;o=o.return}for(;l!==null;){if(o=_s(l),o===null)return;if(u=o.tag,u===5||u===6){r=i=o;continue e}l=l.parentNode}}r=r.return}I0(function(){var d=i,f=Rh(n),m=[];e:{var v=ny.get(t);if(v!==void 0){var I=Lh,A=t;switch(t){case"keypress":if(Sl(n)===0)break e;case"keydown":case"keyup":I=Aw;break;case"focusin":A="focus",I=Sc;break;case"focusout":A="blur",I=Sc;break;case"beforeblur":case"afterblur":I=Sc;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":I=Mp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":I=gw;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":I=Pw;break;case J0:case Z0:case ey:I=_w;break;case ty:I=Vw;break;case"scroll":I=pw;break;case"wheel":I=Mw;break;case"copy":case"cut":case"paste":I=xw;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":I=jp}var P=(e&4)!==0,M=!P&&t==="scroll",S=P?v!==null?v+"Capture":null:v;P=[];for(var x=d,k;x!==null;){k=x;var V=k.stateNode;if(k.tag===5&&V!==null&&(k=V,S!==null&&(V=Ko(x,S),V!=null&&P.push(ta(x,V,k)))),M)break;x=x.return}0<P.length&&(v=new I(v,A,null,n,f),m.push({event:v,listeners:P}))}}if(!(e&7)){e:{if(v=t==="mouseover"||t==="pointerover",I=t==="mouseout"||t==="pointerout",v&&n!==fd&&(A=n.relatedTarget||n.fromElement)&&(_s(A)||A[Jn]))break e;if((I||v)&&(v=f.window===f?f:(v=f.ownerDocument)?v.defaultView||v.parentWindow:window,I?(A=n.relatedTarget||n.toElement,I=d,A=A?_s(A):null,A!==null&&(M=Ms(A),A!==M||A.tag!==5&&A.tag!==6)&&(A=null)):(I=null,A=d),I!==A)){if(P=Mp,V="onMouseLeave",S="onMouseEnter",x="mouse",(t==="pointerout"||t==="pointerover")&&(P=jp,V="onPointerLeave",S="onPointerEnter",x="pointer"),M=I==null?v:ai(I),k=A==null?v:ai(A),v=new P(V,x+"leave",I,n,f),v.target=M,v.relatedTarget=k,V=null,_s(f)===d&&(P=new P(S,x+"enter",A,n,f),P.target=k,P.relatedTarget=M,V=P),M=V,I&&A)t:{for(P=I,S=A,x=0,k=P;k;k=Xs(k))x++;for(k=0,V=S;V;V=Xs(V))k++;for(;0<x-k;)P=Xs(P),x--;for(;0<k-x;)S=Xs(S),k--;for(;x--;){if(P===S||S!==null&&P===S.alternate)break t;P=Xs(P),S=Xs(S)}P=null}else P=null;I!==null&&Kp(m,v,I,P,!1),A!==null&&M!==null&&Kp(m,M,A,P,!0)}}e:{if(v=d?ai(d):window,I=v.nodeName&&v.nodeName.toLowerCase(),I==="select"||I==="input"&&v.type==="file")var F=Bw;else if(zp(v))if(G0)F=Ww;else{F=qw;var B=$w}else(I=v.nodeName)&&I.toLowerCase()==="input"&&(v.type==="checkbox"||v.type==="radio")&&(F=Hw);if(F&&(F=F(t,d))){W0(m,F,n,f);break e}B&&B(t,v,d),t==="focusout"&&(B=v._wrapperState)&&B.controlled&&v.type==="number"&&ld(v,"number",v.value)}switch(B=d?ai(d):window,t){case"focusin":(zp(B)||B.contentEditable==="true")&&(ii=B,wd=d,Lo=null);break;case"focusout":Lo=wd=ii=null;break;case"mousedown":xd=!0;break;case"contextmenu":case"mouseup":case"dragend":xd=!1,Hp(m,n,f);break;case"selectionchange":if(Qw)break;case"keydown":case"keyup":Hp(m,n,f)}var w;if(Oh)e:{switch(t){case"compositionstart":var y="onCompositionStart";break e;case"compositionend":y="onCompositionEnd";break e;case"compositionupdate":y="onCompositionUpdate";break e}y=void 0}else si?q0(t,n)&&(y="onCompositionEnd"):t==="keydown"&&n.keyCode===229&&(y="onCompositionStart");y&&($0&&n.locale!=="ko"&&(si||y!=="onCompositionStart"?y==="onCompositionEnd"&&si&&(w=B0()):(kr=f,Mh="value"in kr?kr.value:kr.textContent,si=!0)),B=Wl(d,y),0<B.length&&(y=new Lp(y,t,null,n,f),m.push({event:y,listeners:B}),w?y.data=w:(w=H0(n),w!==null&&(y.data=w)))),(w=jw?Ow(t,n):Fw(t,n))&&(d=Wl(d,"onBeforeInput"),0<d.length&&(f=new Lp("onBeforeInput","beforeinput",null,n,f),m.push({event:f,listeners:d}),f.data=w))}ry(m,e)})}function ta(t,e,n){return{instance:t,listener:e,currentTarget:n}}function Wl(t,e){for(var n=e+"Capture",r=[];t!==null;){var s=t,i=s.stateNode;s.tag===5&&i!==null&&(s=i,i=Ko(t,n),i!=null&&r.unshift(ta(t,i,s)),i=Ko(t,e),i!=null&&r.push(ta(t,i,s))),t=t.return}return r}function Xs(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5);return t||null}function Kp(t,e,n,r,s){for(var i=e._reactName,o=[];n!==null&&n!==r;){var l=n,u=l.alternate,d=l.stateNode;if(u!==null&&u===r)break;l.tag===5&&d!==null&&(l=d,s?(u=Ko(n,i),u!=null&&o.unshift(ta(n,u,l))):s||(u=Ko(n,i),u!=null&&o.push(ta(n,u,l)))),n=n.return}o.length!==0&&t.push({event:e,listeners:o})}var Zw=/\r\n?/g,ex=/\u0000|\uFFFD/g;function Qp(t){return(typeof t=="string"?t:""+t).replace(Zw,`
`).replace(ex,"")}function il(t,e,n){if(e=Qp(e),Qp(t)!==e&&n)throw Error(U(425))}function Gl(){}var Ed=null,Td=null;function bd(t,e){return t==="textarea"||t==="noscript"||typeof e.children=="string"||typeof e.children=="number"||typeof e.dangerouslySetInnerHTML=="object"&&e.dangerouslySetInnerHTML!==null&&e.dangerouslySetInnerHTML.__html!=null}var Sd=typeof setTimeout=="function"?setTimeout:void 0,tx=typeof clearTimeout=="function"?clearTimeout:void 0,Yp=typeof Promise=="function"?Promise:void 0,nx=typeof queueMicrotask=="function"?queueMicrotask:typeof Yp<"u"?function(t){return Yp.resolve(null).then(t).catch(rx)}:Sd;function rx(t){setTimeout(function(){throw t})}function Vc(t,e){var n=e,r=0;do{var s=n.nextSibling;if(t.removeChild(n),s&&s.nodeType===8)if(n=s.data,n==="/$"){if(r===0){t.removeChild(s),Xo(e);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=s}while(n);Xo(e)}function Nr(t){for(;t!=null;t=t.nextSibling){var e=t.nodeType;if(e===1||e===3)break;if(e===8){if(e=t.data,e==="$"||e==="$!"||e==="$?")break;if(e==="/$")return null}}return t}function Xp(t){t=t.previousSibling;for(var e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="$"||n==="$!"||n==="$?"){if(e===0)return t;e--}else n==="/$"&&e++}t=t.previousSibling}return null}var Ui=Math.random().toString(36).slice(2),Vn="__reactFiber$"+Ui,na="__reactProps$"+Ui,Jn="__reactContainer$"+Ui,kd="__reactEvents$"+Ui,sx="__reactListeners$"+Ui,ix="__reactHandles$"+Ui;function _s(t){var e=t[Vn];if(e)return e;for(var n=t.parentNode;n;){if(e=n[Jn]||n[Vn]){if(n=e.alternate,e.child!==null||n!==null&&n.child!==null)for(t=Xp(t);t!==null;){if(n=t[Vn])return n;t=Xp(t)}return e}t=n,n=t.parentNode}return null}function ba(t){return t=t[Vn]||t[Jn],!t||t.tag!==5&&t.tag!==6&&t.tag!==13&&t.tag!==3?null:t}function ai(t){if(t.tag===5||t.tag===6)return t.stateNode;throw Error(U(33))}function Vu(t){return t[na]||null}var Id=[],li=-1;function Xr(t){return{current:t}}function Ae(t){0>li||(t.current=Id[li],Id[li]=null,li--)}function Ee(t,e){li++,Id[li]=t.current,t.current=e}var $r={},xt=Xr($r),Dt=Xr(!1),ks=$r;function Ii(t,e){var n=t.type.contextTypes;if(!n)return $r;var r=t.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===e)return r.__reactInternalMemoizedMaskedChildContext;var s={},i;for(i in n)s[i]=e[i];return r&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=e,t.__reactInternalMemoizedMaskedChildContext=s),s}function Mt(t){return t=t.childContextTypes,t!=null}function Kl(){Ae(Dt),Ae(xt)}function Jp(t,e,n){if(xt.current!==$r)throw Error(U(168));Ee(xt,e),Ee(Dt,n)}function iy(t,e,n){var r=t.stateNode;if(e=e.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var s in r)if(!(s in e))throw Error(U(108,$_(t)||"Unknown",s));return Me({},n,r)}function Ql(t){return t=(t=t.stateNode)&&t.__reactInternalMemoizedMergedChildContext||$r,ks=xt.current,Ee(xt,t),Ee(Dt,Dt.current),!0}function Zp(t,e,n){var r=t.stateNode;if(!r)throw Error(U(169));n?(t=iy(t,e,ks),r.__reactInternalMemoizedMergedChildContext=t,Ae(Dt),Ae(xt),Ee(xt,t)):Ae(Dt),Ee(Dt,n)}var Wn=null,Du=!1,Dc=!1;function oy(t){Wn===null?Wn=[t]:Wn.push(t)}function ox(t){Du=!0,oy(t)}function Jr(){if(!Dc&&Wn!==null){Dc=!0;var t=0,e=ve;try{var n=Wn;for(ve=1;t<n.length;t++){var r=n[t];do r=r(!0);while(r!==null)}Wn=null,Du=!1}catch(s){throw Wn!==null&&(Wn=Wn.slice(t+1)),P0(Ph,Jr),s}finally{ve=e,Dc=!1}}return null}var ui=[],ci=0,Yl=null,Xl=0,Zt=[],en=0,Is=null,Gn=1,Kn="";function gs(t,e){ui[ci++]=Xl,ui[ci++]=Yl,Yl=t,Xl=e}function ay(t,e,n){Zt[en++]=Gn,Zt[en++]=Kn,Zt[en++]=Is,Is=t;var r=Gn;t=Kn;var s=32-wn(r)-1;r&=~(1<<s),n+=1;var i=32-wn(e)+s;if(30<i){var o=s-s%5;i=(r&(1<<o)-1).toString(32),r>>=o,s-=o,Gn=1<<32-wn(e)+s|n<<s|r,Kn=i+t}else Gn=1<<i|n<<s|r,Kn=t}function zh(t){t.return!==null&&(gs(t,1),ay(t,1,0))}function Uh(t){for(;t===Yl;)Yl=ui[--ci],ui[ci]=null,Xl=ui[--ci],ui[ci]=null;for(;t===Is;)Is=Zt[--en],Zt[en]=null,Kn=Zt[--en],Zt[en]=null,Gn=Zt[--en],Zt[en]=null}var zt=null,Ft=null,Re=!1,vn=null;function ly(t,e){var n=rn(5,null,null,0);n.elementType="DELETED",n.stateNode=e,n.return=t,e=t.deletions,e===null?(t.deletions=[n],t.flags|=16):e.push(n)}function em(t,e){switch(t.tag){case 5:var n=t.type;return e=e.nodeType!==1||n.toLowerCase()!==e.nodeName.toLowerCase()?null:e,e!==null?(t.stateNode=e,zt=t,Ft=Nr(e.firstChild),!0):!1;case 6:return e=t.pendingProps===""||e.nodeType!==3?null:e,e!==null?(t.stateNode=e,zt=t,Ft=null,!0):!1;case 13:return e=e.nodeType!==8?null:e,e!==null?(n=Is!==null?{id:Gn,overflow:Kn}:null,t.memoizedState={dehydrated:e,treeContext:n,retryLane:1073741824},n=rn(18,null,null,0),n.stateNode=e,n.return=t,t.child=n,zt=t,Ft=null,!0):!1;default:return!1}}function Ad(t){return(t.mode&1)!==0&&(t.flags&128)===0}function Cd(t){if(Re){var e=Ft;if(e){var n=e;if(!em(t,e)){if(Ad(t))throw Error(U(418));e=Nr(n.nextSibling);var r=zt;e&&em(t,e)?ly(r,n):(t.flags=t.flags&-4097|2,Re=!1,zt=t)}}else{if(Ad(t))throw Error(U(418));t.flags=t.flags&-4097|2,Re=!1,zt=t}}}function tm(t){for(t=t.return;t!==null&&t.tag!==5&&t.tag!==3&&t.tag!==13;)t=t.return;zt=t}function ol(t){if(t!==zt)return!1;if(!Re)return tm(t),Re=!0,!1;var e;if((e=t.tag!==3)&&!(e=t.tag!==5)&&(e=t.type,e=e!=="head"&&e!=="body"&&!bd(t.type,t.memoizedProps)),e&&(e=Ft)){if(Ad(t))throw uy(),Error(U(418));for(;e;)ly(t,e),e=Nr(e.nextSibling)}if(tm(t),t.tag===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(U(317));e:{for(t=t.nextSibling,e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="/$"){if(e===0){Ft=Nr(t.nextSibling);break e}e--}else n!=="$"&&n!=="$!"&&n!=="$?"||e++}t=t.nextSibling}Ft=null}}else Ft=zt?Nr(t.stateNode.nextSibling):null;return!0}function uy(){for(var t=Ft;t;)t=Nr(t.nextSibling)}function Ai(){Ft=zt=null,Re=!1}function Bh(t){vn===null?vn=[t]:vn.push(t)}var ax=sr.ReactCurrentBatchConfig;function _o(t,e,n){if(t=n.ref,t!==null&&typeof t!="function"&&typeof t!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(U(309));var r=n.stateNode}if(!r)throw Error(U(147,t));var s=r,i=""+t;return e!==null&&e.ref!==null&&typeof e.ref=="function"&&e.ref._stringRef===i?e.ref:(e=function(o){var l=s.refs;o===null?delete l[i]:l[i]=o},e._stringRef=i,e)}if(typeof t!="string")throw Error(U(284));if(!n._owner)throw Error(U(290,t))}return t}function al(t,e){throw t=Object.prototype.toString.call(e),Error(U(31,t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t))}function nm(t){var e=t._init;return e(t._payload)}function cy(t){function e(S,x){if(t){var k=S.deletions;k===null?(S.deletions=[x],S.flags|=16):k.push(x)}}function n(S,x){if(!t)return null;for(;x!==null;)e(S,x),x=x.sibling;return null}function r(S,x){for(S=new Map;x!==null;)x.key!==null?S.set(x.key,x):S.set(x.index,x),x=x.sibling;return S}function s(S,x){return S=Lr(S,x),S.index=0,S.sibling=null,S}function i(S,x,k){return S.index=k,t?(k=S.alternate,k!==null?(k=k.index,k<x?(S.flags|=2,x):k):(S.flags|=2,x)):(S.flags|=1048576,x)}function o(S){return t&&S.alternate===null&&(S.flags|=2),S}function l(S,x,k,V){return x===null||x.tag!==6?(x=Uc(k,S.mode,V),x.return=S,x):(x=s(x,k),x.return=S,x)}function u(S,x,k,V){var F=k.type;return F===ri?f(S,x,k.props.children,V,k.key):x!==null&&(x.elementType===F||typeof F=="object"&&F!==null&&F.$$typeof===Er&&nm(F)===x.type)?(V=s(x,k.props),V.ref=_o(S,x,k),V.return=S,V):(V=Nl(k.type,k.key,k.props,null,S.mode,V),V.ref=_o(S,x,k),V.return=S,V)}function d(S,x,k,V){return x===null||x.tag!==4||x.stateNode.containerInfo!==k.containerInfo||x.stateNode.implementation!==k.implementation?(x=Bc(k,S.mode,V),x.return=S,x):(x=s(x,k.children||[]),x.return=S,x)}function f(S,x,k,V,F){return x===null||x.tag!==7?(x=Ss(k,S.mode,V,F),x.return=S,x):(x=s(x,k),x.return=S,x)}function m(S,x,k){if(typeof x=="string"&&x!==""||typeof x=="number")return x=Uc(""+x,S.mode,k),x.return=S,x;if(typeof x=="object"&&x!==null){switch(x.$$typeof){case Ya:return k=Nl(x.type,x.key,x.props,null,S.mode,k),k.ref=_o(S,null,x),k.return=S,k;case ni:return x=Bc(x,S.mode,k),x.return=S,x;case Er:var V=x._init;return m(S,V(x._payload),k)}if(So(x)||po(x))return x=Ss(x,S.mode,k,null),x.return=S,x;al(S,x)}return null}function v(S,x,k,V){var F=x!==null?x.key:null;if(typeof k=="string"&&k!==""||typeof k=="number")return F!==null?null:l(S,x,""+k,V);if(typeof k=="object"&&k!==null){switch(k.$$typeof){case Ya:return k.key===F?u(S,x,k,V):null;case ni:return k.key===F?d(S,x,k,V):null;case Er:return F=k._init,v(S,x,F(k._payload),V)}if(So(k)||po(k))return F!==null?null:f(S,x,k,V,null);al(S,k)}return null}function I(S,x,k,V,F){if(typeof V=="string"&&V!==""||typeof V=="number")return S=S.get(k)||null,l(x,S,""+V,F);if(typeof V=="object"&&V!==null){switch(V.$$typeof){case Ya:return S=S.get(V.key===null?k:V.key)||null,u(x,S,V,F);case ni:return S=S.get(V.key===null?k:V.key)||null,d(x,S,V,F);case Er:var B=V._init;return I(S,x,k,B(V._payload),F)}if(So(V)||po(V))return S=S.get(k)||null,f(x,S,V,F,null);al(x,V)}return null}function A(S,x,k,V){for(var F=null,B=null,w=x,y=x=0,_=null;w!==null&&y<k.length;y++){w.index>y?(_=w,w=null):_=w.sibling;var T=v(S,w,k[y],V);if(T===null){w===null&&(w=_);break}t&&w&&T.alternate===null&&e(S,w),x=i(T,x,y),B===null?F=T:B.sibling=T,B=T,w=_}if(y===k.length)return n(S,w),Re&&gs(S,y),F;if(w===null){for(;y<k.length;y++)w=m(S,k[y],V),w!==null&&(x=i(w,x,y),B===null?F=w:B.sibling=w,B=w);return Re&&gs(S,y),F}for(w=r(S,w);y<k.length;y++)_=I(w,S,y,k[y],V),_!==null&&(t&&_.alternate!==null&&w.delete(_.key===null?y:_.key),x=i(_,x,y),B===null?F=_:B.sibling=_,B=_);return t&&w.forEach(function(b){return e(S,b)}),Re&&gs(S,y),F}function P(S,x,k,V){var F=po(k);if(typeof F!="function")throw Error(U(150));if(k=F.call(k),k==null)throw Error(U(151));for(var B=F=null,w=x,y=x=0,_=null,T=k.next();w!==null&&!T.done;y++,T=k.next()){w.index>y?(_=w,w=null):_=w.sibling;var b=v(S,w,T.value,V);if(b===null){w===null&&(w=_);break}t&&w&&b.alternate===null&&e(S,w),x=i(b,x,y),B===null?F=b:B.sibling=b,B=b,w=_}if(T.done)return n(S,w),Re&&gs(S,y),F;if(w===null){for(;!T.done;y++,T=k.next())T=m(S,T.value,V),T!==null&&(x=i(T,x,y),B===null?F=T:B.sibling=T,B=T);return Re&&gs(S,y),F}for(w=r(S,w);!T.done;y++,T=k.next())T=I(w,S,y,T.value,V),T!==null&&(t&&T.alternate!==null&&w.delete(T.key===null?y:T.key),x=i(T,x,y),B===null?F=T:B.sibling=T,B=T);return t&&w.forEach(function(C){return e(S,C)}),Re&&gs(S,y),F}function M(S,x,k,V){if(typeof k=="object"&&k!==null&&k.type===ri&&k.key===null&&(k=k.props.children),typeof k=="object"&&k!==null){switch(k.$$typeof){case Ya:e:{for(var F=k.key,B=x;B!==null;){if(B.key===F){if(F=k.type,F===ri){if(B.tag===7){n(S,B.sibling),x=s(B,k.props.children),x.return=S,S=x;break e}}else if(B.elementType===F||typeof F=="object"&&F!==null&&F.$$typeof===Er&&nm(F)===B.type){n(S,B.sibling),x=s(B,k.props),x.ref=_o(S,B,k),x.return=S,S=x;break e}n(S,B);break}else e(S,B);B=B.sibling}k.type===ri?(x=Ss(k.props.children,S.mode,V,k.key),x.return=S,S=x):(V=Nl(k.type,k.key,k.props,null,S.mode,V),V.ref=_o(S,x,k),V.return=S,S=V)}return o(S);case ni:e:{for(B=k.key;x!==null;){if(x.key===B)if(x.tag===4&&x.stateNode.containerInfo===k.containerInfo&&x.stateNode.implementation===k.implementation){n(S,x.sibling),x=s(x,k.children||[]),x.return=S,S=x;break e}else{n(S,x);break}else e(S,x);x=x.sibling}x=Bc(k,S.mode,V),x.return=S,S=x}return o(S);case Er:return B=k._init,M(S,x,B(k._payload),V)}if(So(k))return A(S,x,k,V);if(po(k))return P(S,x,k,V);al(S,k)}return typeof k=="string"&&k!==""||typeof k=="number"?(k=""+k,x!==null&&x.tag===6?(n(S,x.sibling),x=s(x,k),x.return=S,S=x):(n(S,x),x=Uc(k,S.mode,V),x.return=S,S=x),o(S)):n(S,x)}return M}var Ci=cy(!0),dy=cy(!1),Jl=Xr(null),Zl=null,di=null,$h=null;function qh(){$h=di=Zl=null}function Hh(t){var e=Jl.current;Ae(Jl),t._currentValue=e}function Rd(t,e,n){for(;t!==null;){var r=t.alternate;if((t.childLanes&e)!==e?(t.childLanes|=e,r!==null&&(r.childLanes|=e)):r!==null&&(r.childLanes&e)!==e&&(r.childLanes|=e),t===n)break;t=t.return}}function _i(t,e){Zl=t,$h=di=null,t=t.dependencies,t!==null&&t.firstContext!==null&&(t.lanes&e&&(Vt=!0),t.firstContext=null)}function on(t){var e=t._currentValue;if($h!==t)if(t={context:t,memoizedValue:e,next:null},di===null){if(Zl===null)throw Error(U(308));di=t,Zl.dependencies={lanes:0,firstContext:t}}else di=di.next=t;return e}var ws=null;function Wh(t){ws===null?ws=[t]:ws.push(t)}function hy(t,e,n,r){var s=e.interleaved;return s===null?(n.next=n,Wh(e)):(n.next=s.next,s.next=n),e.interleaved=n,Zn(t,r)}function Zn(t,e){t.lanes|=e;var n=t.alternate;for(n!==null&&(n.lanes|=e),n=t,t=t.return;t!==null;)t.childLanes|=e,n=t.alternate,n!==null&&(n.childLanes|=e),n=t,t=t.return;return n.tag===3?n.stateNode:null}var Tr=!1;function Gh(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function fy(t,e){t=t.updateQueue,e.updateQueue===t&&(e.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,effects:t.effects})}function Qn(t,e){return{eventTime:t,lane:e,tag:0,payload:null,callback:null,next:null}}function Vr(t,e,n){var r=t.updateQueue;if(r===null)return null;if(r=r.shared,me&2){var s=r.pending;return s===null?e.next=e:(e.next=s.next,s.next=e),r.pending=e,Zn(t,n)}return s=r.interleaved,s===null?(e.next=e,Wh(r)):(e.next=s.next,s.next=e),r.interleaved=e,Zn(t,n)}function kl(t,e,n){if(e=e.updateQueue,e!==null&&(e=e.shared,(n&4194240)!==0)){var r=e.lanes;r&=t.pendingLanes,n|=r,e.lanes=n,Nh(t,n)}}function rm(t,e){var n=t.updateQueue,r=t.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var s=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};i===null?s=i=o:i=i.next=o,n=n.next}while(n!==null);i===null?s=i=e:i=i.next=e}else s=i=e;n={baseState:r.baseState,firstBaseUpdate:s,lastBaseUpdate:i,shared:r.shared,effects:r.effects},t.updateQueue=n;return}t=n.lastBaseUpdate,t===null?n.firstBaseUpdate=e:t.next=e,n.lastBaseUpdate=e}function eu(t,e,n,r){var s=t.updateQueue;Tr=!1;var i=s.firstBaseUpdate,o=s.lastBaseUpdate,l=s.shared.pending;if(l!==null){s.shared.pending=null;var u=l,d=u.next;u.next=null,o===null?i=d:o.next=d,o=u;var f=t.alternate;f!==null&&(f=f.updateQueue,l=f.lastBaseUpdate,l!==o&&(l===null?f.firstBaseUpdate=d:l.next=d,f.lastBaseUpdate=u))}if(i!==null){var m=s.baseState;o=0,f=d=u=null,l=i;do{var v=l.lane,I=l.eventTime;if((r&v)===v){f!==null&&(f=f.next={eventTime:I,lane:0,tag:l.tag,payload:l.payload,callback:l.callback,next:null});e:{var A=t,P=l;switch(v=e,I=n,P.tag){case 1:if(A=P.payload,typeof A=="function"){m=A.call(I,m,v);break e}m=A;break e;case 3:A.flags=A.flags&-65537|128;case 0:if(A=P.payload,v=typeof A=="function"?A.call(I,m,v):A,v==null)break e;m=Me({},m,v);break e;case 2:Tr=!0}}l.callback!==null&&l.lane!==0&&(t.flags|=64,v=s.effects,v===null?s.effects=[l]:v.push(l))}else I={eventTime:I,lane:v,tag:l.tag,payload:l.payload,callback:l.callback,next:null},f===null?(d=f=I,u=m):f=f.next=I,o|=v;if(l=l.next,l===null){if(l=s.shared.pending,l===null)break;v=l,l=v.next,v.next=null,s.lastBaseUpdate=v,s.shared.pending=null}}while(!0);if(f===null&&(u=m),s.baseState=u,s.firstBaseUpdate=d,s.lastBaseUpdate=f,e=s.shared.interleaved,e!==null){s=e;do o|=s.lane,s=s.next;while(s!==e)}else i===null&&(s.shared.lanes=0);Cs|=o,t.lanes=o,t.memoizedState=m}}function sm(t,e,n){if(t=e.effects,e.effects=null,t!==null)for(e=0;e<t.length;e++){var r=t[e],s=r.callback;if(s!==null){if(r.callback=null,r=n,typeof s!="function")throw Error(U(191,s));s.call(r)}}}var Sa={},Mn=Xr(Sa),ra=Xr(Sa),sa=Xr(Sa);function xs(t){if(t===Sa)throw Error(U(174));return t}function Kh(t,e){switch(Ee(sa,e),Ee(ra,t),Ee(Mn,Sa),t=e.nodeType,t){case 9:case 11:e=(e=e.documentElement)?e.namespaceURI:cd(null,"");break;default:t=t===8?e.parentNode:e,e=t.namespaceURI||null,t=t.tagName,e=cd(e,t)}Ae(Mn),Ee(Mn,e)}function Ri(){Ae(Mn),Ae(ra),Ae(sa)}function py(t){xs(sa.current);var e=xs(Mn.current),n=cd(e,t.type);e!==n&&(Ee(ra,t),Ee(Mn,n))}function Qh(t){ra.current===t&&(Ae(Mn),Ae(ra))}var Ve=Xr(0);function tu(t){for(var e=t;e!==null;){if(e.tag===13){var n=e.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return e}else if(e.tag===19&&e.memoizedProps.revealOrder!==void 0){if(e.flags&128)return e}else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return null;e=e.return}e.sibling.return=e.return,e=e.sibling}return null}var Mc=[];function Yh(){for(var t=0;t<Mc.length;t++)Mc[t]._workInProgressVersionPrimary=null;Mc.length=0}var Il=sr.ReactCurrentDispatcher,Lc=sr.ReactCurrentBatchConfig,As=0,De=null,Xe=null,ot=null,nu=!1,jo=!1,ia=0,lx=0;function mt(){throw Error(U(321))}function Xh(t,e){if(e===null)return!1;for(var n=0;n<e.length&&n<t.length;n++)if(!Tn(t[n],e[n]))return!1;return!0}function Jh(t,e,n,r,s,i){if(As=i,De=e,e.memoizedState=null,e.updateQueue=null,e.lanes=0,Il.current=t===null||t.memoizedState===null?hx:fx,t=n(r,s),jo){i=0;do{if(jo=!1,ia=0,25<=i)throw Error(U(301));i+=1,ot=Xe=null,e.updateQueue=null,Il.current=px,t=n(r,s)}while(jo)}if(Il.current=ru,e=Xe!==null&&Xe.next!==null,As=0,ot=Xe=De=null,nu=!1,e)throw Error(U(300));return t}function Zh(){var t=ia!==0;return ia=0,t}function Pn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ot===null?De.memoizedState=ot=t:ot=ot.next=t,ot}function an(){if(Xe===null){var t=De.alternate;t=t!==null?t.memoizedState:null}else t=Xe.next;var e=ot===null?De.memoizedState:ot.next;if(e!==null)ot=e,Xe=t;else{if(t===null)throw Error(U(310));Xe=t,t={memoizedState:Xe.memoizedState,baseState:Xe.baseState,baseQueue:Xe.baseQueue,queue:Xe.queue,next:null},ot===null?De.memoizedState=ot=t:ot=ot.next=t}return ot}function oa(t,e){return typeof e=="function"?e(t):e}function jc(t){var e=an(),n=e.queue;if(n===null)throw Error(U(311));n.lastRenderedReducer=t;var r=Xe,s=r.baseQueue,i=n.pending;if(i!==null){if(s!==null){var o=s.next;s.next=i.next,i.next=o}r.baseQueue=s=i,n.pending=null}if(s!==null){i=s.next,r=r.baseState;var l=o=null,u=null,d=i;do{var f=d.lane;if((As&f)===f)u!==null&&(u=u.next={lane:0,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null}),r=d.hasEagerState?d.eagerState:t(r,d.action);else{var m={lane:f,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null};u===null?(l=u=m,o=r):u=u.next=m,De.lanes|=f,Cs|=f}d=d.next}while(d!==null&&d!==i);u===null?o=r:u.next=l,Tn(r,e.memoizedState)||(Vt=!0),e.memoizedState=r,e.baseState=o,e.baseQueue=u,n.lastRenderedState=r}if(t=n.interleaved,t!==null){s=t;do i=s.lane,De.lanes|=i,Cs|=i,s=s.next;while(s!==t)}else s===null&&(n.lanes=0);return[e.memoizedState,n.dispatch]}function Oc(t){var e=an(),n=e.queue;if(n===null)throw Error(U(311));n.lastRenderedReducer=t;var r=n.dispatch,s=n.pending,i=e.memoizedState;if(s!==null){n.pending=null;var o=s=s.next;do i=t(i,o.action),o=o.next;while(o!==s);Tn(i,e.memoizedState)||(Vt=!0),e.memoizedState=i,e.baseQueue===null&&(e.baseState=i),n.lastRenderedState=i}return[i,r]}function my(){}function gy(t,e){var n=De,r=an(),s=e(),i=!Tn(r.memoizedState,s);if(i&&(r.memoizedState=s,Vt=!0),r=r.queue,ef(_y.bind(null,n,r,t),[t]),r.getSnapshot!==e||i||ot!==null&&ot.memoizedState.tag&1){if(n.flags|=2048,aa(9,vy.bind(null,n,r,s,e),void 0,null),lt===null)throw Error(U(349));As&30||yy(n,e,s)}return s}function yy(t,e,n){t.flags|=16384,t={getSnapshot:e,value:n},e=De.updateQueue,e===null?(e={lastEffect:null,stores:null},De.updateQueue=e,e.stores=[t]):(n=e.stores,n===null?e.stores=[t]:n.push(t))}function vy(t,e,n,r){e.value=n,e.getSnapshot=r,wy(e)&&xy(t)}function _y(t,e,n){return n(function(){wy(e)&&xy(t)})}function wy(t){var e=t.getSnapshot;t=t.value;try{var n=e();return!Tn(t,n)}catch{return!0}}function xy(t){var e=Zn(t,1);e!==null&&xn(e,t,1,-1)}function im(t){var e=Pn();return typeof t=="function"&&(t=t()),e.memoizedState=e.baseState=t,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:oa,lastRenderedState:t},e.queue=t,t=t.dispatch=dx.bind(null,De,t),[e.memoizedState,t]}function aa(t,e,n,r){return t={tag:t,create:e,destroy:n,deps:r,next:null},e=De.updateQueue,e===null?(e={lastEffect:null,stores:null},De.updateQueue=e,e.lastEffect=t.next=t):(n=e.lastEffect,n===null?e.lastEffect=t.next=t:(r=n.next,n.next=t,t.next=r,e.lastEffect=t)),t}function Ey(){return an().memoizedState}function Al(t,e,n,r){var s=Pn();De.flags|=t,s.memoizedState=aa(1|e,n,void 0,r===void 0?null:r)}function Mu(t,e,n,r){var s=an();r=r===void 0?null:r;var i=void 0;if(Xe!==null){var o=Xe.memoizedState;if(i=o.destroy,r!==null&&Xh(r,o.deps)){s.memoizedState=aa(e,n,i,r);return}}De.flags|=t,s.memoizedState=aa(1|e,n,i,r)}function om(t,e){return Al(8390656,8,t,e)}function ef(t,e){return Mu(2048,8,t,e)}function Ty(t,e){return Mu(4,2,t,e)}function by(t,e){return Mu(4,4,t,e)}function Sy(t,e){if(typeof e=="function")return t=t(),e(t),function(){e(null)};if(e!=null)return t=t(),e.current=t,function(){e.current=null}}function ky(t,e,n){return n=n!=null?n.concat([t]):null,Mu(4,4,Sy.bind(null,e,t),n)}function tf(){}function Iy(t,e){var n=an();e=e===void 0?null:e;var r=n.memoizedState;return r!==null&&e!==null&&Xh(e,r[1])?r[0]:(n.memoizedState=[t,e],t)}function Ay(t,e){var n=an();e=e===void 0?null:e;var r=n.memoizedState;return r!==null&&e!==null&&Xh(e,r[1])?r[0]:(t=t(),n.memoizedState=[t,e],t)}function Cy(t,e,n){return As&21?(Tn(n,e)||(n=D0(),De.lanes|=n,Cs|=n,t.baseState=!0),e):(t.baseState&&(t.baseState=!1,Vt=!0),t.memoizedState=n)}function ux(t,e){var n=ve;ve=n!==0&&4>n?n:4,t(!0);var r=Lc.transition;Lc.transition={};try{t(!1),e()}finally{ve=n,Lc.transition=r}}function Ry(){return an().memoizedState}function cx(t,e,n){var r=Mr(t);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},Py(t))Ny(e,n);else if(n=hy(t,e,n,r),n!==null){var s=kt();xn(n,t,r,s),Vy(n,e,r)}}function dx(t,e,n){var r=Mr(t),s={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(Py(t))Ny(e,s);else{var i=t.alternate;if(t.lanes===0&&(i===null||i.lanes===0)&&(i=e.lastRenderedReducer,i!==null))try{var o=e.lastRenderedState,l=i(o,n);if(s.hasEagerState=!0,s.eagerState=l,Tn(l,o)){var u=e.interleaved;u===null?(s.next=s,Wh(e)):(s.next=u.next,u.next=s),e.interleaved=s;return}}catch{}finally{}n=hy(t,e,s,r),n!==null&&(s=kt(),xn(n,t,r,s),Vy(n,e,r))}}function Py(t){var e=t.alternate;return t===De||e!==null&&e===De}function Ny(t,e){jo=nu=!0;var n=t.pending;n===null?e.next=e:(e.next=n.next,n.next=e),t.pending=e}function Vy(t,e,n){if(n&4194240){var r=e.lanes;r&=t.pendingLanes,n|=r,e.lanes=n,Nh(t,n)}}var ru={readContext:on,useCallback:mt,useContext:mt,useEffect:mt,useImperativeHandle:mt,useInsertionEffect:mt,useLayoutEffect:mt,useMemo:mt,useReducer:mt,useRef:mt,useState:mt,useDebugValue:mt,useDeferredValue:mt,useTransition:mt,useMutableSource:mt,useSyncExternalStore:mt,useId:mt,unstable_isNewReconciler:!1},hx={readContext:on,useCallback:function(t,e){return Pn().memoizedState=[t,e===void 0?null:e],t},useContext:on,useEffect:om,useImperativeHandle:function(t,e,n){return n=n!=null?n.concat([t]):null,Al(4194308,4,Sy.bind(null,e,t),n)},useLayoutEffect:function(t,e){return Al(4194308,4,t,e)},useInsertionEffect:function(t,e){return Al(4,2,t,e)},useMemo:function(t,e){var n=Pn();return e=e===void 0?null:e,t=t(),n.memoizedState=[t,e],t},useReducer:function(t,e,n){var r=Pn();return e=n!==void 0?n(e):e,r.memoizedState=r.baseState=e,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:e},r.queue=t,t=t.dispatch=cx.bind(null,De,t),[r.memoizedState,t]},useRef:function(t){var e=Pn();return t={current:t},e.memoizedState=t},useState:im,useDebugValue:tf,useDeferredValue:function(t){return Pn().memoizedState=t},useTransition:function(){var t=im(!1),e=t[0];return t=ux.bind(null,t[1]),Pn().memoizedState=t,[e,t]},useMutableSource:function(){},useSyncExternalStore:function(t,e,n){var r=De,s=Pn();if(Re){if(n===void 0)throw Error(U(407));n=n()}else{if(n=e(),lt===null)throw Error(U(349));As&30||yy(r,e,n)}s.memoizedState=n;var i={value:n,getSnapshot:e};return s.queue=i,om(_y.bind(null,r,i,t),[t]),r.flags|=2048,aa(9,vy.bind(null,r,i,n,e),void 0,null),n},useId:function(){var t=Pn(),e=lt.identifierPrefix;if(Re){var n=Kn,r=Gn;n=(r&~(1<<32-wn(r)-1)).toString(32)+n,e=":"+e+"R"+n,n=ia++,0<n&&(e+="H"+n.toString(32)),e+=":"}else n=lx++,e=":"+e+"r"+n.toString(32)+":";return t.memoizedState=e},unstable_isNewReconciler:!1},fx={readContext:on,useCallback:Iy,useContext:on,useEffect:ef,useImperativeHandle:ky,useInsertionEffect:Ty,useLayoutEffect:by,useMemo:Ay,useReducer:jc,useRef:Ey,useState:function(){return jc(oa)},useDebugValue:tf,useDeferredValue:function(t){var e=an();return Cy(e,Xe.memoizedState,t)},useTransition:function(){var t=jc(oa)[0],e=an().memoizedState;return[t,e]},useMutableSource:my,useSyncExternalStore:gy,useId:Ry,unstable_isNewReconciler:!1},px={readContext:on,useCallback:Iy,useContext:on,useEffect:ef,useImperativeHandle:ky,useInsertionEffect:Ty,useLayoutEffect:by,useMemo:Ay,useReducer:Oc,useRef:Ey,useState:function(){return Oc(oa)},useDebugValue:tf,useDeferredValue:function(t){var e=an();return Xe===null?e.memoizedState=t:Cy(e,Xe.memoizedState,t)},useTransition:function(){var t=Oc(oa)[0],e=an().memoizedState;return[t,e]},useMutableSource:my,useSyncExternalStore:gy,useId:Ry,unstable_isNewReconciler:!1};function gn(t,e){if(t&&t.defaultProps){e=Me({},e),t=t.defaultProps;for(var n in t)e[n]===void 0&&(e[n]=t[n]);return e}return e}function Pd(t,e,n,r){e=t.memoizedState,n=n(r,e),n=n==null?e:Me({},e,n),t.memoizedState=n,t.lanes===0&&(t.updateQueue.baseState=n)}var Lu={isMounted:function(t){return(t=t._reactInternals)?Ms(t)===t:!1},enqueueSetState:function(t,e,n){t=t._reactInternals;var r=kt(),s=Mr(t),i=Qn(r,s);i.payload=e,n!=null&&(i.callback=n),e=Vr(t,i,s),e!==null&&(xn(e,t,s,r),kl(e,t,s))},enqueueReplaceState:function(t,e,n){t=t._reactInternals;var r=kt(),s=Mr(t),i=Qn(r,s);i.tag=1,i.payload=e,n!=null&&(i.callback=n),e=Vr(t,i,s),e!==null&&(xn(e,t,s,r),kl(e,t,s))},enqueueForceUpdate:function(t,e){t=t._reactInternals;var n=kt(),r=Mr(t),s=Qn(n,r);s.tag=2,e!=null&&(s.callback=e),e=Vr(t,s,r),e!==null&&(xn(e,t,r,n),kl(e,t,r))}};function am(t,e,n,r,s,i,o){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(r,i,o):e.prototype&&e.prototype.isPureReactComponent?!Zo(n,r)||!Zo(s,i):!0}function Dy(t,e,n){var r=!1,s=$r,i=e.contextType;return typeof i=="object"&&i!==null?i=on(i):(s=Mt(e)?ks:xt.current,r=e.contextTypes,i=(r=r!=null)?Ii(t,s):$r),e=new e(n,i),t.memoizedState=e.state!==null&&e.state!==void 0?e.state:null,e.updater=Lu,t.stateNode=e,e._reactInternals=t,r&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=s,t.__reactInternalMemoizedMaskedChildContext=i),e}function lm(t,e,n,r){t=e.state,typeof e.componentWillReceiveProps=="function"&&e.componentWillReceiveProps(n,r),typeof e.UNSAFE_componentWillReceiveProps=="function"&&e.UNSAFE_componentWillReceiveProps(n,r),e.state!==t&&Lu.enqueueReplaceState(e,e.state,null)}function Nd(t,e,n,r){var s=t.stateNode;s.props=n,s.state=t.memoizedState,s.refs={},Gh(t);var i=e.contextType;typeof i=="object"&&i!==null?s.context=on(i):(i=Mt(e)?ks:xt.current,s.context=Ii(t,i)),s.state=t.memoizedState,i=e.getDerivedStateFromProps,typeof i=="function"&&(Pd(t,e,i,n),s.state=t.memoizedState),typeof e.getDerivedStateFromProps=="function"||typeof s.getSnapshotBeforeUpdate=="function"||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(e=s.state,typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount(),e!==s.state&&Lu.enqueueReplaceState(s,s.state,null),eu(t,n,s,r),s.state=t.memoizedState),typeof s.componentDidMount=="function"&&(t.flags|=4194308)}function Pi(t,e){try{var n="",r=e;do n+=B_(r),r=r.return;while(r);var s=n}catch(i){s=`
Error generating stack: `+i.message+`
`+i.stack}return{value:t,source:e,stack:s,digest:null}}function Fc(t,e,n){return{value:t,source:null,stack:n??null,digest:e??null}}function Vd(t,e){try{console.error(e.value)}catch(n){setTimeout(function(){throw n})}}var mx=typeof WeakMap=="function"?WeakMap:Map;function My(t,e,n){n=Qn(-1,n),n.tag=3,n.payload={element:null};var r=e.value;return n.callback=function(){iu||(iu=!0,$d=r),Vd(t,e)},n}function Ly(t,e,n){n=Qn(-1,n),n.tag=3;var r=t.type.getDerivedStateFromError;if(typeof r=="function"){var s=e.value;n.payload=function(){return r(s)},n.callback=function(){Vd(t,e)}}var i=t.stateNode;return i!==null&&typeof i.componentDidCatch=="function"&&(n.callback=function(){Vd(t,e),typeof r!="function"&&(Dr===null?Dr=new Set([this]):Dr.add(this));var o=e.stack;this.componentDidCatch(e.value,{componentStack:o!==null?o:""})}),n}function um(t,e,n){var r=t.pingCache;if(r===null){r=t.pingCache=new mx;var s=new Set;r.set(e,s)}else s=r.get(e),s===void 0&&(s=new Set,r.set(e,s));s.has(n)||(s.add(n),t=Cx.bind(null,t,e,n),e.then(t,t))}function cm(t){do{var e;if((e=t.tag===13)&&(e=t.memoizedState,e=e!==null?e.dehydrated!==null:!0),e)return t;t=t.return}while(t!==null);return null}function dm(t,e,n,r,s){return t.mode&1?(t.flags|=65536,t.lanes=s,t):(t===e?t.flags|=65536:(t.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(e=Qn(-1,1),e.tag=2,Vr(n,e,1))),n.lanes|=1),t)}var gx=sr.ReactCurrentOwner,Vt=!1;function St(t,e,n,r){e.child=t===null?dy(e,null,n,r):Ci(e,t.child,n,r)}function hm(t,e,n,r,s){n=n.render;var i=e.ref;return _i(e,s),r=Jh(t,e,n,r,i,s),n=Zh(),t!==null&&!Vt?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~s,er(t,e,s)):(Re&&n&&zh(e),e.flags|=1,St(t,e,r,s),e.child)}function fm(t,e,n,r,s){if(t===null){var i=n.type;return typeof i=="function"&&!cf(i)&&i.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(e.tag=15,e.type=i,jy(t,e,i,r,s)):(t=Nl(n.type,null,r,e,e.mode,s),t.ref=e.ref,t.return=e,e.child=t)}if(i=t.child,!(t.lanes&s)){var o=i.memoizedProps;if(n=n.compare,n=n!==null?n:Zo,n(o,r)&&t.ref===e.ref)return er(t,e,s)}return e.flags|=1,t=Lr(i,r),t.ref=e.ref,t.return=e,e.child=t}function jy(t,e,n,r,s){if(t!==null){var i=t.memoizedProps;if(Zo(i,r)&&t.ref===e.ref)if(Vt=!1,e.pendingProps=r=i,(t.lanes&s)!==0)t.flags&131072&&(Vt=!0);else return e.lanes=t.lanes,er(t,e,s)}return Dd(t,e,n,r,s)}function Oy(t,e,n){var r=e.pendingProps,s=r.children,i=t!==null?t.memoizedState:null;if(r.mode==="hidden")if(!(e.mode&1))e.memoizedState={baseLanes:0,cachePool:null,transitions:null},Ee(fi,Ot),Ot|=n;else{if(!(n&1073741824))return t=i!==null?i.baseLanes|n:n,e.lanes=e.childLanes=1073741824,e.memoizedState={baseLanes:t,cachePool:null,transitions:null},e.updateQueue=null,Ee(fi,Ot),Ot|=t,null;e.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=i!==null?i.baseLanes:n,Ee(fi,Ot),Ot|=r}else i!==null?(r=i.baseLanes|n,e.memoizedState=null):r=n,Ee(fi,Ot),Ot|=r;return St(t,e,s,n),e.child}function Fy(t,e){var n=e.ref;(t===null&&n!==null||t!==null&&t.ref!==n)&&(e.flags|=512,e.flags|=2097152)}function Dd(t,e,n,r,s){var i=Mt(n)?ks:xt.current;return i=Ii(e,i),_i(e,s),n=Jh(t,e,n,r,i,s),r=Zh(),t!==null&&!Vt?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~s,er(t,e,s)):(Re&&r&&zh(e),e.flags|=1,St(t,e,n,s),e.child)}function pm(t,e,n,r,s){if(Mt(n)){var i=!0;Ql(e)}else i=!1;if(_i(e,s),e.stateNode===null)Cl(t,e),Dy(e,n,r),Nd(e,n,r,s),r=!0;else if(t===null){var o=e.stateNode,l=e.memoizedProps;o.props=l;var u=o.context,d=n.contextType;typeof d=="object"&&d!==null?d=on(d):(d=Mt(n)?ks:xt.current,d=Ii(e,d));var f=n.getDerivedStateFromProps,m=typeof f=="function"||typeof o.getSnapshotBeforeUpdate=="function";m||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(l!==r||u!==d)&&lm(e,o,r,d),Tr=!1;var v=e.memoizedState;o.state=v,eu(e,r,o,s),u=e.memoizedState,l!==r||v!==u||Dt.current||Tr?(typeof f=="function"&&(Pd(e,n,f,r),u=e.memoizedState),(l=Tr||am(e,n,l,r,v,u,d))?(m||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(e.flags|=4194308)):(typeof o.componentDidMount=="function"&&(e.flags|=4194308),e.memoizedProps=r,e.memoizedState=u),o.props=r,o.state=u,o.context=d,r=l):(typeof o.componentDidMount=="function"&&(e.flags|=4194308),r=!1)}else{o=e.stateNode,fy(t,e),l=e.memoizedProps,d=e.type===e.elementType?l:gn(e.type,l),o.props=d,m=e.pendingProps,v=o.context,u=n.contextType,typeof u=="object"&&u!==null?u=on(u):(u=Mt(n)?ks:xt.current,u=Ii(e,u));var I=n.getDerivedStateFromProps;(f=typeof I=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(l!==m||v!==u)&&lm(e,o,r,u),Tr=!1,v=e.memoizedState,o.state=v,eu(e,r,o,s);var A=e.memoizedState;l!==m||v!==A||Dt.current||Tr?(typeof I=="function"&&(Pd(e,n,I,r),A=e.memoizedState),(d=Tr||am(e,n,d,r,v,A,u)||!1)?(f||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(r,A,u),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(r,A,u)),typeof o.componentDidUpdate=="function"&&(e.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(e.flags|=1024)):(typeof o.componentDidUpdate!="function"||l===t.memoizedProps&&v===t.memoizedState||(e.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===t.memoizedProps&&v===t.memoizedState||(e.flags|=1024),e.memoizedProps=r,e.memoizedState=A),o.props=r,o.state=A,o.context=u,r=d):(typeof o.componentDidUpdate!="function"||l===t.memoizedProps&&v===t.memoizedState||(e.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||l===t.memoizedProps&&v===t.memoizedState||(e.flags|=1024),r=!1)}return Md(t,e,n,r,i,s)}function Md(t,e,n,r,s,i){Fy(t,e);var o=(e.flags&128)!==0;if(!r&&!o)return s&&Zp(e,n,!1),er(t,e,i);r=e.stateNode,gx.current=e;var l=o&&typeof n.getDerivedStateFromError!="function"?null:r.render();return e.flags|=1,t!==null&&o?(e.child=Ci(e,t.child,null,i),e.child=Ci(e,null,l,i)):St(t,e,l,i),e.memoizedState=r.state,s&&Zp(e,n,!0),e.child}function zy(t){var e=t.stateNode;e.pendingContext?Jp(t,e.pendingContext,e.pendingContext!==e.context):e.context&&Jp(t,e.context,!1),Kh(t,e.containerInfo)}function mm(t,e,n,r,s){return Ai(),Bh(s),e.flags|=256,St(t,e,n,r),e.child}var Ld={dehydrated:null,treeContext:null,retryLane:0};function jd(t){return{baseLanes:t,cachePool:null,transitions:null}}function Uy(t,e,n){var r=e.pendingProps,s=Ve.current,i=!1,o=(e.flags&128)!==0,l;if((l=o)||(l=t!==null&&t.memoizedState===null?!1:(s&2)!==0),l?(i=!0,e.flags&=-129):(t===null||t.memoizedState!==null)&&(s|=1),Ee(Ve,s&1),t===null)return Cd(e),t=e.memoizedState,t!==null&&(t=t.dehydrated,t!==null)?(e.mode&1?t.data==="$!"?e.lanes=8:e.lanes=1073741824:e.lanes=1,null):(o=r.children,t=r.fallback,i?(r=e.mode,i=e.child,o={mode:"hidden",children:o},!(r&1)&&i!==null?(i.childLanes=0,i.pendingProps=o):i=Fu(o,r,0,null),t=Ss(t,r,n,null),i.return=e,t.return=e,i.sibling=t,e.child=i,e.child.memoizedState=jd(n),e.memoizedState=Ld,t):nf(e,o));if(s=t.memoizedState,s!==null&&(l=s.dehydrated,l!==null))return yx(t,e,o,r,l,s,n);if(i){i=r.fallback,o=e.mode,s=t.child,l=s.sibling;var u={mode:"hidden",children:r.children};return!(o&1)&&e.child!==s?(r=e.child,r.childLanes=0,r.pendingProps=u,e.deletions=null):(r=Lr(s,u),r.subtreeFlags=s.subtreeFlags&14680064),l!==null?i=Lr(l,i):(i=Ss(i,o,n,null),i.flags|=2),i.return=e,r.return=e,r.sibling=i,e.child=r,r=i,i=e.child,o=t.child.memoizedState,o=o===null?jd(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},i.memoizedState=o,i.childLanes=t.childLanes&~n,e.memoizedState=Ld,r}return i=t.child,t=i.sibling,r=Lr(i,{mode:"visible",children:r.children}),!(e.mode&1)&&(r.lanes=n),r.return=e,r.sibling=null,t!==null&&(n=e.deletions,n===null?(e.deletions=[t],e.flags|=16):n.push(t)),e.child=r,e.memoizedState=null,r}function nf(t,e){return e=Fu({mode:"visible",children:e},t.mode,0,null),e.return=t,t.child=e}function ll(t,e,n,r){return r!==null&&Bh(r),Ci(e,t.child,null,n),t=nf(e,e.pendingProps.children),t.flags|=2,e.memoizedState=null,t}function yx(t,e,n,r,s,i,o){if(n)return e.flags&256?(e.flags&=-257,r=Fc(Error(U(422))),ll(t,e,o,r)):e.memoizedState!==null?(e.child=t.child,e.flags|=128,null):(i=r.fallback,s=e.mode,r=Fu({mode:"visible",children:r.children},s,0,null),i=Ss(i,s,o,null),i.flags|=2,r.return=e,i.return=e,r.sibling=i,e.child=r,e.mode&1&&Ci(e,t.child,null,o),e.child.memoizedState=jd(o),e.memoizedState=Ld,i);if(!(e.mode&1))return ll(t,e,o,null);if(s.data==="$!"){if(r=s.nextSibling&&s.nextSibling.dataset,r)var l=r.dgst;return r=l,i=Error(U(419)),r=Fc(i,r,void 0),ll(t,e,o,r)}if(l=(o&t.childLanes)!==0,Vt||l){if(r=lt,r!==null){switch(o&-o){case 4:s=2;break;case 16:s=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:s=32;break;case 536870912:s=268435456;break;default:s=0}s=s&(r.suspendedLanes|o)?0:s,s!==0&&s!==i.retryLane&&(i.retryLane=s,Zn(t,s),xn(r,t,s,-1))}return uf(),r=Fc(Error(U(421))),ll(t,e,o,r)}return s.data==="$?"?(e.flags|=128,e.child=t.child,e=Rx.bind(null,t),s._reactRetry=e,null):(t=i.treeContext,Ft=Nr(s.nextSibling),zt=e,Re=!0,vn=null,t!==null&&(Zt[en++]=Gn,Zt[en++]=Kn,Zt[en++]=Is,Gn=t.id,Kn=t.overflow,Is=e),e=nf(e,r.children),e.flags|=4096,e)}function gm(t,e,n){t.lanes|=e;var r=t.alternate;r!==null&&(r.lanes|=e),Rd(t.return,e,n)}function zc(t,e,n,r,s){var i=t.memoizedState;i===null?t.memoizedState={isBackwards:e,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:s}:(i.isBackwards=e,i.rendering=null,i.renderingStartTime=0,i.last=r,i.tail=n,i.tailMode=s)}function By(t,e,n){var r=e.pendingProps,s=r.revealOrder,i=r.tail;if(St(t,e,r.children,n),r=Ve.current,r&2)r=r&1|2,e.flags|=128;else{if(t!==null&&t.flags&128)e:for(t=e.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&gm(t,n,e);else if(t.tag===19)gm(t,n,e);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}r&=1}if(Ee(Ve,r),!(e.mode&1))e.memoizedState=null;else switch(s){case"forwards":for(n=e.child,s=null;n!==null;)t=n.alternate,t!==null&&tu(t)===null&&(s=n),n=n.sibling;n=s,n===null?(s=e.child,e.child=null):(s=n.sibling,n.sibling=null),zc(e,!1,s,n,i);break;case"backwards":for(n=null,s=e.child,e.child=null;s!==null;){if(t=s.alternate,t!==null&&tu(t)===null){e.child=s;break}t=s.sibling,s.sibling=n,n=s,s=t}zc(e,!0,n,null,i);break;case"together":zc(e,!1,null,null,void 0);break;default:e.memoizedState=null}return e.child}function Cl(t,e){!(e.mode&1)&&t!==null&&(t.alternate=null,e.alternate=null,e.flags|=2)}function er(t,e,n){if(t!==null&&(e.dependencies=t.dependencies),Cs|=e.lanes,!(n&e.childLanes))return null;if(t!==null&&e.child!==t.child)throw Error(U(153));if(e.child!==null){for(t=e.child,n=Lr(t,t.pendingProps),e.child=n,n.return=e;t.sibling!==null;)t=t.sibling,n=n.sibling=Lr(t,t.pendingProps),n.return=e;n.sibling=null}return e.child}function vx(t,e,n){switch(e.tag){case 3:zy(e),Ai();break;case 5:py(e);break;case 1:Mt(e.type)&&Ql(e);break;case 4:Kh(e,e.stateNode.containerInfo);break;case 10:var r=e.type._context,s=e.memoizedProps.value;Ee(Jl,r._currentValue),r._currentValue=s;break;case 13:if(r=e.memoizedState,r!==null)return r.dehydrated!==null?(Ee(Ve,Ve.current&1),e.flags|=128,null):n&e.child.childLanes?Uy(t,e,n):(Ee(Ve,Ve.current&1),t=er(t,e,n),t!==null?t.sibling:null);Ee(Ve,Ve.current&1);break;case 19:if(r=(n&e.childLanes)!==0,t.flags&128){if(r)return By(t,e,n);e.flags|=128}if(s=e.memoizedState,s!==null&&(s.rendering=null,s.tail=null,s.lastEffect=null),Ee(Ve,Ve.current),r)break;return null;case 22:case 23:return e.lanes=0,Oy(t,e,n)}return er(t,e,n)}var $y,Od,qy,Hy;$y=function(t,e){for(var n=e.child;n!==null;){if(n.tag===5||n.tag===6)t.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};Od=function(){};qy=function(t,e,n,r){var s=t.memoizedProps;if(s!==r){t=e.stateNode,xs(Mn.current);var i=null;switch(n){case"input":s=od(t,s),r=od(t,r),i=[];break;case"select":s=Me({},s,{value:void 0}),r=Me({},r,{value:void 0}),i=[];break;case"textarea":s=ud(t,s),r=ud(t,r),i=[];break;default:typeof s.onClick!="function"&&typeof r.onClick=="function"&&(t.onclick=Gl)}dd(n,r);var o;n=null;for(d in s)if(!r.hasOwnProperty(d)&&s.hasOwnProperty(d)&&s[d]!=null)if(d==="style"){var l=s[d];for(o in l)l.hasOwnProperty(o)&&(n||(n={}),n[o]="")}else d!=="dangerouslySetInnerHTML"&&d!=="children"&&d!=="suppressContentEditableWarning"&&d!=="suppressHydrationWarning"&&d!=="autoFocus"&&(Wo.hasOwnProperty(d)?i||(i=[]):(i=i||[]).push(d,null));for(d in r){var u=r[d];if(l=s!=null?s[d]:void 0,r.hasOwnProperty(d)&&u!==l&&(u!=null||l!=null))if(d==="style")if(l){for(o in l)!l.hasOwnProperty(o)||u&&u.hasOwnProperty(o)||(n||(n={}),n[o]="");for(o in u)u.hasOwnProperty(o)&&l[o]!==u[o]&&(n||(n={}),n[o]=u[o])}else n||(i||(i=[]),i.push(d,n)),n=u;else d==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,l=l?l.__html:void 0,u!=null&&l!==u&&(i=i||[]).push(d,u)):d==="children"?typeof u!="string"&&typeof u!="number"||(i=i||[]).push(d,""+u):d!=="suppressContentEditableWarning"&&d!=="suppressHydrationWarning"&&(Wo.hasOwnProperty(d)?(u!=null&&d==="onScroll"&&ke("scroll",t),i||l===u||(i=[])):(i=i||[]).push(d,u))}n&&(i=i||[]).push("style",n);var d=i;(e.updateQueue=d)&&(e.flags|=4)}};Hy=function(t,e,n,r){n!==r&&(e.flags|=4)};function wo(t,e){if(!Re)switch(t.tailMode){case"hidden":e=t.tail;for(var n=null;e!==null;)e.alternate!==null&&(n=e),e=e.sibling;n===null?t.tail=null:n.sibling=null;break;case"collapsed":n=t.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?e||t.tail===null?t.tail=null:t.tail.sibling=null:r.sibling=null}}function gt(t){var e=t.alternate!==null&&t.alternate.child===t.child,n=0,r=0;if(e)for(var s=t.child;s!==null;)n|=s.lanes|s.childLanes,r|=s.subtreeFlags&14680064,r|=s.flags&14680064,s.return=t,s=s.sibling;else for(s=t.child;s!==null;)n|=s.lanes|s.childLanes,r|=s.subtreeFlags,r|=s.flags,s.return=t,s=s.sibling;return t.subtreeFlags|=r,t.childLanes=n,e}function _x(t,e,n){var r=e.pendingProps;switch(Uh(e),e.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return gt(e),null;case 1:return Mt(e.type)&&Kl(),gt(e),null;case 3:return r=e.stateNode,Ri(),Ae(Dt),Ae(xt),Yh(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(t===null||t.child===null)&&(ol(e)?e.flags|=4:t===null||t.memoizedState.isDehydrated&&!(e.flags&256)||(e.flags|=1024,vn!==null&&(Wd(vn),vn=null))),Od(t,e),gt(e),null;case 5:Qh(e);var s=xs(sa.current);if(n=e.type,t!==null&&e.stateNode!=null)qy(t,e,n,r,s),t.ref!==e.ref&&(e.flags|=512,e.flags|=2097152);else{if(!r){if(e.stateNode===null)throw Error(U(166));return gt(e),null}if(t=xs(Mn.current),ol(e)){r=e.stateNode,n=e.type;var i=e.memoizedProps;switch(r[Vn]=e,r[na]=i,t=(e.mode&1)!==0,n){case"dialog":ke("cancel",r),ke("close",r);break;case"iframe":case"object":case"embed":ke("load",r);break;case"video":case"audio":for(s=0;s<Io.length;s++)ke(Io[s],r);break;case"source":ke("error",r);break;case"img":case"image":case"link":ke("error",r),ke("load",r);break;case"details":ke("toggle",r);break;case"input":Sp(r,i),ke("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!i.multiple},ke("invalid",r);break;case"textarea":Ip(r,i),ke("invalid",r)}dd(n,i),s=null;for(var o in i)if(i.hasOwnProperty(o)){var l=i[o];o==="children"?typeof l=="string"?r.textContent!==l&&(i.suppressHydrationWarning!==!0&&il(r.textContent,l,t),s=["children",l]):typeof l=="number"&&r.textContent!==""+l&&(i.suppressHydrationWarning!==!0&&il(r.textContent,l,t),s=["children",""+l]):Wo.hasOwnProperty(o)&&l!=null&&o==="onScroll"&&ke("scroll",r)}switch(n){case"input":Xa(r),kp(r,i,!0);break;case"textarea":Xa(r),Ap(r);break;case"select":case"option":break;default:typeof i.onClick=="function"&&(r.onclick=Gl)}r=s,e.updateQueue=r,r!==null&&(e.flags|=4)}else{o=s.nodeType===9?s:s.ownerDocument,t==="http://www.w3.org/1999/xhtml"&&(t=_0(n)),t==="http://www.w3.org/1999/xhtml"?n==="script"?(t=o.createElement("div"),t.innerHTML="<script><\/script>",t=t.removeChild(t.firstChild)):typeof r.is=="string"?t=o.createElement(n,{is:r.is}):(t=o.createElement(n),n==="select"&&(o=t,r.multiple?o.multiple=!0:r.size&&(o.size=r.size))):t=o.createElementNS(t,n),t[Vn]=e,t[na]=r,$y(t,e,!1,!1),e.stateNode=t;e:{switch(o=hd(n,r),n){case"dialog":ke("cancel",t),ke("close",t),s=r;break;case"iframe":case"object":case"embed":ke("load",t),s=r;break;case"video":case"audio":for(s=0;s<Io.length;s++)ke(Io[s],t);s=r;break;case"source":ke("error",t),s=r;break;case"img":case"image":case"link":ke("error",t),ke("load",t),s=r;break;case"details":ke("toggle",t),s=r;break;case"input":Sp(t,r),s=od(t,r),ke("invalid",t);break;case"option":s=r;break;case"select":t._wrapperState={wasMultiple:!!r.multiple},s=Me({},r,{value:void 0}),ke("invalid",t);break;case"textarea":Ip(t,r),s=ud(t,r),ke("invalid",t);break;default:s=r}dd(n,s),l=s;for(i in l)if(l.hasOwnProperty(i)){var u=l[i];i==="style"?E0(t,u):i==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,u!=null&&w0(t,u)):i==="children"?typeof u=="string"?(n!=="textarea"||u!=="")&&Go(t,u):typeof u=="number"&&Go(t,""+u):i!=="suppressContentEditableWarning"&&i!=="suppressHydrationWarning"&&i!=="autoFocus"&&(Wo.hasOwnProperty(i)?u!=null&&i==="onScroll"&&ke("scroll",t):u!=null&&kh(t,i,u,o))}switch(n){case"input":Xa(t),kp(t,r,!1);break;case"textarea":Xa(t),Ap(t);break;case"option":r.value!=null&&t.setAttribute("value",""+Br(r.value));break;case"select":t.multiple=!!r.multiple,i=r.value,i!=null?mi(t,!!r.multiple,i,!1):r.defaultValue!=null&&mi(t,!!r.multiple,r.defaultValue,!0);break;default:typeof s.onClick=="function"&&(t.onclick=Gl)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(e.flags|=4)}e.ref!==null&&(e.flags|=512,e.flags|=2097152)}return gt(e),null;case 6:if(t&&e.stateNode!=null)Hy(t,e,t.memoizedProps,r);else{if(typeof r!="string"&&e.stateNode===null)throw Error(U(166));if(n=xs(sa.current),xs(Mn.current),ol(e)){if(r=e.stateNode,n=e.memoizedProps,r[Vn]=e,(i=r.nodeValue!==n)&&(t=zt,t!==null))switch(t.tag){case 3:il(r.nodeValue,n,(t.mode&1)!==0);break;case 5:t.memoizedProps.suppressHydrationWarning!==!0&&il(r.nodeValue,n,(t.mode&1)!==0)}i&&(e.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Vn]=e,e.stateNode=r}return gt(e),null;case 13:if(Ae(Ve),r=e.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(Re&&Ft!==null&&e.mode&1&&!(e.flags&128))uy(),Ai(),e.flags|=98560,i=!1;else if(i=ol(e),r!==null&&r.dehydrated!==null){if(t===null){if(!i)throw Error(U(318));if(i=e.memoizedState,i=i!==null?i.dehydrated:null,!i)throw Error(U(317));i[Vn]=e}else Ai(),!(e.flags&128)&&(e.memoizedState=null),e.flags|=4;gt(e),i=!1}else vn!==null&&(Wd(vn),vn=null),i=!0;if(!i)return e.flags&65536?e:null}return e.flags&128?(e.lanes=n,e):(r=r!==null,r!==(t!==null&&t.memoizedState!==null)&&r&&(e.child.flags|=8192,e.mode&1&&(t===null||Ve.current&1?Je===0&&(Je=3):uf())),e.updateQueue!==null&&(e.flags|=4),gt(e),null);case 4:return Ri(),Od(t,e),t===null&&ea(e.stateNode.containerInfo),gt(e),null;case 10:return Hh(e.type._context),gt(e),null;case 17:return Mt(e.type)&&Kl(),gt(e),null;case 19:if(Ae(Ve),i=e.memoizedState,i===null)return gt(e),null;if(r=(e.flags&128)!==0,o=i.rendering,o===null)if(r)wo(i,!1);else{if(Je!==0||t!==null&&t.flags&128)for(t=e.child;t!==null;){if(o=tu(t),o!==null){for(e.flags|=128,wo(i,!1),r=o.updateQueue,r!==null&&(e.updateQueue=r,e.flags|=4),e.subtreeFlags=0,r=n,n=e.child;n!==null;)i=n,t=r,i.flags&=14680066,o=i.alternate,o===null?(i.childLanes=0,i.lanes=t,i.child=null,i.subtreeFlags=0,i.memoizedProps=null,i.memoizedState=null,i.updateQueue=null,i.dependencies=null,i.stateNode=null):(i.childLanes=o.childLanes,i.lanes=o.lanes,i.child=o.child,i.subtreeFlags=0,i.deletions=null,i.memoizedProps=o.memoizedProps,i.memoizedState=o.memoizedState,i.updateQueue=o.updateQueue,i.type=o.type,t=o.dependencies,i.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),n=n.sibling;return Ee(Ve,Ve.current&1|2),e.child}t=t.sibling}i.tail!==null&&$e()>Ni&&(e.flags|=128,r=!0,wo(i,!1),e.lanes=4194304)}else{if(!r)if(t=tu(o),t!==null){if(e.flags|=128,r=!0,n=t.updateQueue,n!==null&&(e.updateQueue=n,e.flags|=4),wo(i,!0),i.tail===null&&i.tailMode==="hidden"&&!o.alternate&&!Re)return gt(e),null}else 2*$e()-i.renderingStartTime>Ni&&n!==1073741824&&(e.flags|=128,r=!0,wo(i,!1),e.lanes=4194304);i.isBackwards?(o.sibling=e.child,e.child=o):(n=i.last,n!==null?n.sibling=o:e.child=o,i.last=o)}return i.tail!==null?(e=i.tail,i.rendering=e,i.tail=e.sibling,i.renderingStartTime=$e(),e.sibling=null,n=Ve.current,Ee(Ve,r?n&1|2:n&1),e):(gt(e),null);case 22:case 23:return lf(),r=e.memoizedState!==null,t!==null&&t.memoizedState!==null!==r&&(e.flags|=8192),r&&e.mode&1?Ot&1073741824&&(gt(e),e.subtreeFlags&6&&(e.flags|=8192)):gt(e),null;case 24:return null;case 25:return null}throw Error(U(156,e.tag))}function wx(t,e){switch(Uh(e),e.tag){case 1:return Mt(e.type)&&Kl(),t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 3:return Ri(),Ae(Dt),Ae(xt),Yh(),t=e.flags,t&65536&&!(t&128)?(e.flags=t&-65537|128,e):null;case 5:return Qh(e),null;case 13:if(Ae(Ve),t=e.memoizedState,t!==null&&t.dehydrated!==null){if(e.alternate===null)throw Error(U(340));Ai()}return t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 19:return Ae(Ve),null;case 4:return Ri(),null;case 10:return Hh(e.type._context),null;case 22:case 23:return lf(),null;case 24:return null;default:return null}}var ul=!1,_t=!1,xx=typeof WeakSet=="function"?WeakSet:Set,Q=null;function hi(t,e){var n=t.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){ze(t,e,r)}else n.current=null}function Fd(t,e,n){try{n()}catch(r){ze(t,e,r)}}var ym=!1;function Ex(t,e){if(Ed=ql,t=Y0(),Fh(t)){if("selectionStart"in t)var n={start:t.selectionStart,end:t.selectionEnd};else e:{n=(n=t.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var s=r.anchorOffset,i=r.focusNode;r=r.focusOffset;try{n.nodeType,i.nodeType}catch{n=null;break e}var o=0,l=-1,u=-1,d=0,f=0,m=t,v=null;t:for(;;){for(var I;m!==n||s!==0&&m.nodeType!==3||(l=o+s),m!==i||r!==0&&m.nodeType!==3||(u=o+r),m.nodeType===3&&(o+=m.nodeValue.length),(I=m.firstChild)!==null;)v=m,m=I;for(;;){if(m===t)break t;if(v===n&&++d===s&&(l=o),v===i&&++f===r&&(u=o),(I=m.nextSibling)!==null)break;m=v,v=m.parentNode}m=I}n=l===-1||u===-1?null:{start:l,end:u}}else n=null}n=n||{start:0,end:0}}else n=null;for(Td={focusedElem:t,selectionRange:n},ql=!1,Q=e;Q!==null;)if(e=Q,t=e.child,(e.subtreeFlags&1028)!==0&&t!==null)t.return=e,Q=t;else for(;Q!==null;){e=Q;try{var A=e.alternate;if(e.flags&1024)switch(e.tag){case 0:case 11:case 15:break;case 1:if(A!==null){var P=A.memoizedProps,M=A.memoizedState,S=e.stateNode,x=S.getSnapshotBeforeUpdate(e.elementType===e.type?P:gn(e.type,P),M);S.__reactInternalSnapshotBeforeUpdate=x}break;case 3:var k=e.stateNode.containerInfo;k.nodeType===1?k.textContent="":k.nodeType===9&&k.documentElement&&k.removeChild(k.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(U(163))}}catch(V){ze(e,e.return,V)}if(t=e.sibling,t!==null){t.return=e.return,Q=t;break}Q=e.return}return A=ym,ym=!1,A}function Oo(t,e,n){var r=e.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var s=r=r.next;do{if((s.tag&t)===t){var i=s.destroy;s.destroy=void 0,i!==void 0&&Fd(e,n,i)}s=s.next}while(s!==r)}}function ju(t,e){if(e=e.updateQueue,e=e!==null?e.lastEffect:null,e!==null){var n=e=e.next;do{if((n.tag&t)===t){var r=n.create;n.destroy=r()}n=n.next}while(n!==e)}}function zd(t){var e=t.ref;if(e!==null){var n=t.stateNode;switch(t.tag){case 5:t=n;break;default:t=n}typeof e=="function"?e(t):e.current=t}}function Wy(t){var e=t.alternate;e!==null&&(t.alternate=null,Wy(e)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(e=t.stateNode,e!==null&&(delete e[Vn],delete e[na],delete e[kd],delete e[sx],delete e[ix])),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}function Gy(t){return t.tag===5||t.tag===3||t.tag===4}function vm(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||Gy(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function Ud(t,e,n){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?n.nodeType===8?n.parentNode.insertBefore(t,e):n.insertBefore(t,e):(n.nodeType===8?(e=n.parentNode,e.insertBefore(t,n)):(e=n,e.appendChild(t)),n=n._reactRootContainer,n!=null||e.onclick!==null||(e.onclick=Gl));else if(r!==4&&(t=t.child,t!==null))for(Ud(t,e,n),t=t.sibling;t!==null;)Ud(t,e,n),t=t.sibling}function Bd(t,e,n){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?n.insertBefore(t,e):n.appendChild(t);else if(r!==4&&(t=t.child,t!==null))for(Bd(t,e,n),t=t.sibling;t!==null;)Bd(t,e,n),t=t.sibling}var ut=null,yn=!1;function wr(t,e,n){for(n=n.child;n!==null;)Ky(t,e,n),n=n.sibling}function Ky(t,e,n){if(Dn&&typeof Dn.onCommitFiberUnmount=="function")try{Dn.onCommitFiberUnmount(Cu,n)}catch{}switch(n.tag){case 5:_t||hi(n,e);case 6:var r=ut,s=yn;ut=null,wr(t,e,n),ut=r,yn=s,ut!==null&&(yn?(t=ut,n=n.stateNode,t.nodeType===8?t.parentNode.removeChild(n):t.removeChild(n)):ut.removeChild(n.stateNode));break;case 18:ut!==null&&(yn?(t=ut,n=n.stateNode,t.nodeType===8?Vc(t.parentNode,n):t.nodeType===1&&Vc(t,n),Xo(t)):Vc(ut,n.stateNode));break;case 4:r=ut,s=yn,ut=n.stateNode.containerInfo,yn=!0,wr(t,e,n),ut=r,yn=s;break;case 0:case 11:case 14:case 15:if(!_t&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){s=r=r.next;do{var i=s,o=i.destroy;i=i.tag,o!==void 0&&(i&2||i&4)&&Fd(n,e,o),s=s.next}while(s!==r)}wr(t,e,n);break;case 1:if(!_t&&(hi(n,e),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(l){ze(n,e,l)}wr(t,e,n);break;case 21:wr(t,e,n);break;case 22:n.mode&1?(_t=(r=_t)||n.memoizedState!==null,wr(t,e,n),_t=r):wr(t,e,n);break;default:wr(t,e,n)}}function _m(t){var e=t.updateQueue;if(e!==null){t.updateQueue=null;var n=t.stateNode;n===null&&(n=t.stateNode=new xx),e.forEach(function(r){var s=Px.bind(null,t,r);n.has(r)||(n.add(r),r.then(s,s))})}}function mn(t,e){var n=e.deletions;if(n!==null)for(var r=0;r<n.length;r++){var s=n[r];try{var i=t,o=e,l=o;e:for(;l!==null;){switch(l.tag){case 5:ut=l.stateNode,yn=!1;break e;case 3:ut=l.stateNode.containerInfo,yn=!0;break e;case 4:ut=l.stateNode.containerInfo,yn=!0;break e}l=l.return}if(ut===null)throw Error(U(160));Ky(i,o,s),ut=null,yn=!1;var u=s.alternate;u!==null&&(u.return=null),s.return=null}catch(d){ze(s,e,d)}}if(e.subtreeFlags&12854)for(e=e.child;e!==null;)Qy(e,t),e=e.sibling}function Qy(t,e){var n=t.alternate,r=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:if(mn(e,t),Rn(t),r&4){try{Oo(3,t,t.return),ju(3,t)}catch(P){ze(t,t.return,P)}try{Oo(5,t,t.return)}catch(P){ze(t,t.return,P)}}break;case 1:mn(e,t),Rn(t),r&512&&n!==null&&hi(n,n.return);break;case 5:if(mn(e,t),Rn(t),r&512&&n!==null&&hi(n,n.return),t.flags&32){var s=t.stateNode;try{Go(s,"")}catch(P){ze(t,t.return,P)}}if(r&4&&(s=t.stateNode,s!=null)){var i=t.memoizedProps,o=n!==null?n.memoizedProps:i,l=t.type,u=t.updateQueue;if(t.updateQueue=null,u!==null)try{l==="input"&&i.type==="radio"&&i.name!=null&&y0(s,i),hd(l,o);var d=hd(l,i);for(o=0;o<u.length;o+=2){var f=u[o],m=u[o+1];f==="style"?E0(s,m):f==="dangerouslySetInnerHTML"?w0(s,m):f==="children"?Go(s,m):kh(s,f,m,d)}switch(l){case"input":ad(s,i);break;case"textarea":v0(s,i);break;case"select":var v=s._wrapperState.wasMultiple;s._wrapperState.wasMultiple=!!i.multiple;var I=i.value;I!=null?mi(s,!!i.multiple,I,!1):v!==!!i.multiple&&(i.defaultValue!=null?mi(s,!!i.multiple,i.defaultValue,!0):mi(s,!!i.multiple,i.multiple?[]:"",!1))}s[na]=i}catch(P){ze(t,t.return,P)}}break;case 6:if(mn(e,t),Rn(t),r&4){if(t.stateNode===null)throw Error(U(162));s=t.stateNode,i=t.memoizedProps;try{s.nodeValue=i}catch(P){ze(t,t.return,P)}}break;case 3:if(mn(e,t),Rn(t),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Xo(e.containerInfo)}catch(P){ze(t,t.return,P)}break;case 4:mn(e,t),Rn(t);break;case 13:mn(e,t),Rn(t),s=t.child,s.flags&8192&&(i=s.memoizedState!==null,s.stateNode.isHidden=i,!i||s.alternate!==null&&s.alternate.memoizedState!==null||(of=$e())),r&4&&_m(t);break;case 22:if(f=n!==null&&n.memoizedState!==null,t.mode&1?(_t=(d=_t)||f,mn(e,t),_t=d):mn(e,t),Rn(t),r&8192){if(d=t.memoizedState!==null,(t.stateNode.isHidden=d)&&!f&&t.mode&1)for(Q=t,f=t.child;f!==null;){for(m=Q=f;Q!==null;){switch(v=Q,I=v.child,v.tag){case 0:case 11:case 14:case 15:Oo(4,v,v.return);break;case 1:hi(v,v.return);var A=v.stateNode;if(typeof A.componentWillUnmount=="function"){r=v,n=v.return;try{e=r,A.props=e.memoizedProps,A.state=e.memoizedState,A.componentWillUnmount()}catch(P){ze(r,n,P)}}break;case 5:hi(v,v.return);break;case 22:if(v.memoizedState!==null){xm(m);continue}}I!==null?(I.return=v,Q=I):xm(m)}f=f.sibling}e:for(f=null,m=t;;){if(m.tag===5){if(f===null){f=m;try{s=m.stateNode,d?(i=s.style,typeof i.setProperty=="function"?i.setProperty("display","none","important"):i.display="none"):(l=m.stateNode,u=m.memoizedProps.style,o=u!=null&&u.hasOwnProperty("display")?u.display:null,l.style.display=x0("display",o))}catch(P){ze(t,t.return,P)}}}else if(m.tag===6){if(f===null)try{m.stateNode.nodeValue=d?"":m.memoizedProps}catch(P){ze(t,t.return,P)}}else if((m.tag!==22&&m.tag!==23||m.memoizedState===null||m===t)&&m.child!==null){m.child.return=m,m=m.child;continue}if(m===t)break e;for(;m.sibling===null;){if(m.return===null||m.return===t)break e;f===m&&(f=null),m=m.return}f===m&&(f=null),m.sibling.return=m.return,m=m.sibling}}break;case 19:mn(e,t),Rn(t),r&4&&_m(t);break;case 21:break;default:mn(e,t),Rn(t)}}function Rn(t){var e=t.flags;if(e&2){try{e:{for(var n=t.return;n!==null;){if(Gy(n)){var r=n;break e}n=n.return}throw Error(U(160))}switch(r.tag){case 5:var s=r.stateNode;r.flags&32&&(Go(s,""),r.flags&=-33);var i=vm(t);Bd(t,i,s);break;case 3:case 4:var o=r.stateNode.containerInfo,l=vm(t);Ud(t,l,o);break;default:throw Error(U(161))}}catch(u){ze(t,t.return,u)}t.flags&=-3}e&4096&&(t.flags&=-4097)}function Tx(t,e,n){Q=t,Yy(t)}function Yy(t,e,n){for(var r=(t.mode&1)!==0;Q!==null;){var s=Q,i=s.child;if(s.tag===22&&r){var o=s.memoizedState!==null||ul;if(!o){var l=s.alternate,u=l!==null&&l.memoizedState!==null||_t;l=ul;var d=_t;if(ul=o,(_t=u)&&!d)for(Q=s;Q!==null;)o=Q,u=o.child,o.tag===22&&o.memoizedState!==null?Em(s):u!==null?(u.return=o,Q=u):Em(s);for(;i!==null;)Q=i,Yy(i),i=i.sibling;Q=s,ul=l,_t=d}wm(t)}else s.subtreeFlags&8772&&i!==null?(i.return=s,Q=i):wm(t)}}function wm(t){for(;Q!==null;){var e=Q;if(e.flags&8772){var n=e.alternate;try{if(e.flags&8772)switch(e.tag){case 0:case 11:case 15:_t||ju(5,e);break;case 1:var r=e.stateNode;if(e.flags&4&&!_t)if(n===null)r.componentDidMount();else{var s=e.elementType===e.type?n.memoizedProps:gn(e.type,n.memoizedProps);r.componentDidUpdate(s,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var i=e.updateQueue;i!==null&&sm(e,i,r);break;case 3:var o=e.updateQueue;if(o!==null){if(n=null,e.child!==null)switch(e.child.tag){case 5:n=e.child.stateNode;break;case 1:n=e.child.stateNode}sm(e,o,n)}break;case 5:var l=e.stateNode;if(n===null&&e.flags&4){n=l;var u=e.memoizedProps;switch(e.type){case"button":case"input":case"select":case"textarea":u.autoFocus&&n.focus();break;case"img":u.src&&(n.src=u.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(e.memoizedState===null){var d=e.alternate;if(d!==null){var f=d.memoizedState;if(f!==null){var m=f.dehydrated;m!==null&&Xo(m)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(U(163))}_t||e.flags&512&&zd(e)}catch(v){ze(e,e.return,v)}}if(e===t){Q=null;break}if(n=e.sibling,n!==null){n.return=e.return,Q=n;break}Q=e.return}}function xm(t){for(;Q!==null;){var e=Q;if(e===t){Q=null;break}var n=e.sibling;if(n!==null){n.return=e.return,Q=n;break}Q=e.return}}function Em(t){for(;Q!==null;){var e=Q;try{switch(e.tag){case 0:case 11:case 15:var n=e.return;try{ju(4,e)}catch(u){ze(e,n,u)}break;case 1:var r=e.stateNode;if(typeof r.componentDidMount=="function"){var s=e.return;try{r.componentDidMount()}catch(u){ze(e,s,u)}}var i=e.return;try{zd(e)}catch(u){ze(e,i,u)}break;case 5:var o=e.return;try{zd(e)}catch(u){ze(e,o,u)}}}catch(u){ze(e,e.return,u)}if(e===t){Q=null;break}var l=e.sibling;if(l!==null){l.return=e.return,Q=l;break}Q=e.return}}var bx=Math.ceil,su=sr.ReactCurrentDispatcher,rf=sr.ReactCurrentOwner,sn=sr.ReactCurrentBatchConfig,me=0,lt=null,We=null,ht=0,Ot=0,fi=Xr(0),Je=0,la=null,Cs=0,Ou=0,sf=0,Fo=null,Nt=null,of=0,Ni=1/0,Hn=null,iu=!1,$d=null,Dr=null,cl=!1,Ir=null,ou=0,zo=0,qd=null,Rl=-1,Pl=0;function kt(){return me&6?$e():Rl!==-1?Rl:Rl=$e()}function Mr(t){return t.mode&1?me&2&&ht!==0?ht&-ht:ax.transition!==null?(Pl===0&&(Pl=D0()),Pl):(t=ve,t!==0||(t=window.event,t=t===void 0?16:U0(t.type)),t):1}function xn(t,e,n,r){if(50<zo)throw zo=0,qd=null,Error(U(185));Ea(t,n,r),(!(me&2)||t!==lt)&&(t===lt&&(!(me&2)&&(Ou|=n),Je===4&&Sr(t,ht)),Lt(t,r),n===1&&me===0&&!(e.mode&1)&&(Ni=$e()+500,Du&&Jr()))}function Lt(t,e){var n=t.callbackNode;aw(t,e);var r=$l(t,t===lt?ht:0);if(r===0)n!==null&&Pp(n),t.callbackNode=null,t.callbackPriority=0;else if(e=r&-r,t.callbackPriority!==e){if(n!=null&&Pp(n),e===1)t.tag===0?ox(Tm.bind(null,t)):oy(Tm.bind(null,t)),nx(function(){!(me&6)&&Jr()}),n=null;else{switch(M0(r)){case 1:n=Ph;break;case 4:n=N0;break;case 16:n=Bl;break;case 536870912:n=V0;break;default:n=Bl}n=sv(n,Xy.bind(null,t))}t.callbackPriority=e,t.callbackNode=n}}function Xy(t,e){if(Rl=-1,Pl=0,me&6)throw Error(U(327));var n=t.callbackNode;if(wi()&&t.callbackNode!==n)return null;var r=$l(t,t===lt?ht:0);if(r===0)return null;if(r&30||r&t.expiredLanes||e)e=au(t,r);else{e=r;var s=me;me|=2;var i=Zy();(lt!==t||ht!==e)&&(Hn=null,Ni=$e()+500,bs(t,e));do try{Ix();break}catch(l){Jy(t,l)}while(!0);qh(),su.current=i,me=s,We!==null?e=0:(lt=null,ht=0,e=Je)}if(e!==0){if(e===2&&(s=yd(t),s!==0&&(r=s,e=Hd(t,s))),e===1)throw n=la,bs(t,0),Sr(t,r),Lt(t,$e()),n;if(e===6)Sr(t,r);else{if(s=t.current.alternate,!(r&30)&&!Sx(s)&&(e=au(t,r),e===2&&(i=yd(t),i!==0&&(r=i,e=Hd(t,i))),e===1))throw n=la,bs(t,0),Sr(t,r),Lt(t,$e()),n;switch(t.finishedWork=s,t.finishedLanes=r,e){case 0:case 1:throw Error(U(345));case 2:ys(t,Nt,Hn);break;case 3:if(Sr(t,r),(r&130023424)===r&&(e=of+500-$e(),10<e)){if($l(t,0)!==0)break;if(s=t.suspendedLanes,(s&r)!==r){kt(),t.pingedLanes|=t.suspendedLanes&s;break}t.timeoutHandle=Sd(ys.bind(null,t,Nt,Hn),e);break}ys(t,Nt,Hn);break;case 4:if(Sr(t,r),(r&4194240)===r)break;for(e=t.eventTimes,s=-1;0<r;){var o=31-wn(r);i=1<<o,o=e[o],o>s&&(s=o),r&=~i}if(r=s,r=$e()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*bx(r/1960))-r,10<r){t.timeoutHandle=Sd(ys.bind(null,t,Nt,Hn),r);break}ys(t,Nt,Hn);break;case 5:ys(t,Nt,Hn);break;default:throw Error(U(329))}}}return Lt(t,$e()),t.callbackNode===n?Xy.bind(null,t):null}function Hd(t,e){var n=Fo;return t.current.memoizedState.isDehydrated&&(bs(t,e).flags|=256),t=au(t,e),t!==2&&(e=Nt,Nt=n,e!==null&&Wd(e)),t}function Wd(t){Nt===null?Nt=t:Nt.push.apply(Nt,t)}function Sx(t){for(var e=t;;){if(e.flags&16384){var n=e.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var s=n[r],i=s.getSnapshot;s=s.value;try{if(!Tn(i(),s))return!1}catch{return!1}}}if(n=e.child,e.subtreeFlags&16384&&n!==null)n.return=e,e=n;else{if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return!0;e=e.return}e.sibling.return=e.return,e=e.sibling}}return!0}function Sr(t,e){for(e&=~sf,e&=~Ou,t.suspendedLanes|=e,t.pingedLanes&=~e,t=t.expirationTimes;0<e;){var n=31-wn(e),r=1<<n;t[n]=-1,e&=~r}}function Tm(t){if(me&6)throw Error(U(327));wi();var e=$l(t,0);if(!(e&1))return Lt(t,$e()),null;var n=au(t,e);if(t.tag!==0&&n===2){var r=yd(t);r!==0&&(e=r,n=Hd(t,r))}if(n===1)throw n=la,bs(t,0),Sr(t,e),Lt(t,$e()),n;if(n===6)throw Error(U(345));return t.finishedWork=t.current.alternate,t.finishedLanes=e,ys(t,Nt,Hn),Lt(t,$e()),null}function af(t,e){var n=me;me|=1;try{return t(e)}finally{me=n,me===0&&(Ni=$e()+500,Du&&Jr())}}function Rs(t){Ir!==null&&Ir.tag===0&&!(me&6)&&wi();var e=me;me|=1;var n=sn.transition,r=ve;try{if(sn.transition=null,ve=1,t)return t()}finally{ve=r,sn.transition=n,me=e,!(me&6)&&Jr()}}function lf(){Ot=fi.current,Ae(fi)}function bs(t,e){t.finishedWork=null,t.finishedLanes=0;var n=t.timeoutHandle;if(n!==-1&&(t.timeoutHandle=-1,tx(n)),We!==null)for(n=We.return;n!==null;){var r=n;switch(Uh(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Kl();break;case 3:Ri(),Ae(Dt),Ae(xt),Yh();break;case 5:Qh(r);break;case 4:Ri();break;case 13:Ae(Ve);break;case 19:Ae(Ve);break;case 10:Hh(r.type._context);break;case 22:case 23:lf()}n=n.return}if(lt=t,We=t=Lr(t.current,null),ht=Ot=e,Je=0,la=null,sf=Ou=Cs=0,Nt=Fo=null,ws!==null){for(e=0;e<ws.length;e++)if(n=ws[e],r=n.interleaved,r!==null){n.interleaved=null;var s=r.next,i=n.pending;if(i!==null){var o=i.next;i.next=s,r.next=o}n.pending=r}ws=null}return t}function Jy(t,e){do{var n=We;try{if(qh(),Il.current=ru,nu){for(var r=De.memoizedState;r!==null;){var s=r.queue;s!==null&&(s.pending=null),r=r.next}nu=!1}if(As=0,ot=Xe=De=null,jo=!1,ia=0,rf.current=null,n===null||n.return===null){Je=1,la=e,We=null;break}e:{var i=t,o=n.return,l=n,u=e;if(e=ht,l.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){var d=u,f=l,m=f.tag;if(!(f.mode&1)&&(m===0||m===11||m===15)){var v=f.alternate;v?(f.updateQueue=v.updateQueue,f.memoizedState=v.memoizedState,f.lanes=v.lanes):(f.updateQueue=null,f.memoizedState=null)}var I=cm(o);if(I!==null){I.flags&=-257,dm(I,o,l,i,e),I.mode&1&&um(i,d,e),e=I,u=d;var A=e.updateQueue;if(A===null){var P=new Set;P.add(u),e.updateQueue=P}else A.add(u);break e}else{if(!(e&1)){um(i,d,e),uf();break e}u=Error(U(426))}}else if(Re&&l.mode&1){var M=cm(o);if(M!==null){!(M.flags&65536)&&(M.flags|=256),dm(M,o,l,i,e),Bh(Pi(u,l));break e}}i=u=Pi(u,l),Je!==4&&(Je=2),Fo===null?Fo=[i]:Fo.push(i),i=o;do{switch(i.tag){case 3:i.flags|=65536,e&=-e,i.lanes|=e;var S=My(i,u,e);rm(i,S);break e;case 1:l=u;var x=i.type,k=i.stateNode;if(!(i.flags&128)&&(typeof x.getDerivedStateFromError=="function"||k!==null&&typeof k.componentDidCatch=="function"&&(Dr===null||!Dr.has(k)))){i.flags|=65536,e&=-e,i.lanes|=e;var V=Ly(i,l,e);rm(i,V);break e}}i=i.return}while(i!==null)}tv(n)}catch(F){e=F,We===n&&n!==null&&(We=n=n.return);continue}break}while(!0)}function Zy(){var t=su.current;return su.current=ru,t===null?ru:t}function uf(){(Je===0||Je===3||Je===2)&&(Je=4),lt===null||!(Cs&268435455)&&!(Ou&268435455)||Sr(lt,ht)}function au(t,e){var n=me;me|=2;var r=Zy();(lt!==t||ht!==e)&&(Hn=null,bs(t,e));do try{kx();break}catch(s){Jy(t,s)}while(!0);if(qh(),me=n,su.current=r,We!==null)throw Error(U(261));return lt=null,ht=0,Je}function kx(){for(;We!==null;)ev(We)}function Ix(){for(;We!==null&&!J_();)ev(We)}function ev(t){var e=rv(t.alternate,t,Ot);t.memoizedProps=t.pendingProps,e===null?tv(t):We=e,rf.current=null}function tv(t){var e=t;do{var n=e.alternate;if(t=e.return,e.flags&32768){if(n=wx(n,e),n!==null){n.flags&=32767,We=n;return}if(t!==null)t.flags|=32768,t.subtreeFlags=0,t.deletions=null;else{Je=6,We=null;return}}else if(n=_x(n,e,Ot),n!==null){We=n;return}if(e=e.sibling,e!==null){We=e;return}We=e=t}while(e!==null);Je===0&&(Je=5)}function ys(t,e,n){var r=ve,s=sn.transition;try{sn.transition=null,ve=1,Ax(t,e,n,r)}finally{sn.transition=s,ve=r}return null}function Ax(t,e,n,r){do wi();while(Ir!==null);if(me&6)throw Error(U(327));n=t.finishedWork;var s=t.finishedLanes;if(n===null)return null;if(t.finishedWork=null,t.finishedLanes=0,n===t.current)throw Error(U(177));t.callbackNode=null,t.callbackPriority=0;var i=n.lanes|n.childLanes;if(lw(t,i),t===lt&&(We=lt=null,ht=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||cl||(cl=!0,sv(Bl,function(){return wi(),null})),i=(n.flags&15990)!==0,n.subtreeFlags&15990||i){i=sn.transition,sn.transition=null;var o=ve;ve=1;var l=me;me|=4,rf.current=null,Ex(t,n),Qy(n,t),Kw(Td),ql=!!Ed,Td=Ed=null,t.current=n,Tx(n),Z_(),me=l,ve=o,sn.transition=i}else t.current=n;if(cl&&(cl=!1,Ir=t,ou=s),i=t.pendingLanes,i===0&&(Dr=null),nw(n.stateNode),Lt(t,$e()),e!==null)for(r=t.onRecoverableError,n=0;n<e.length;n++)s=e[n],r(s.value,{componentStack:s.stack,digest:s.digest});if(iu)throw iu=!1,t=$d,$d=null,t;return ou&1&&t.tag!==0&&wi(),i=t.pendingLanes,i&1?t===qd?zo++:(zo=0,qd=t):zo=0,Jr(),null}function wi(){if(Ir!==null){var t=M0(ou),e=sn.transition,n=ve;try{if(sn.transition=null,ve=16>t?16:t,Ir===null)var r=!1;else{if(t=Ir,Ir=null,ou=0,me&6)throw Error(U(331));var s=me;for(me|=4,Q=t.current;Q!==null;){var i=Q,o=i.child;if(Q.flags&16){var l=i.deletions;if(l!==null){for(var u=0;u<l.length;u++){var d=l[u];for(Q=d;Q!==null;){var f=Q;switch(f.tag){case 0:case 11:case 15:Oo(8,f,i)}var m=f.child;if(m!==null)m.return=f,Q=m;else for(;Q!==null;){f=Q;var v=f.sibling,I=f.return;if(Wy(f),f===d){Q=null;break}if(v!==null){v.return=I,Q=v;break}Q=I}}}var A=i.alternate;if(A!==null){var P=A.child;if(P!==null){A.child=null;do{var M=P.sibling;P.sibling=null,P=M}while(P!==null)}}Q=i}}if(i.subtreeFlags&2064&&o!==null)o.return=i,Q=o;else e:for(;Q!==null;){if(i=Q,i.flags&2048)switch(i.tag){case 0:case 11:case 15:Oo(9,i,i.return)}var S=i.sibling;if(S!==null){S.return=i.return,Q=S;break e}Q=i.return}}var x=t.current;for(Q=x;Q!==null;){o=Q;var k=o.child;if(o.subtreeFlags&2064&&k!==null)k.return=o,Q=k;else e:for(o=x;Q!==null;){if(l=Q,l.flags&2048)try{switch(l.tag){case 0:case 11:case 15:ju(9,l)}}catch(F){ze(l,l.return,F)}if(l===o){Q=null;break e}var V=l.sibling;if(V!==null){V.return=l.return,Q=V;break e}Q=l.return}}if(me=s,Jr(),Dn&&typeof Dn.onPostCommitFiberRoot=="function")try{Dn.onPostCommitFiberRoot(Cu,t)}catch{}r=!0}return r}finally{ve=n,sn.transition=e}}return!1}function bm(t,e,n){e=Pi(n,e),e=My(t,e,1),t=Vr(t,e,1),e=kt(),t!==null&&(Ea(t,1,e),Lt(t,e))}function ze(t,e,n){if(t.tag===3)bm(t,t,n);else for(;e!==null;){if(e.tag===3){bm(e,t,n);break}else if(e.tag===1){var r=e.stateNode;if(typeof e.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(Dr===null||!Dr.has(r))){t=Pi(n,t),t=Ly(e,t,1),e=Vr(e,t,1),t=kt(),e!==null&&(Ea(e,1,t),Lt(e,t));break}}e=e.return}}function Cx(t,e,n){var r=t.pingCache;r!==null&&r.delete(e),e=kt(),t.pingedLanes|=t.suspendedLanes&n,lt===t&&(ht&n)===n&&(Je===4||Je===3&&(ht&130023424)===ht&&500>$e()-of?bs(t,0):sf|=n),Lt(t,e)}function nv(t,e){e===0&&(t.mode&1?(e=el,el<<=1,!(el&130023424)&&(el=4194304)):e=1);var n=kt();t=Zn(t,e),t!==null&&(Ea(t,e,n),Lt(t,n))}function Rx(t){var e=t.memoizedState,n=0;e!==null&&(n=e.retryLane),nv(t,n)}function Px(t,e){var n=0;switch(t.tag){case 13:var r=t.stateNode,s=t.memoizedState;s!==null&&(n=s.retryLane);break;case 19:r=t.stateNode;break;default:throw Error(U(314))}r!==null&&r.delete(e),nv(t,n)}var rv;rv=function(t,e,n){if(t!==null)if(t.memoizedProps!==e.pendingProps||Dt.current)Vt=!0;else{if(!(t.lanes&n)&&!(e.flags&128))return Vt=!1,vx(t,e,n);Vt=!!(t.flags&131072)}else Vt=!1,Re&&e.flags&1048576&&ay(e,Xl,e.index);switch(e.lanes=0,e.tag){case 2:var r=e.type;Cl(t,e),t=e.pendingProps;var s=Ii(e,xt.current);_i(e,n),s=Jh(null,e,r,t,s,n);var i=Zh();return e.flags|=1,typeof s=="object"&&s!==null&&typeof s.render=="function"&&s.$$typeof===void 0?(e.tag=1,e.memoizedState=null,e.updateQueue=null,Mt(r)?(i=!0,Ql(e)):i=!1,e.memoizedState=s.state!==null&&s.state!==void 0?s.state:null,Gh(e),s.updater=Lu,e.stateNode=s,s._reactInternals=e,Nd(e,r,t,n),e=Md(null,e,r,!0,i,n)):(e.tag=0,Re&&i&&zh(e),St(null,e,s,n),e=e.child),e;case 16:r=e.elementType;e:{switch(Cl(t,e),t=e.pendingProps,s=r._init,r=s(r._payload),e.type=r,s=e.tag=Vx(r),t=gn(r,t),s){case 0:e=Dd(null,e,r,t,n);break e;case 1:e=pm(null,e,r,t,n);break e;case 11:e=hm(null,e,r,t,n);break e;case 14:e=fm(null,e,r,gn(r.type,t),n);break e}throw Error(U(306,r,""))}return e;case 0:return r=e.type,s=e.pendingProps,s=e.elementType===r?s:gn(r,s),Dd(t,e,r,s,n);case 1:return r=e.type,s=e.pendingProps,s=e.elementType===r?s:gn(r,s),pm(t,e,r,s,n);case 3:e:{if(zy(e),t===null)throw Error(U(387));r=e.pendingProps,i=e.memoizedState,s=i.element,fy(t,e),eu(e,r,null,n);var o=e.memoizedState;if(r=o.element,i.isDehydrated)if(i={element:r,isDehydrated:!1,cache:o.cache,pendingSuspenseBoundaries:o.pendingSuspenseBoundaries,transitions:o.transitions},e.updateQueue.baseState=i,e.memoizedState=i,e.flags&256){s=Pi(Error(U(423)),e),e=mm(t,e,r,n,s);break e}else if(r!==s){s=Pi(Error(U(424)),e),e=mm(t,e,r,n,s);break e}else for(Ft=Nr(e.stateNode.containerInfo.firstChild),zt=e,Re=!0,vn=null,n=dy(e,null,r,n),e.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(Ai(),r===s){e=er(t,e,n);break e}St(t,e,r,n)}e=e.child}return e;case 5:return py(e),t===null&&Cd(e),r=e.type,s=e.pendingProps,i=t!==null?t.memoizedProps:null,o=s.children,bd(r,s)?o=null:i!==null&&bd(r,i)&&(e.flags|=32),Fy(t,e),St(t,e,o,n),e.child;case 6:return t===null&&Cd(e),null;case 13:return Uy(t,e,n);case 4:return Kh(e,e.stateNode.containerInfo),r=e.pendingProps,t===null?e.child=Ci(e,null,r,n):St(t,e,r,n),e.child;case 11:return r=e.type,s=e.pendingProps,s=e.elementType===r?s:gn(r,s),hm(t,e,r,s,n);case 7:return St(t,e,e.pendingProps,n),e.child;case 8:return St(t,e,e.pendingProps.children,n),e.child;case 12:return St(t,e,e.pendingProps.children,n),e.child;case 10:e:{if(r=e.type._context,s=e.pendingProps,i=e.memoizedProps,o=s.value,Ee(Jl,r._currentValue),r._currentValue=o,i!==null)if(Tn(i.value,o)){if(i.children===s.children&&!Dt.current){e=er(t,e,n);break e}}else for(i=e.child,i!==null&&(i.return=e);i!==null;){var l=i.dependencies;if(l!==null){o=i.child;for(var u=l.firstContext;u!==null;){if(u.context===r){if(i.tag===1){u=Qn(-1,n&-n),u.tag=2;var d=i.updateQueue;if(d!==null){d=d.shared;var f=d.pending;f===null?u.next=u:(u.next=f.next,f.next=u),d.pending=u}}i.lanes|=n,u=i.alternate,u!==null&&(u.lanes|=n),Rd(i.return,n,e),l.lanes|=n;break}u=u.next}}else if(i.tag===10)o=i.type===e.type?null:i.child;else if(i.tag===18){if(o=i.return,o===null)throw Error(U(341));o.lanes|=n,l=o.alternate,l!==null&&(l.lanes|=n),Rd(o,n,e),o=i.sibling}else o=i.child;if(o!==null)o.return=i;else for(o=i;o!==null;){if(o===e){o=null;break}if(i=o.sibling,i!==null){i.return=o.return,o=i;break}o=o.return}i=o}St(t,e,s.children,n),e=e.child}return e;case 9:return s=e.type,r=e.pendingProps.children,_i(e,n),s=on(s),r=r(s),e.flags|=1,St(t,e,r,n),e.child;case 14:return r=e.type,s=gn(r,e.pendingProps),s=gn(r.type,s),fm(t,e,r,s,n);case 15:return jy(t,e,e.type,e.pendingProps,n);case 17:return r=e.type,s=e.pendingProps,s=e.elementType===r?s:gn(r,s),Cl(t,e),e.tag=1,Mt(r)?(t=!0,Ql(e)):t=!1,_i(e,n),Dy(e,r,s),Nd(e,r,s,n),Md(null,e,r,!0,t,n);case 19:return By(t,e,n);case 22:return Oy(t,e,n)}throw Error(U(156,e.tag))};function sv(t,e){return P0(t,e)}function Nx(t,e,n,r){this.tag=t,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=e,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function rn(t,e,n,r){return new Nx(t,e,n,r)}function cf(t){return t=t.prototype,!(!t||!t.isReactComponent)}function Vx(t){if(typeof t=="function")return cf(t)?1:0;if(t!=null){if(t=t.$$typeof,t===Ah)return 11;if(t===Ch)return 14}return 2}function Lr(t,e){var n=t.alternate;return n===null?(n=rn(t.tag,e,t.key,t.mode),n.elementType=t.elementType,n.type=t.type,n.stateNode=t.stateNode,n.alternate=t,t.alternate=n):(n.pendingProps=e,n.type=t.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=t.flags&14680064,n.childLanes=t.childLanes,n.lanes=t.lanes,n.child=t.child,n.memoizedProps=t.memoizedProps,n.memoizedState=t.memoizedState,n.updateQueue=t.updateQueue,e=t.dependencies,n.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext},n.sibling=t.sibling,n.index=t.index,n.ref=t.ref,n}function Nl(t,e,n,r,s,i){var o=2;if(r=t,typeof t=="function")cf(t)&&(o=1);else if(typeof t=="string")o=5;else e:switch(t){case ri:return Ss(n.children,s,i,e);case Ih:o=8,s|=8;break;case nd:return t=rn(12,n,e,s|2),t.elementType=nd,t.lanes=i,t;case rd:return t=rn(13,n,e,s),t.elementType=rd,t.lanes=i,t;case sd:return t=rn(19,n,e,s),t.elementType=sd,t.lanes=i,t;case p0:return Fu(n,s,i,e);default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case h0:o=10;break e;case f0:o=9;break e;case Ah:o=11;break e;case Ch:o=14;break e;case Er:o=16,r=null;break e}throw Error(U(130,t==null?t:typeof t,""))}return e=rn(o,n,e,s),e.elementType=t,e.type=r,e.lanes=i,e}function Ss(t,e,n,r){return t=rn(7,t,r,e),t.lanes=n,t}function Fu(t,e,n,r){return t=rn(22,t,r,e),t.elementType=p0,t.lanes=n,t.stateNode={isHidden:!1},t}function Uc(t,e,n){return t=rn(6,t,null,e),t.lanes=n,t}function Bc(t,e,n){return e=rn(4,t.children!==null?t.children:[],t.key,e),e.lanes=n,e.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},e}function Dx(t,e,n,r,s){this.tag=e,this.containerInfo=t,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Ec(0),this.expirationTimes=Ec(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ec(0),this.identifierPrefix=r,this.onRecoverableError=s,this.mutableSourceEagerHydrationData=null}function df(t,e,n,r,s,i,o,l,u){return t=new Dx(t,e,n,l,u),e===1?(e=1,i===!0&&(e|=8)):e=0,i=rn(3,null,null,e),t.current=i,i.stateNode=t,i.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},Gh(i),t}function Mx(t,e,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:ni,key:r==null?null:""+r,children:t,containerInfo:e,implementation:n}}function iv(t){if(!t)return $r;t=t._reactInternals;e:{if(Ms(t)!==t||t.tag!==1)throw Error(U(170));var e=t;do{switch(e.tag){case 3:e=e.stateNode.context;break e;case 1:if(Mt(e.type)){e=e.stateNode.__reactInternalMemoizedMergedChildContext;break e}}e=e.return}while(e!==null);throw Error(U(171))}if(t.tag===1){var n=t.type;if(Mt(n))return iy(t,n,e)}return e}function ov(t,e,n,r,s,i,o,l,u){return t=df(n,r,!0,t,s,i,o,l,u),t.context=iv(null),n=t.current,r=kt(),s=Mr(n),i=Qn(r,s),i.callback=e??null,Vr(n,i,s),t.current.lanes=s,Ea(t,s,r),Lt(t,r),t}function zu(t,e,n,r){var s=e.current,i=kt(),o=Mr(s);return n=iv(n),e.context===null?e.context=n:e.pendingContext=n,e=Qn(i,o),e.payload={element:t},r=r===void 0?null:r,r!==null&&(e.callback=r),t=Vr(s,e,o),t!==null&&(xn(t,s,o,i),kl(t,s,o)),o}function lu(t){if(t=t.current,!t.child)return null;switch(t.child.tag){case 5:return t.child.stateNode;default:return t.child.stateNode}}function Sm(t,e){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var n=t.retryLane;t.retryLane=n!==0&&n<e?n:e}}function hf(t,e){Sm(t,e),(t=t.alternate)&&Sm(t,e)}function Lx(){return null}var av=typeof reportError=="function"?reportError:function(t){console.error(t)};function ff(t){this._internalRoot=t}Uu.prototype.render=ff.prototype.render=function(t){var e=this._internalRoot;if(e===null)throw Error(U(409));zu(t,e,null,null)};Uu.prototype.unmount=ff.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var e=t.containerInfo;Rs(function(){zu(null,t,null,null)}),e[Jn]=null}};function Uu(t){this._internalRoot=t}Uu.prototype.unstable_scheduleHydration=function(t){if(t){var e=O0();t={blockedOn:null,target:t,priority:e};for(var n=0;n<br.length&&e!==0&&e<br[n].priority;n++);br.splice(n,0,t),n===0&&z0(t)}};function pf(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function Bu(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11&&(t.nodeType!==8||t.nodeValue!==" react-mount-point-unstable "))}function km(){}function jx(t,e,n,r,s){if(s){if(typeof r=="function"){var i=r;r=function(){var d=lu(o);i.call(d)}}var o=ov(e,r,t,0,null,!1,!1,"",km);return t._reactRootContainer=o,t[Jn]=o.current,ea(t.nodeType===8?t.parentNode:t),Rs(),o}for(;s=t.lastChild;)t.removeChild(s);if(typeof r=="function"){var l=r;r=function(){var d=lu(u);l.call(d)}}var u=df(t,0,!1,null,null,!1,!1,"",km);return t._reactRootContainer=u,t[Jn]=u.current,ea(t.nodeType===8?t.parentNode:t),Rs(function(){zu(e,u,n,r)}),u}function $u(t,e,n,r,s){var i=n._reactRootContainer;if(i){var o=i;if(typeof s=="function"){var l=s;s=function(){var u=lu(o);l.call(u)}}zu(e,o,t,s)}else o=jx(n,e,t,s,r);return lu(o)}L0=function(t){switch(t.tag){case 3:var e=t.stateNode;if(e.current.memoizedState.isDehydrated){var n=ko(e.pendingLanes);n!==0&&(Nh(e,n|1),Lt(e,$e()),!(me&6)&&(Ni=$e()+500,Jr()))}break;case 13:Rs(function(){var r=Zn(t,1);if(r!==null){var s=kt();xn(r,t,1,s)}}),hf(t,1)}};Vh=function(t){if(t.tag===13){var e=Zn(t,134217728);if(e!==null){var n=kt();xn(e,t,134217728,n)}hf(t,134217728)}};j0=function(t){if(t.tag===13){var e=Mr(t),n=Zn(t,e);if(n!==null){var r=kt();xn(n,t,e,r)}hf(t,e)}};O0=function(){return ve};F0=function(t,e){var n=ve;try{return ve=t,e()}finally{ve=n}};pd=function(t,e,n){switch(e){case"input":if(ad(t,n),e=n.name,n.type==="radio"&&e!=null){for(n=t;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+e)+'][type="radio"]'),e=0;e<n.length;e++){var r=n[e];if(r!==t&&r.form===t.form){var s=Vu(r);if(!s)throw Error(U(90));g0(r),ad(r,s)}}}break;case"textarea":v0(t,n);break;case"select":e=n.value,e!=null&&mi(t,!!n.multiple,e,!1)}};S0=af;k0=Rs;var Ox={usingClientEntryPoint:!1,Events:[ba,ai,Vu,T0,b0,af]},xo={findFiberByHostInstance:_s,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Fx={bundleType:xo.bundleType,version:xo.version,rendererPackageName:xo.rendererPackageName,rendererConfig:xo.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:sr.ReactCurrentDispatcher,findHostInstanceByFiber:function(t){return t=C0(t),t===null?null:t.stateNode},findFiberByHostInstance:xo.findFiberByHostInstance||Lx,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var dl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!dl.isDisabled&&dl.supportsFiber)try{Cu=dl.inject(Fx),Dn=dl}catch{}}Bt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Ox;Bt.createPortal=function(t,e){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!pf(e))throw Error(U(200));return Mx(t,e,null,n)};Bt.createRoot=function(t,e){if(!pf(t))throw Error(U(299));var n=!1,r="",s=av;return e!=null&&(e.unstable_strictMode===!0&&(n=!0),e.identifierPrefix!==void 0&&(r=e.identifierPrefix),e.onRecoverableError!==void 0&&(s=e.onRecoverableError)),e=df(t,1,!1,null,null,n,!1,r,s),t[Jn]=e.current,ea(t.nodeType===8?t.parentNode:t),new ff(e)};Bt.findDOMNode=function(t){if(t==null)return null;if(t.nodeType===1)return t;var e=t._reactInternals;if(e===void 0)throw typeof t.render=="function"?Error(U(188)):(t=Object.keys(t).join(","),Error(U(268,t)));return t=C0(e),t=t===null?null:t.stateNode,t};Bt.flushSync=function(t){return Rs(t)};Bt.hydrate=function(t,e,n){if(!Bu(e))throw Error(U(200));return $u(null,t,e,!0,n)};Bt.hydrateRoot=function(t,e,n){if(!pf(t))throw Error(U(405));var r=n!=null&&n.hydratedSources||null,s=!1,i="",o=av;if(n!=null&&(n.unstable_strictMode===!0&&(s=!0),n.identifierPrefix!==void 0&&(i=n.identifierPrefix),n.onRecoverableError!==void 0&&(o=n.onRecoverableError)),e=ov(e,null,t,1,n??null,s,!1,i,o),t[Jn]=e.current,ea(t),r)for(t=0;t<r.length;t++)n=r[t],s=n._getVersion,s=s(n._source),e.mutableSourceEagerHydrationData==null?e.mutableSourceEagerHydrationData=[n,s]:e.mutableSourceEagerHydrationData.push(n,s);return new Uu(e)};Bt.render=function(t,e,n){if(!Bu(e))throw Error(U(200));return $u(null,t,e,!1,n)};Bt.unmountComponentAtNode=function(t){if(!Bu(t))throw Error(U(40));return t._reactRootContainer?(Rs(function(){$u(null,null,t,!1,function(){t._reactRootContainer=null,t[Jn]=null})}),!0):!1};Bt.unstable_batchedUpdates=af;Bt.unstable_renderSubtreeIntoContainer=function(t,e,n,r){if(!Bu(n))throw Error(U(200));if(t==null||t._reactInternals===void 0)throw Error(U(38));return $u(t,e,n,!1,r)};Bt.version="18.3.1-next-f1338f8080-20240426";function lv(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(lv)}catch(t){console.error(t)}}lv(),l0.exports=Bt;var zx=l0.exports,Im=zx;ed.createRoot=Im.createRoot,ed.hydrateRoot=Im.hydrateRoot;/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ux=()=>{};var Am={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uv=function(t){const e=[];let n=0;for(let r=0;r<t.length;r++){let s=t.charCodeAt(r);s<128?e[n++]=s:s<2048?(e[n++]=s>>6|192,e[n++]=s&63|128):(s&64512)===55296&&r+1<t.length&&(t.charCodeAt(r+1)&64512)===56320?(s=65536+((s&1023)<<10)+(t.charCodeAt(++r)&1023),e[n++]=s>>18|240,e[n++]=s>>12&63|128,e[n++]=s>>6&63|128,e[n++]=s&63|128):(e[n++]=s>>12|224,e[n++]=s>>6&63|128,e[n++]=s&63|128)}return e},Bx=function(t){const e=[];let n=0,r=0;for(;n<t.length;){const s=t[n++];if(s<128)e[r++]=String.fromCharCode(s);else if(s>191&&s<224){const i=t[n++];e[r++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=t[n++],o=t[n++],l=t[n++],u=((s&7)<<18|(i&63)<<12|(o&63)<<6|l&63)-65536;e[r++]=String.fromCharCode(55296+(u>>10)),e[r++]=String.fromCharCode(56320+(u&1023))}else{const i=t[n++],o=t[n++];e[r++]=String.fromCharCode((s&15)<<12|(i&63)<<6|o&63)}}return e.join("")},cv={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let s=0;s<t.length;s+=3){const i=t[s],o=s+1<t.length,l=o?t[s+1]:0,u=s+2<t.length,d=u?t[s+2]:0,f=i>>2,m=(i&3)<<4|l>>4;let v=(l&15)<<2|d>>6,I=d&63;u||(I=64,o||(v=64)),r.push(n[f],n[m],n[v],n[I])}return r.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(uv(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):Bx(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();const n=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let s=0;s<t.length;){const i=n[t.charAt(s++)],l=s<t.length?n[t.charAt(s)]:0;++s;const d=s<t.length?n[t.charAt(s)]:64;++s;const m=s<t.length?n[t.charAt(s)]:64;if(++s,i==null||l==null||d==null||m==null)throw new $x;const v=i<<2|l>>4;if(r.push(v),d!==64){const I=l<<4&240|d>>2;if(r.push(I),m!==64){const A=d<<6&192|m;r.push(A)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}};class $x extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const qx=function(t){const e=uv(t);return cv.encodeByteArray(e,!0)},uu=function(t){return qx(t).replace(/\./g,"")},Hx=function(t){try{return cv.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wx(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gx=()=>Wx().__FIREBASE_DEFAULTS__,Kx=()=>{if(typeof process>"u"||typeof Am>"u")return;const t=Am.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},Qx=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=t&&Hx(t[1]);return e&&JSON.parse(e)},mf=()=>{try{return Ux()||Gx()||Kx()||Qx()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},Yx=t=>{var e,n;return(n=(e=mf())==null?void 0:e.emulatorHosts)==null?void 0:n[t]},Xx=t=>{const e=Yx(t);if(!e)return;const n=e.lastIndexOf(":");if(n<=0||n+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const r=parseInt(e.substring(n+1),10);return e[0]==="["?[e.substring(1,n-1),r]:[e.substring(0,n),r]},dv=()=>{var t;return(t=mf())==null?void 0:t.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jx{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}wrapCallback(e){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(n):e(n,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zx(t,e){if(t.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const n={alg:"none",type:"JWT"},r=e||"demo-project",s=t.iat||0,i=t.sub||t.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o={iss:`https://securetoken.google.com/${r}`,aud:r,iat:s,exp:s+3600,auth_time:s,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...t};return[uu(JSON.stringify(n)),uu(JSON.stringify(o)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function e2(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function t2(){var e;const t=(e=mf())==null?void 0:e.forceEnvironment;if(t==="node")return!0;if(t==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function n2(){return!t2()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function r2(){try{return typeof indexedDB=="object"}catch{return!1}}function s2(){return new Promise((t,e)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(r);s.onsuccess=()=>{s.result.close(),n||self.indexedDB.deleteDatabase(r),t(!0)},s.onupgradeneeded=()=>{n=!1},s.onerror=()=>{var i;e(((i=s.error)==null?void 0:i.message)||"")}}catch(n){e(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const i2="FirebaseError";class Bi extends Error{constructor(e,n,r){super(n),this.code=e,this.customData=r,this.name=i2,Object.setPrototypeOf(this,Bi.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,hv.prototype.create)}}class hv{constructor(e,n,r){this.service=e,this.serviceName=n,this.errors=r}create(e,...n){const r=n[0]||{},s=`${this.service}/${e}`,i=this.errors[e],o=i?o2(i,r):"Error",l=`${this.serviceName}: ${o} (${s}).`;return new Bi(s,l,r)}}function o2(t,e){return t.replace(a2,(n,r)=>{const s=e[r];return s!=null?String(s):`<${r}?>`})}const a2=/\{\$([^}]+)}/g;function cu(t,e){if(t===e)return!0;const n=Object.keys(t),r=Object.keys(e);for(const s of n){if(!r.includes(s))return!1;const i=t[s],o=e[s];if(Cm(i)&&Cm(o)){if(!cu(i,o))return!1}else if(i!==o)return!1}for(const s of r)if(!n.includes(s))return!1;return!0}function Cm(t){return t!==null&&typeof t=="object"}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vi(t){return t&&t._delegate?t._delegate:t}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fv(t){try{return(t.startsWith("http://")||t.startsWith("https://")?new URL(t).hostname:t).endsWith(".cloudworkstations.dev")}catch{return!1}}async function l2(t){return(await fetch(t,{credentials:"include"})).ok}class ua{constructor(e,n,r){this.name=e,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vs="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u2{constructor(e,n){this.name=e,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const n=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(n)){const r=new Jx;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:n});s&&r.resolve(s)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(e){const n=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(n)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:n})}catch(s){if(r)return null;throw s}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(d2(e))try{this.getOrInitializeService({instanceIdentifier:vs})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(n);try{const i=this.getOrInitializeService({instanceIdentifier:s});r.resolve(i)}catch{}}}}clearInstance(e=vs){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...e.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=vs){return this.instances.has(e)}getOptions(e=vs){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:n={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[i,o]of this.instancesDeferred.entries()){const l=this.normalizeInstanceIdentifier(i);r===l&&o.resolve(s)}return s}onInit(e,n){const r=this.normalizeInstanceIdentifier(n),s=this.onInitCallbacks.get(r)??new Set;s.add(e),this.onInitCallbacks.set(r,s);const i=this.instances.get(r);return i&&e(i,r),()=>{s.delete(e)}}invokeOnInitCallbacks(e,n){const r=this.onInitCallbacks.get(n);if(r)for(const s of r)try{s(e,n)}catch{}}getOrInitializeService({instanceIdentifier:e,options:n={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:c2(e),options:n}),this.instances.set(e,r),this.instancesOptions.set(e,n),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=vs){return this.component?this.component.multipleInstances?e:vs:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function c2(t){return t===vs?void 0:t}function d2(t){return t.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class h2{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const n=this.getProvider(e.name);if(n.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);n.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const n=new u2(e,this);return this.providers.set(e,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var fe;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(fe||(fe={}));const f2={debug:fe.DEBUG,verbose:fe.VERBOSE,info:fe.INFO,warn:fe.WARN,error:fe.ERROR,silent:fe.SILENT},p2=fe.INFO,m2={[fe.DEBUG]:"log",[fe.VERBOSE]:"log",[fe.INFO]:"info",[fe.WARN]:"warn",[fe.ERROR]:"error"},g2=(t,e,...n)=>{if(e<t.logLevel)return;const r=new Date().toISOString(),s=m2[e];if(s)console[s](`[${r}]  ${t.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class pv{constructor(e){this.name=e,this._logLevel=p2,this._logHandler=g2,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in fe))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?f2[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,fe.DEBUG,...e),this._logHandler(this,fe.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,fe.VERBOSE,...e),this._logHandler(this,fe.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,fe.INFO,...e),this._logHandler(this,fe.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,fe.WARN,...e),this._logHandler(this,fe.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,fe.ERROR,...e),this._logHandler(this,fe.ERROR,...e)}}const y2=(t,e)=>e.some(n=>t instanceof n);let Rm,Pm;function v2(){return Rm||(Rm=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function _2(){return Pm||(Pm=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const mv=new WeakMap,Gd=new WeakMap,gv=new WeakMap,$c=new WeakMap,gf=new WeakMap;function w2(t){const e=new Promise((n,r)=>{const s=()=>{t.removeEventListener("success",i),t.removeEventListener("error",o)},i=()=>{n(jr(t.result)),s()},o=()=>{r(t.error),s()};t.addEventListener("success",i),t.addEventListener("error",o)});return e.then(n=>{n instanceof IDBCursor&&mv.set(n,t)}).catch(()=>{}),gf.set(e,t),e}function x2(t){if(Gd.has(t))return;const e=new Promise((n,r)=>{const s=()=>{t.removeEventListener("complete",i),t.removeEventListener("error",o),t.removeEventListener("abort",o)},i=()=>{n(),s()},o=()=>{r(t.error||new DOMException("AbortError","AbortError")),s()};t.addEventListener("complete",i),t.addEventListener("error",o),t.addEventListener("abort",o)});Gd.set(t,e)}let Kd={get(t,e,n){if(t instanceof IDBTransaction){if(e==="done")return Gd.get(t);if(e==="objectStoreNames")return t.objectStoreNames||gv.get(t);if(e==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return jr(t[e])},set(t,e,n){return t[e]=n,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function E2(t){Kd=t(Kd)}function T2(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...n){const r=t.call(qc(this),e,...n);return gv.set(r,e.sort?e.sort():[e]),jr(r)}:_2().includes(t)?function(...e){return t.apply(qc(this),e),jr(mv.get(this))}:function(...e){return jr(t.apply(qc(this),e))}}function b2(t){return typeof t=="function"?T2(t):(t instanceof IDBTransaction&&x2(t),y2(t,v2())?new Proxy(t,Kd):t)}function jr(t){if(t instanceof IDBRequest)return w2(t);if($c.has(t))return $c.get(t);const e=b2(t);return e!==t&&($c.set(t,e),gf.set(e,t)),e}const qc=t=>gf.get(t);function S2(t,e,{blocked:n,upgrade:r,blocking:s,terminated:i}={}){const o=indexedDB.open(t,e),l=jr(o);return r&&o.addEventListener("upgradeneeded",u=>{r(jr(o.result),u.oldVersion,u.newVersion,jr(o.transaction),u)}),n&&o.addEventListener("blocked",u=>n(u.oldVersion,u.newVersion,u)),l.then(u=>{i&&u.addEventListener("close",()=>i()),s&&u.addEventListener("versionchange",d=>s(d.oldVersion,d.newVersion,d))}).catch(()=>{}),l}const k2=["get","getKey","getAll","getAllKeys","count"],I2=["put","add","delete","clear"],Hc=new Map;function Nm(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(Hc.get(e))return Hc.get(e);const n=e.replace(/FromIndex$/,""),r=e!==n,s=I2.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(s||k2.includes(n)))return;const i=async function(o,...l){const u=this.transaction(o,s?"readwrite":"readonly");let d=u.store;return r&&(d=d.index(l.shift())),(await Promise.all([d[n](...l),s&&u.done]))[0]};return Hc.set(e,i),i}E2(t=>({...t,get:(e,n,r)=>Nm(e,n)||t.get(e,n,r),has:(e,n)=>!!Nm(e,n)||t.has(e,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A2{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(C2(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function C2(t){const e=t.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Qd="@firebase/app",Vm="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tr=new pv("@firebase/app"),R2="@firebase/app-compat",P2="@firebase/analytics-compat",N2="@firebase/analytics",V2="@firebase/app-check-compat",D2="@firebase/app-check",M2="@firebase/auth",L2="@firebase/auth-compat",j2="@firebase/database",O2="@firebase/data-connect",F2="@firebase/database-compat",z2="@firebase/functions",U2="@firebase/functions-compat",B2="@firebase/installations",$2="@firebase/installations-compat",q2="@firebase/messaging",H2="@firebase/messaging-compat",W2="@firebase/performance",G2="@firebase/performance-compat",K2="@firebase/remote-config",Q2="@firebase/remote-config-compat",Y2="@firebase/storage",X2="@firebase/storage-compat",J2="@firebase/firestore",Z2="@firebase/ai",eE="@firebase/firestore-compat",tE="firebase",nE="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yd="[DEFAULT]",rE={[Qd]:"fire-core",[R2]:"fire-core-compat",[N2]:"fire-analytics",[P2]:"fire-analytics-compat",[D2]:"fire-app-check",[V2]:"fire-app-check-compat",[M2]:"fire-auth",[L2]:"fire-auth-compat",[j2]:"fire-rtdb",[O2]:"fire-data-connect",[F2]:"fire-rtdb-compat",[z2]:"fire-fn",[U2]:"fire-fn-compat",[B2]:"fire-iid",[$2]:"fire-iid-compat",[q2]:"fire-fcm",[H2]:"fire-fcm-compat",[W2]:"fire-perf",[G2]:"fire-perf-compat",[K2]:"fire-rc",[Q2]:"fire-rc-compat",[Y2]:"fire-gcs",[X2]:"fire-gcs-compat",[J2]:"fire-fst",[eE]:"fire-fst-compat",[Z2]:"fire-vertex","fire-js":"fire-js",[tE]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ca=new Map,sE=new Map,Xd=new Map;function Dm(t,e){try{t.container.addComponent(e)}catch(n){tr.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function du(t){const e=t.name;if(Xd.has(e))return tr.debug(`There were multiple attempts to register component ${e}.`),!1;Xd.set(e,t);for(const n of ca.values())Dm(n,t);for(const n of sE.values())Dm(n,t);return!0}function iE(t,e){const n=t.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),t.container.getProvider(e)}function oE(t){return t==null?!1:t.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const aE={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Or=new hv("app","Firebase",aE);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lE{constructor(e,n,r){this._isDeleted=!1,this._options={...e},this._config={...n},this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new ua("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Or.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uE=nE;function yv(t,e={}){let n=t;typeof e!="object"&&(e={name:e});const r={name:Yd,automaticDataCollectionEnabled:!0,...e},s=r.name;if(typeof s!="string"||!s)throw Or.create("bad-app-name",{appName:String(s)});if(n||(n=dv()),!n)throw Or.create("no-options");const i=ca.get(s);if(i){if(cu(n,i.options)&&cu(r,i.config))return i;throw Or.create("duplicate-app",{appName:s})}const o=new h2(s);for(const u of Xd.values())o.addComponent(u);const l=new lE(n,r,o);return ca.set(s,l),l}function cE(t=Yd){const e=ca.get(t);if(!e&&t===Yd&&dv())return yv();if(!e)throw Or.create("no-app",{appName:t});return e}function Mm(){return Array.from(ca.values())}function xi(t,e,n){let r=rE[t]??t;n&&(r+=`-${n}`);const s=r.match(/\s|\//),i=e.match(/\s|\//);if(s||i){const o=[`Unable to register library "${r}" with version "${e}":`];s&&o.push(`library name "${r}" contains illegal characters (whitespace or "/")`),s&&i&&o.push("and"),i&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),tr.warn(o.join(" "));return}du(new ua(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dE="firebase-heartbeat-database",hE=1,da="firebase-heartbeat-store";let Wc=null;function vv(){return Wc||(Wc=S2(dE,hE,{upgrade:(t,e)=>{switch(e){case 0:try{t.createObjectStore(da)}catch(n){console.warn(n)}}}}).catch(t=>{throw Or.create("idb-open",{originalErrorMessage:t.message})})),Wc}async function fE(t){try{const n=(await vv()).transaction(da),r=await n.objectStore(da).get(_v(t));return await n.done,r}catch(e){if(e instanceof Bi)tr.warn(e.message);else{const n=Or.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});tr.warn(n.message)}}}async function Lm(t,e){try{const r=(await vv()).transaction(da,"readwrite");await r.objectStore(da).put(e,_v(t)),await r.done}catch(n){if(n instanceof Bi)tr.warn(n.message);else{const r=Or.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});tr.warn(r.message)}}}function _v(t){return`${t.name}!${t.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pE=1024,mE=30;class gE{constructor(e){this.container=e,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new vE(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,n;try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=jm();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)==null?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:s}),this._heartbeatsCache.heartbeats.length>mE){const o=_E(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){tr.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=jm(),{heartbeatsToSend:r,unsentEntries:s}=yE(this._heartbeatsCache.heartbeats),i=uu(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(n){return tr.warn(n),""}}}function jm(){return new Date().toISOString().substring(0,10)}function yE(t,e=pE){const n=[];let r=t.slice();for(const s of t){const i=n.find(o=>o.agent===s.agent);if(i){if(i.dates.push(s.date),Om(n)>e){i.dates.pop();break}}else if(n.push({agent:s.agent,dates:[s.date]}),Om(n)>e){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class vE{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return r2()?s2().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await fE(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return Lm(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return Lm(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function Om(t){return uu(JSON.stringify({version:2,heartbeats:t})).length}function _E(t){if(t.length===0)return-1;let e=0,n=t[0].date;for(let r=1;r<t.length;r++)t[r].date<n&&(n=t[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wE(t){du(new ua("platform-logger",e=>new A2(e),"PRIVATE")),du(new ua("heartbeat",e=>new gE(e),"PRIVATE")),xi(Qd,Vm,t),xi(Qd,Vm,"esm2020"),xi("fire-js","")}wE("");var xE="firebase",EE="12.12.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */xi(xE,EE,"app");var Fm=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Fr,wv;(function(){var t;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(w,y){function _(){}_.prototype=y.prototype,w.F=y.prototype,w.prototype=new _,w.prototype.constructor=w,w.D=function(T,b,C){for(var E=Array(arguments.length-2),J=2;J<arguments.length;J++)E[J-2]=arguments[J];return y.prototype[b].apply(T,E)}}function n(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(r,n),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(w,y,_){_||(_=0);const T=Array(16);if(typeof y=="string")for(var b=0;b<16;++b)T[b]=y.charCodeAt(_++)|y.charCodeAt(_++)<<8|y.charCodeAt(_++)<<16|y.charCodeAt(_++)<<24;else for(b=0;b<16;++b)T[b]=y[_++]|y[_++]<<8|y[_++]<<16|y[_++]<<24;y=w.g[0],_=w.g[1],b=w.g[2];let C=w.g[3],E;E=y+(C^_&(b^C))+T[0]+3614090360&4294967295,y=_+(E<<7&4294967295|E>>>25),E=C+(b^y&(_^b))+T[1]+3905402710&4294967295,C=y+(E<<12&4294967295|E>>>20),E=b+(_^C&(y^_))+T[2]+606105819&4294967295,b=C+(E<<17&4294967295|E>>>15),E=_+(y^b&(C^y))+T[3]+3250441966&4294967295,_=b+(E<<22&4294967295|E>>>10),E=y+(C^_&(b^C))+T[4]+4118548399&4294967295,y=_+(E<<7&4294967295|E>>>25),E=C+(b^y&(_^b))+T[5]+1200080426&4294967295,C=y+(E<<12&4294967295|E>>>20),E=b+(_^C&(y^_))+T[6]+2821735955&4294967295,b=C+(E<<17&4294967295|E>>>15),E=_+(y^b&(C^y))+T[7]+4249261313&4294967295,_=b+(E<<22&4294967295|E>>>10),E=y+(C^_&(b^C))+T[8]+1770035416&4294967295,y=_+(E<<7&4294967295|E>>>25),E=C+(b^y&(_^b))+T[9]+2336552879&4294967295,C=y+(E<<12&4294967295|E>>>20),E=b+(_^C&(y^_))+T[10]+4294925233&4294967295,b=C+(E<<17&4294967295|E>>>15),E=_+(y^b&(C^y))+T[11]+2304563134&4294967295,_=b+(E<<22&4294967295|E>>>10),E=y+(C^_&(b^C))+T[12]+1804603682&4294967295,y=_+(E<<7&4294967295|E>>>25),E=C+(b^y&(_^b))+T[13]+4254626195&4294967295,C=y+(E<<12&4294967295|E>>>20),E=b+(_^C&(y^_))+T[14]+2792965006&4294967295,b=C+(E<<17&4294967295|E>>>15),E=_+(y^b&(C^y))+T[15]+1236535329&4294967295,_=b+(E<<22&4294967295|E>>>10),E=y+(b^C&(_^b))+T[1]+4129170786&4294967295,y=_+(E<<5&4294967295|E>>>27),E=C+(_^b&(y^_))+T[6]+3225465664&4294967295,C=y+(E<<9&4294967295|E>>>23),E=b+(y^_&(C^y))+T[11]+643717713&4294967295,b=C+(E<<14&4294967295|E>>>18),E=_+(C^y&(b^C))+T[0]+3921069994&4294967295,_=b+(E<<20&4294967295|E>>>12),E=y+(b^C&(_^b))+T[5]+3593408605&4294967295,y=_+(E<<5&4294967295|E>>>27),E=C+(_^b&(y^_))+T[10]+38016083&4294967295,C=y+(E<<9&4294967295|E>>>23),E=b+(y^_&(C^y))+T[15]+3634488961&4294967295,b=C+(E<<14&4294967295|E>>>18),E=_+(C^y&(b^C))+T[4]+3889429448&4294967295,_=b+(E<<20&4294967295|E>>>12),E=y+(b^C&(_^b))+T[9]+568446438&4294967295,y=_+(E<<5&4294967295|E>>>27),E=C+(_^b&(y^_))+T[14]+3275163606&4294967295,C=y+(E<<9&4294967295|E>>>23),E=b+(y^_&(C^y))+T[3]+4107603335&4294967295,b=C+(E<<14&4294967295|E>>>18),E=_+(C^y&(b^C))+T[8]+1163531501&4294967295,_=b+(E<<20&4294967295|E>>>12),E=y+(b^C&(_^b))+T[13]+2850285829&4294967295,y=_+(E<<5&4294967295|E>>>27),E=C+(_^b&(y^_))+T[2]+4243563512&4294967295,C=y+(E<<9&4294967295|E>>>23),E=b+(y^_&(C^y))+T[7]+1735328473&4294967295,b=C+(E<<14&4294967295|E>>>18),E=_+(C^y&(b^C))+T[12]+2368359562&4294967295,_=b+(E<<20&4294967295|E>>>12),E=y+(_^b^C)+T[5]+4294588738&4294967295,y=_+(E<<4&4294967295|E>>>28),E=C+(y^_^b)+T[8]+2272392833&4294967295,C=y+(E<<11&4294967295|E>>>21),E=b+(C^y^_)+T[11]+1839030562&4294967295,b=C+(E<<16&4294967295|E>>>16),E=_+(b^C^y)+T[14]+4259657740&4294967295,_=b+(E<<23&4294967295|E>>>9),E=y+(_^b^C)+T[1]+2763975236&4294967295,y=_+(E<<4&4294967295|E>>>28),E=C+(y^_^b)+T[4]+1272893353&4294967295,C=y+(E<<11&4294967295|E>>>21),E=b+(C^y^_)+T[7]+4139469664&4294967295,b=C+(E<<16&4294967295|E>>>16),E=_+(b^C^y)+T[10]+3200236656&4294967295,_=b+(E<<23&4294967295|E>>>9),E=y+(_^b^C)+T[13]+681279174&4294967295,y=_+(E<<4&4294967295|E>>>28),E=C+(y^_^b)+T[0]+3936430074&4294967295,C=y+(E<<11&4294967295|E>>>21),E=b+(C^y^_)+T[3]+3572445317&4294967295,b=C+(E<<16&4294967295|E>>>16),E=_+(b^C^y)+T[6]+76029189&4294967295,_=b+(E<<23&4294967295|E>>>9),E=y+(_^b^C)+T[9]+3654602809&4294967295,y=_+(E<<4&4294967295|E>>>28),E=C+(y^_^b)+T[12]+3873151461&4294967295,C=y+(E<<11&4294967295|E>>>21),E=b+(C^y^_)+T[15]+530742520&4294967295,b=C+(E<<16&4294967295|E>>>16),E=_+(b^C^y)+T[2]+3299628645&4294967295,_=b+(E<<23&4294967295|E>>>9),E=y+(b^(_|~C))+T[0]+4096336452&4294967295,y=_+(E<<6&4294967295|E>>>26),E=C+(_^(y|~b))+T[7]+1126891415&4294967295,C=y+(E<<10&4294967295|E>>>22),E=b+(y^(C|~_))+T[14]+2878612391&4294967295,b=C+(E<<15&4294967295|E>>>17),E=_+(C^(b|~y))+T[5]+4237533241&4294967295,_=b+(E<<21&4294967295|E>>>11),E=y+(b^(_|~C))+T[12]+1700485571&4294967295,y=_+(E<<6&4294967295|E>>>26),E=C+(_^(y|~b))+T[3]+2399980690&4294967295,C=y+(E<<10&4294967295|E>>>22),E=b+(y^(C|~_))+T[10]+4293915773&4294967295,b=C+(E<<15&4294967295|E>>>17),E=_+(C^(b|~y))+T[1]+2240044497&4294967295,_=b+(E<<21&4294967295|E>>>11),E=y+(b^(_|~C))+T[8]+1873313359&4294967295,y=_+(E<<6&4294967295|E>>>26),E=C+(_^(y|~b))+T[15]+4264355552&4294967295,C=y+(E<<10&4294967295|E>>>22),E=b+(y^(C|~_))+T[6]+2734768916&4294967295,b=C+(E<<15&4294967295|E>>>17),E=_+(C^(b|~y))+T[13]+1309151649&4294967295,_=b+(E<<21&4294967295|E>>>11),E=y+(b^(_|~C))+T[4]+4149444226&4294967295,y=_+(E<<6&4294967295|E>>>26),E=C+(_^(y|~b))+T[11]+3174756917&4294967295,C=y+(E<<10&4294967295|E>>>22),E=b+(y^(C|~_))+T[2]+718787259&4294967295,b=C+(E<<15&4294967295|E>>>17),E=_+(C^(b|~y))+T[9]+3951481745&4294967295,w.g[0]=w.g[0]+y&4294967295,w.g[1]=w.g[1]+(b+(E<<21&4294967295|E>>>11))&4294967295,w.g[2]=w.g[2]+b&4294967295,w.g[3]=w.g[3]+C&4294967295}r.prototype.v=function(w,y){y===void 0&&(y=w.length);const _=y-this.blockSize,T=this.C;let b=this.h,C=0;for(;C<y;){if(b==0)for(;C<=_;)s(this,w,C),C+=this.blockSize;if(typeof w=="string"){for(;C<y;)if(T[b++]=w.charCodeAt(C++),b==this.blockSize){s(this,T),b=0;break}}else for(;C<y;)if(T[b++]=w[C++],b==this.blockSize){s(this,T),b=0;break}}this.h=b,this.o+=y},r.prototype.A=function(){var w=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);w[0]=128;for(var y=1;y<w.length-8;++y)w[y]=0;y=this.o*8;for(var _=w.length-8;_<w.length;++_)w[_]=y&255,y/=256;for(this.v(w),w=Array(16),y=0,_=0;_<4;++_)for(let T=0;T<32;T+=8)w[y++]=this.g[_]>>>T&255;return w};function i(w,y){var _=l;return Object.prototype.hasOwnProperty.call(_,w)?_[w]:_[w]=y(w)}function o(w,y){this.h=y;const _=[];let T=!0;for(let b=w.length-1;b>=0;b--){const C=w[b]|0;T&&C==y||(_[b]=C,T=!1)}this.g=_}var l={};function u(w){return-128<=w&&w<128?i(w,function(y){return new o([y|0],y<0?-1:0)}):new o([w|0],w<0?-1:0)}function d(w){if(isNaN(w)||!isFinite(w))return m;if(w<0)return M(d(-w));const y=[];let _=1;for(let T=0;w>=_;T++)y[T]=w/_|0,_*=4294967296;return new o(y,0)}function f(w,y){if(w.length==0)throw Error("number format error: empty string");if(y=y||10,y<2||36<y)throw Error("radix out of range: "+y);if(w.charAt(0)=="-")return M(f(w.substring(1),y));if(w.indexOf("-")>=0)throw Error('number format error: interior "-" character');const _=d(Math.pow(y,8));let T=m;for(let C=0;C<w.length;C+=8){var b=Math.min(8,w.length-C);const E=parseInt(w.substring(C,C+b),y);b<8?(b=d(Math.pow(y,b)),T=T.j(b).add(d(E))):(T=T.j(_),T=T.add(d(E)))}return T}var m=u(0),v=u(1),I=u(16777216);t=o.prototype,t.m=function(){if(P(this))return-M(this).m();let w=0,y=1;for(let _=0;_<this.g.length;_++){const T=this.i(_);w+=(T>=0?T:4294967296+T)*y,y*=4294967296}return w},t.toString=function(w){if(w=w||10,w<2||36<w)throw Error("radix out of range: "+w);if(A(this))return"0";if(P(this))return"-"+M(this).toString(w);const y=d(Math.pow(w,6));var _=this;let T="";for(;;){const b=V(_,y).g;_=S(_,b.j(y));let C=((_.g.length>0?_.g[0]:_.h)>>>0).toString(w);if(_=b,A(_))return C+T;for(;C.length<6;)C="0"+C;T=C+T}},t.i=function(w){return w<0?0:w<this.g.length?this.g[w]:this.h};function A(w){if(w.h!=0)return!1;for(let y=0;y<w.g.length;y++)if(w.g[y]!=0)return!1;return!0}function P(w){return w.h==-1}t.l=function(w){return w=S(this,w),P(w)?-1:A(w)?0:1};function M(w){const y=w.g.length,_=[];for(let T=0;T<y;T++)_[T]=~w.g[T];return new o(_,~w.h).add(v)}t.abs=function(){return P(this)?M(this):this},t.add=function(w){const y=Math.max(this.g.length,w.g.length),_=[];let T=0;for(let b=0;b<=y;b++){let C=T+(this.i(b)&65535)+(w.i(b)&65535),E=(C>>>16)+(this.i(b)>>>16)+(w.i(b)>>>16);T=E>>>16,C&=65535,E&=65535,_[b]=E<<16|C}return new o(_,_[_.length-1]&-2147483648?-1:0)};function S(w,y){return w.add(M(y))}t.j=function(w){if(A(this)||A(w))return m;if(P(this))return P(w)?M(this).j(M(w)):M(M(this).j(w));if(P(w))return M(this.j(M(w)));if(this.l(I)<0&&w.l(I)<0)return d(this.m()*w.m());const y=this.g.length+w.g.length,_=[];for(var T=0;T<2*y;T++)_[T]=0;for(T=0;T<this.g.length;T++)for(let b=0;b<w.g.length;b++){const C=this.i(T)>>>16,E=this.i(T)&65535,J=w.i(b)>>>16,Pe=w.i(b)&65535;_[2*T+2*b]+=E*Pe,x(_,2*T+2*b),_[2*T+2*b+1]+=C*Pe,x(_,2*T+2*b+1),_[2*T+2*b+1]+=E*J,x(_,2*T+2*b+1),_[2*T+2*b+2]+=C*J,x(_,2*T+2*b+2)}for(w=0;w<y;w++)_[w]=_[2*w+1]<<16|_[2*w];for(w=y;w<2*y;w++)_[w]=0;return new o(_,0)};function x(w,y){for(;(w[y]&65535)!=w[y];)w[y+1]+=w[y]>>>16,w[y]&=65535,y++}function k(w,y){this.g=w,this.h=y}function V(w,y){if(A(y))throw Error("division by zero");if(A(w))return new k(m,m);if(P(w))return y=V(M(w),y),new k(M(y.g),M(y.h));if(P(y))return y=V(w,M(y)),new k(M(y.g),y.h);if(w.g.length>30){if(P(w)||P(y))throw Error("slowDivide_ only works with positive integers.");for(var _=v,T=y;T.l(w)<=0;)_=F(_),T=F(T);var b=B(_,1),C=B(T,1);for(T=B(T,2),_=B(_,2);!A(T);){var E=C.add(T);E.l(w)<=0&&(b=b.add(_),C=E),T=B(T,1),_=B(_,1)}return y=S(w,b.j(y)),new k(b,y)}for(b=m;w.l(y)>=0;){for(_=Math.max(1,Math.floor(w.m()/y.m())),T=Math.ceil(Math.log(_)/Math.LN2),T=T<=48?1:Math.pow(2,T-48),C=d(_),E=C.j(y);P(E)||E.l(w)>0;)_-=T,C=d(_),E=C.j(y);A(C)&&(C=v),b=b.add(C),w=S(w,E)}return new k(b,w)}t.B=function(w){return V(this,w).h},t.and=function(w){const y=Math.max(this.g.length,w.g.length),_=[];for(let T=0;T<y;T++)_[T]=this.i(T)&w.i(T);return new o(_,this.h&w.h)},t.or=function(w){const y=Math.max(this.g.length,w.g.length),_=[];for(let T=0;T<y;T++)_[T]=this.i(T)|w.i(T);return new o(_,this.h|w.h)},t.xor=function(w){const y=Math.max(this.g.length,w.g.length),_=[];for(let T=0;T<y;T++)_[T]=this.i(T)^w.i(T);return new o(_,this.h^w.h)};function F(w){const y=w.g.length+1,_=[];for(let T=0;T<y;T++)_[T]=w.i(T)<<1|w.i(T-1)>>>31;return new o(_,w.h)}function B(w,y){const _=y>>5;y%=32;const T=w.g.length-_,b=[];for(let C=0;C<T;C++)b[C]=y>0?w.i(C+_)>>>y|w.i(C+_+1)<<32-y:w.i(C+_);return new o(b,w.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,wv=r,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.B,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=d,o.fromString=f,Fr=o}).apply(typeof Fm<"u"?Fm:typeof self<"u"?self:typeof window<"u"?window:{});var hl=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var xv,Ao,Ev,Vl,Jd,Tv,bv,Sv;(function(){var t,e=Object.defineProperty;function n(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof hl=="object"&&hl];for(var c=0;c<a.length;++c){var h=a[c];if(h&&h.Math==Math)return h}throw Error("Cannot find global object")}var r=n(this);function s(a,c){if(c)e:{var h=r;a=a.split(".");for(var g=0;g<a.length-1;g++){var R=a[g];if(!(R in h))break e;h=h[R]}a=a[a.length-1],g=h[a],c=c(g),c!=g&&c!=null&&e(h,a,{configurable:!0,writable:!0,value:c})}}s("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),s("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),s("Object.entries",function(a){return a||function(c){var h=[],g;for(g in c)Object.prototype.hasOwnProperty.call(c,g)&&h.push([g,c[g]]);return h}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},o=this||self;function l(a){var c=typeof a;return c=="object"&&a!=null||c=="function"}function u(a,c,h){return a.call.apply(a.bind,arguments)}function d(a,c,h){return d=u,d.apply(null,arguments)}function f(a,c){var h=Array.prototype.slice.call(arguments,1);return function(){var g=h.slice();return g.push.apply(g,arguments),a.apply(this,g)}}function m(a,c){function h(){}h.prototype=c.prototype,a.Z=c.prototype,a.prototype=new h,a.prototype.constructor=a,a.Ob=function(g,R,N){for(var $=Array(arguments.length-2),oe=2;oe<arguments.length;oe++)$[oe-2]=arguments[oe];return c.prototype[R].apply(g,$)}}var v=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function I(a){const c=a.length;if(c>0){const h=Array(c);for(let g=0;g<c;g++)h[g]=a[g];return h}return[]}function A(a,c){for(let g=1;g<arguments.length;g++){const R=arguments[g];var h=typeof R;if(h=h!="object"?h:R?Array.isArray(R)?"array":h:"null",h=="array"||h=="object"&&typeof R.length=="number"){h=a.length||0;const N=R.length||0;a.length=h+N;for(let $=0;$<N;$++)a[h+$]=R[$]}else a.push(R)}}class P{constructor(c,h){this.i=c,this.j=h,this.h=0,this.g=null}get(){let c;return this.h>0?(this.h--,c=this.g,this.g=c.next,c.next=null):c=this.i(),c}}function M(a){o.setTimeout(()=>{throw a},0)}function S(){var a=w;let c=null;return a.g&&(c=a.g,a.g=a.g.next,a.g||(a.h=null),c.next=null),c}class x{constructor(){this.h=this.g=null}add(c,h){const g=k.get();g.set(c,h),this.h?this.h.next=g:this.g=g,this.h=g}}var k=new P(()=>new V,a=>a.reset());class V{constructor(){this.next=this.g=this.h=null}set(c,h){this.h=c,this.g=h,this.next=null}reset(){this.next=this.g=this.h=null}}let F,B=!1,w=new x,y=()=>{const a=Promise.resolve(void 0);F=()=>{a.then(_)}};function _(){for(var a;a=S();){try{a.h.call(a.g)}catch(h){M(h)}var c=k;c.j(a),c.h<100&&(c.h++,a.next=c.g,c.g=a)}B=!1}function T(){this.u=this.u,this.C=this.C}T.prototype.u=!1,T.prototype.dispose=function(){this.u||(this.u=!0,this.N())},T.prototype[Symbol.dispose]=function(){this.dispose()},T.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function b(a,c){this.type=a,this.g=this.target=c,this.defaultPrevented=!1}b.prototype.h=function(){this.defaultPrevented=!0};var C=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var a=!1,c=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const h=()=>{};o.addEventListener("test",h,c),o.removeEventListener("test",h,c)}catch{}return a}();function E(a){return/^[\s\xa0]*$/.test(a)}function J(a,c){b.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,c)}m(J,b),J.prototype.init=function(a,c){const h=this.type=a.type,g=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=c,c=a.relatedTarget,c||(h=="mouseover"?c=a.fromElement:h=="mouseout"&&(c=a.toElement)),this.relatedTarget=c,g?(this.clientX=g.clientX!==void 0?g.clientX:g.pageX,this.clientY=g.clientY!==void 0?g.clientY:g.pageY,this.screenX=g.screenX||0,this.screenY=g.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&J.Z.h.call(this)},J.prototype.h=function(){J.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var Pe="closure_listenable_"+(Math.random()*1e6|0),Et=0;function je(a,c,h,g,R){this.listener=a,this.proxy=null,this.src=c,this.type=h,this.capture=!!g,this.ha=R,this.key=++Et,this.da=this.fa=!1}function H(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function Y(a,c,h){for(const g in a)c.call(h,a[g],g,a)}function ne(a,c){for(const h in a)c.call(void 0,a[h],h,a)}function ie(a){const c={};for(const h in a)c[h]=a[h];return c}const Te="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ln(a,c){let h,g;for(let R=1;R<arguments.length;R++){g=arguments[R];for(h in g)a[h]=g[h];for(let N=0;N<Te.length;N++)h=Te[N],Object.prototype.hasOwnProperty.call(g,h)&&(a[h]=g[h])}}function be(a){this.src=a,this.g={},this.h=0}be.prototype.add=function(a,c,h,g,R){const N=a.toString();a=this.g[N],a||(a=this.g[N]=[],this.h++);const $=Tt(a,c,g,R);return $>-1?(c=a[$],h||(c.fa=!1)):(c=new je(c,this.src,N,!!g,R),c.fa=h,a.push(c)),c};function un(a,c){const h=c.type;if(h in a.g){var g=a.g[h],R=Array.prototype.indexOf.call(g,c,void 0),N;(N=R>=0)&&Array.prototype.splice.call(g,R,1),N&&(H(c),a.g[h].length==0&&(delete a.g[h],a.h--))}}function Tt(a,c,h,g){for(let R=0;R<a.length;++R){const N=a[R];if(!N.da&&N.listener==c&&N.capture==!!h&&N.ha==g)return R}return-1}var qt="closure_lm_"+(Math.random()*1e6|0),es={};function ir(a,c,h,g,R){if(Array.isArray(c)){for(let N=0;N<c.length;N++)ir(a,c[N],h,g,R);return null}return h=Xi(h),a&&a[Pe]?a.J(c,h,l(g)?!!g.capture:!1,R):Pa(a,c,h,!1,g,R)}function Pa(a,c,h,g,R,N){if(!c)throw Error("Invalid event type");const $=l(R)?!!R.capture:!!R;let oe=Qi(a);if(oe||(a[qt]=oe=new be(a)),h=oe.add(c,h,g,$,N),h.proxy)return h;if(g=oc(),h.proxy=g,g.src=a,g.listener=h,a.addEventListener)C||(R=$),R===void 0&&(R=!1),a.addEventListener(c.toString(),g,R);else if(a.attachEvent)a.attachEvent(Us(c.toString()),g);else if(a.addListener&&a.removeListener)a.addListener(g);else throw Error("addEventListener and attachEvent are unavailable.");return h}function oc(){function a(h){return c.call(a.src,a.listener,h)}const c=Na;return a}function Ki(a,c,h,g,R){if(Array.isArray(c))for(var N=0;N<c.length;N++)Ki(a,c[N],h,g,R);else g=l(g)?!!g.capture:!!g,h=Xi(h),a&&a[Pe]?(a=a.i,N=String(c).toString(),N in a.g&&(c=a.g[N],h=Tt(c,h,g,R),h>-1&&(H(c[h]),Array.prototype.splice.call(c,h,1),c.length==0&&(delete a.g[N],a.h--)))):a&&(a=Qi(a))&&(c=a.g[c.toString()],a=-1,c&&(a=Tt(c,h,g,R)),(h=a>-1?c[a]:null)&&zs(h))}function zs(a){if(typeof a!="number"&&a&&!a.da){var c=a.src;if(c&&c[Pe])un(c.i,a);else{var h=a.type,g=a.proxy;c.removeEventListener?c.removeEventListener(h,g,a.capture):c.detachEvent?c.detachEvent(Us(h),g):c.addListener&&c.removeListener&&c.removeListener(g),(h=Qi(c))?(un(h,a),h.h==0&&(h.src=null,c[qt]=null)):H(a)}}}function Us(a){return a in es?es[a]:es[a]="on"+a}function Na(a,c){if(a.da)a=!0;else{c=new J(c,this);const h=a.listener,g=a.ha||a.src;a.fa&&zs(a),a=h.call(g,c)}return a}function Qi(a){return a=a[qt],a instanceof be?a:null}var Yi="__closure_events_fn_"+(Math.random()*1e9>>>0);function Xi(a){return typeof a=="function"?a:(a[Yi]||(a[Yi]=function(c){return a.handleEvent(c)}),a[Yi])}function et(){T.call(this),this.i=new be(this),this.M=this,this.G=null}m(et,T),et.prototype[Pe]=!0,et.prototype.removeEventListener=function(a,c,h,g){Ki(this,a,c,h,g)};function tt(a,c){var h,g=a.G;if(g)for(h=[];g;g=g.G)h.push(g);if(a=a.M,g=c.type||c,typeof c=="string")c=new b(c,a);else if(c instanceof b)c.target=c.target||a;else{var R=c;c=new b(g,a),ln(c,R)}R=!0;let N,$;if(h)for($=h.length-1;$>=0;$--)N=c.g=h[$],R=or(N,g,!0,c)&&R;if(N=c.g=a,R=or(N,g,!0,c)&&R,R=or(N,g,!1,c)&&R,h)for($=0;$<h.length;$++)N=c.g=h[$],R=or(N,g,!1,c)&&R}et.prototype.N=function(){if(et.Z.N.call(this),this.i){var a=this.i;for(const c in a.g){const h=a.g[c];for(let g=0;g<h.length;g++)H(h[g]);delete a.g[c],a.h--}}this.G=null},et.prototype.J=function(a,c,h,g){return this.i.add(String(a),c,!1,h,g)},et.prototype.K=function(a,c,h,g){return this.i.add(String(a),c,!0,h,g)};function or(a,c,h,g){if(c=a.i.g[String(c)],!c)return!0;c=c.concat();let R=!0;for(let N=0;N<c.length;++N){const $=c[N];if($&&!$.da&&$.capture==h){const oe=$.listener,Ye=$.ha||$.src;$.fa&&un(a.i,$),R=oe.call(Ye,g)!==!1&&R}}return R&&!g.defaultPrevented}function ac(a,c){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=d(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(c)>2147483647?-1:o.setTimeout(a,c||0)}function Va(a){a.g=ac(()=>{a.g=null,a.i&&(a.i=!1,Va(a))},a.l);const c=a.h;a.h=null,a.m.apply(null,c)}class Ji extends T{constructor(c,h){super(),this.m=c,this.l=h,this.h=null,this.i=!1,this.g=null}j(c){this.h=arguments,this.g?this.i=!0:Va(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function ts(a){T.call(this),this.h=a,this.g={}}m(ts,T);var Da=[];function _e(a){Y(a.g,function(c,h){this.g.hasOwnProperty(h)&&zs(c)},a),a.g={}}ts.prototype.N=function(){ts.Z.N.call(this),_e(this)},ts.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Sn=o.JSON.stringify,ar=o.JSON.parse,Bs=class{stringify(a){return o.JSON.stringify(a,void 0)}parse(a){return o.JSON.parse(a,void 0)}};function Zi(){}function eo(){}var ns={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function $s(){b.call(this,"d")}m($s,b);function to(){b.call(this,"c")}m(to,b);var kn={},Ma=null;function rs(){return Ma=Ma||new et}kn.Ia="serverreachability";function qs(a){b.call(this,kn.Ia,a)}m(qs,b);function ss(a){const c=rs();tt(c,new qs(c))}kn.STAT_EVENT="statevent";function no(a,c){b.call(this,kn.STAT_EVENT,a),this.stat=c}m(no,b);function Qe(a){const c=rs();tt(c,new no(c,a))}kn.Ja="timingevent";function ro(a,c){b.call(this,kn.Ja,a),this.size=c}m(ro,b);function is(a,c){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){a()},c)}function Hs(){this.g=!0}Hs.prototype.ua=function(){this.g=!1};function lc(a,c,h,g,R,N){a.info(function(){if(a.g)if(N){var $="",oe=N.split("&");for(let we=0;we<oe.length;we++){var Ye=oe[we].split("=");if(Ye.length>1){const st=Ye[0];Ye=Ye[1];const Cn=st.split("_");$=Cn.length>=2&&Cn[1]=="type"?$+(st+"="+Ye+"&"):$+(st+"=redacted&")}}}else $=null;else $=N;return"XMLHTTP REQ ("+g+") [attempt "+R+"]: "+c+`
`+h+`
`+$})}function os(a,c,h,g,R,N,$){a.info(function(){return"XMLHTTP RESP ("+g+") [ attempt "+R+"]: "+c+`
`+h+`
`+N+" "+$})}function lr(a,c,h,g){a.info(function(){return"XMLHTTP TEXT ("+c+"): "+uc(a,h)+(g?" "+g:"")})}function as(a,c){a.info(function(){return"TIMEOUT: "+c})}Hs.prototype.info=function(){};function uc(a,c){if(!a.g)return c;if(!c)return null;try{const N=JSON.parse(c);if(N){for(a=0;a<N.length;a++)if(Array.isArray(N[a])){var h=N[a];if(!(h.length<2)){var g=h[1];if(Array.isArray(g)&&!(g.length<1)){var R=g[0];if(R!="noop"&&R!="stop"&&R!="close")for(let $=1;$<g.length;$++)g[$]=""}}}}return Sn(N)}catch{return c}}var ur={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},so={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},nt;function cn(){}m(cn,Zi),cn.prototype.g=function(){return new XMLHttpRequest},nt=new cn;function dn(a){return encodeURIComponent(String(a))}function cr(a){var c=1;a=a.split(":");const h=[];for(;c>0&&a.length;)h.push(a.shift()),c--;return a.length&&h.push(a.join(":")),h}function Un(a,c,h,g){this.j=a,this.i=c,this.l=h,this.S=g||1,this.V=new ts(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new io}function io(){this.i=null,this.g="",this.h=!1}var oo={},ls={};function dr(a,c,h){a.M=1,a.A=hs(Oe(c)),a.u=h,a.R=!0,La(a,null)}function La(a,c){a.F=Date.now(),Se(a),a.B=Oe(a.A);var h=a.B,g=a.S;Array.isArray(g)||(g=[String(g)]),Ba(h.i,"t",g),a.C=0,h=a.j.L,a.h=new io,a.g=mp(a.j,h?c:null,!a.u),a.P>0&&(a.O=new Ji(d(a.Y,a,a.g),a.P)),c=a.V,h=a.g,g=a.ba;var R="readystatechange";Array.isArray(R)||(R&&(Da[0]=R.toString()),R=Da);for(let N=0;N<R.length;N++){const $=ir(h,R[N],g||c.handleEvent,!1,c.h||c);if(!$)break;c.g[$.key]=$}c=a.J?ie(a.J):{},a.u?(a.v||(a.v="POST"),c["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,c)):(a.v="GET",a.g.ea(a.B,a.v,null,c)),ss(),lc(a.i,a.v,a.B,a.l,a.S,a.u)}Un.prototype.ba=function(a){a=a.target;const c=this.O;c&&Yt(a)==3?c.j():this.Y(a)},Un.prototype.Y=function(a){try{if(a==this.g)e:{const oe=Yt(this.g),Ye=this.g.ya(),we=this.g.ca();if(!(oe<3)&&(oe!=3||this.g&&(this.h.h||this.g.la()||$a(this.g)))){this.K||oe!=4||Ye==7||(Ye==8||we<=0?ss(3):ss(2)),Wt(this);var c=this.g.ca();this.X=c;var h=ja(this);if(this.o=c==200,os(this.i,this.v,this.B,this.l,this.S,oe,c),this.o){if(this.U&&!this.L){t:{if(this.g){var g,R=this.g;if((g=R.g?R.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!E(g)){var N=g;break t}}N=null}if(a=N)lr(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Bn(this,a);else{this.o=!1,this.m=3,Qe(12),In(this),Ue(this);break e}}if(this.R){a=!0;let st;for(;!this.K&&this.C<h.length;)if(st=ce(this,h),st==ls){oe==4&&(this.m=4,Qe(14),a=!1),lr(this.i,this.l,null,"[Incomplete Response]");break}else if(st==oo){this.m=4,Qe(15),lr(this.i,this.l,h,"[Invalid Chunk]"),a=!1;break}else lr(this.i,this.l,st,null),Bn(this,st);if(us(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),oe!=4||h.length!=0||this.h.h||(this.m=1,Qe(16),a=!1),this.o=this.o&&a,!a)lr(this.i,this.l,h,"[Invalid Chunked Response]"),In(this),Ue(this);else if(h.length>0&&!this.W){this.W=!0;var $=this.j;$.g==this&&$.aa&&!$.P&&($.j.info("Great, no buffering proxy detected. Bytes received: "+h.length),mc($),$.P=!0,Qe(11))}}else lr(this.i,this.l,h,null),Bn(this,h);oe==4&&In(this),this.o&&!this.K&&(oe==4?dp(this.j,this):(this.o=!1,Se(this)))}else hc(this.g),c==400&&h.indexOf("Unknown SID")>0?(this.m=3,Qe(12)):(this.m=0,Qe(13)),In(this),Ue(this)}}}catch{}finally{}};function ja(a){if(!us(a))return a.g.la();const c=$a(a.g);if(c==="")return"";let h="";const g=c.length,R=Yt(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return In(a),Ue(a),"";a.h.i=new o.TextDecoder}for(let N=0;N<g;N++)a.h.h=!0,h+=a.h.i.decode(c[N],{stream:!(R&&N==g-1)});return c.length=0,a.h.g+=h,a.C=0,a.h.g}function us(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function ce(a,c){var h=a.C,g=c.indexOf(`
`,h);return g==-1?ls:(h=Number(c.substring(h,g)),isNaN(h)?oo:(g+=1,g+h>c.length?ls:(c=c.slice(g,g+h),a.C=g+h,c)))}Un.prototype.cancel=function(){this.K=!0,In(this)};function Se(a){a.T=Date.now()+a.H,Ht(a,a.H)}function Ht(a,c){if(a.D!=null)throw Error("WatchDog timer not null");a.D=is(d(a.aa,a),c)}function Wt(a){a.D&&(o.clearTimeout(a.D),a.D=null)}Un.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(as(this.i,this.B),this.M!=2&&(ss(),Qe(17)),In(this),this.m=2,Ue(this)):Ht(this,this.T-a)};function Ue(a){a.j.I==0||a.K||dp(a.j,a)}function In(a){Wt(a);var c=a.O;c&&typeof c.dispose=="function"&&c.dispose(),a.O=null,_e(a.V),a.g&&(c=a.g,a.g=null,c.abort(),c.dispose())}function Bn(a,c){try{var h=a.j;if(h.I!=0&&(h.g==a||qe(h.h,a))){if(!a.L&&qe(h.h,a)&&h.I==3){try{var g=h.Ba.g.parse(c)}catch{g=null}if(Array.isArray(g)&&g.length==3){var R=g;if(R[0]==0){e:if(!h.v){if(h.g)if(h.g.F+3e3<a.F)Wa(h),qa(h);else break e;pc(h),Qe(18)}}else h.xa=R[1],0<h.xa-h.K&&R[2]<37500&&h.F&&h.A==0&&!h.C&&(h.C=is(d(h.Va,h),6e3));cs(h.h)<=1&&h.ta&&(h.ta=void 0)}else ps(h,11)}else if((a.L||h.g==a)&&Wa(h),!E(c))for(R=h.Ba.g.parse(c),c=0;c<R.length;c++){let we=R[c];const st=we[0];if(!(st<=h.K))if(h.K=st,we=we[1],h.I==2)if(we[0]=="c"){h.M=we[1],h.ba=we[2];const Cn=we[3];Cn!=null&&(h.ka=Cn,h.j.info("VER="+h.ka));const ms=we[4];ms!=null&&(h.za=ms,h.j.info("SVER="+h.za));const vr=we[5];vr!=null&&typeof vr=="number"&&vr>0&&(g=1.5*vr,h.O=g,h.j.info("backChannelRequestTimeoutMs_="+g)),g=h;const _r=a.g;if(_r){const Ka=_r.g?_r.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Ka){var N=g.h;N.g||Ka.indexOf("spdy")==-1&&Ka.indexOf("quic")==-1&&Ka.indexOf("h2")==-1||(N.j=N.l,N.g=new Set,N.h&&(ds(N,N.h),N.h=null))}if(g.G){const gc=_r.g?_r.g.getResponseHeader("X-HTTP-Session-Id"):null;gc&&(g.wa=gc,ge(g.J,g.G,gc))}}h.I=3,h.l&&h.l.ra(),h.aa&&(h.T=Date.now()-a.F,h.j.info("Handshake RTT: "+h.T+"ms")),g=h;var $=a;if(g.na=pp(g,g.L?g.ba:null,g.W),$.L){$n(g.h,$);var oe=$,Ye=g.O;Ye&&(oe.H=Ye),oe.D&&(Wt(oe),Se(oe)),g.g=$}else up(g);h.i.length>0&&Ha(h)}else we[0]!="stop"&&we[0]!="close"||ps(h,7);else h.I==3&&(we[0]=="stop"||we[0]=="close"?we[0]=="stop"?ps(h,7):fc(h):we[0]!="noop"&&h.l&&h.l.qa(we),h.A=0)}}ss(4)}catch{}}var Oa=class{constructor(a,c){this.g=a,this.map=c}};function ao(a){this.l=a||10,o.PerformanceNavigationTiming?(a=o.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Ct(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function cs(a){return a.h?1:a.g?a.g.size:0}function qe(a,c){return a.h?a.h==c:a.g?a.g.has(c):!1}function ds(a,c){a.g?a.g.add(c):a.h=c}function $n(a,c){a.h&&a.h==c?a.h=null:a.g&&a.g.has(c)&&a.g.delete(c)}ao.prototype.cancel=function(){if(this.i=hr(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function hr(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let c=a.i;for(const h of a.g.values())c=c.concat(h.G);return c}return I(a.i)}var Gt=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function lo(a,c){if(a){a=a.split("&");for(let h=0;h<a.length;h++){const g=a[h].indexOf("=");let R,N=null;g>=0?(R=a[h].substring(0,g),N=a[h].substring(g+1)):R=a[h],c(R,N?decodeURIComponent(N.replace(/\+/g," ")):"")}}}function Ce(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let c;a instanceof Ce?(this.l=a.l,hn(this,a.j),this.o=a.o,this.g=a.g,fn(this,a.u),this.h=a.h,qn(this,Gs(a.i)),this.m=a.m):a&&(c=String(a).match(Gt))?(this.l=!1,hn(this,c[1]||"",!0),this.o=fr(c[2]||""),this.g=fr(c[3]||"",!0),fn(this,c[4]),this.h=fr(c[5]||"",!0),qn(this,c[6]||"",!0),this.m=fr(c[7]||"")):(this.l=!1,this.i=new mr(null,this.l))}Ce.prototype.toString=function(){const a=[];var c=this.j;c&&a.push(pn(c,uo,!0),":");var h=this.g;return(h||c=="file")&&(a.push("//"),(c=this.o)&&a.push(pn(c,uo,!0),"@"),a.push(dn(h).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),h=this.u,h!=null&&a.push(":",String(h))),(h=this.h)&&(this.g&&h.charAt(0)!="/"&&a.push("/"),a.push(pn(h,h.charAt(0)=="/"?za:Fa,!0))),(h=this.i.toString())&&a.push("?",h),(h=this.m)&&a.push("#",pn(h,co)),a.join("")},Ce.prototype.resolve=function(a){const c=Oe(this);let h=!!a.j;h?hn(c,a.j):h=!!a.o,h?c.o=a.o:h=!!a.g,h?c.g=a.g:h=a.u!=null;var g=a.h;if(h)fn(c,a.u);else if(h=!!a.h){if(g.charAt(0)!="/")if(this.g&&!this.h)g="/"+g;else{var R=c.h.lastIndexOf("/");R!=-1&&(g=c.h.slice(0,R+1)+g)}if(R=g,R==".."||R==".")g="";else if(R.indexOf("./")!=-1||R.indexOf("/.")!=-1){g=R.lastIndexOf("/",0)==0,R=R.split("/");const N=[];for(let $=0;$<R.length;){const oe=R[$++];oe=="."?g&&$==R.length&&N.push(""):oe==".."?((N.length>1||N.length==1&&N[0]!="")&&N.pop(),g&&$==R.length&&N.push("")):(N.push(oe),g=!0)}g=N.join("/")}else g=R}return h?c.h=g:h=a.i.toString()!=="",h?qn(c,Gs(a.i)):h=!!a.m,h&&(c.m=a.m),c};function Oe(a){return new Ce(a)}function hn(a,c,h){a.j=h?fr(c,!0):c,a.j&&(a.j=a.j.replace(/:$/,""))}function fn(a,c){if(c){if(c=Number(c),isNaN(c)||c<0)throw Error("Bad port number "+c);a.u=c}else a.u=null}function qn(a,c,h){c instanceof mr?(a.i=c,cc(a.i,a.l)):(h||(c=pn(c,Ua)),a.i=new mr(c,a.l))}function ge(a,c,h){a.i.set(c,h)}function hs(a){return ge(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function fr(a,c){return a?c?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function pn(a,c,h){return typeof a=="string"?(a=encodeURI(a).replace(c,pr),h&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function pr(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var uo=/[#\/\?@]/g,Fa=/[#\?:]/g,za=/[#\?]/g,Ua=/[#\?@]/g,co=/#/g;function mr(a,c){this.h=this.g=null,this.i=a||null,this.j=!!c}function An(a){a.g||(a.g=new Map,a.h=0,a.i&&lo(a.i,function(c,h){a.add(decodeURIComponent(c.replace(/\+/g," ")),h)}))}t=mr.prototype,t.add=function(a,c){An(this),this.i=null,a=gr(this,a);let h=this.g.get(a);return h||this.g.set(a,h=[]),h.push(c),this.h+=1,this};function ho(a,c){An(a),c=gr(a,c),a.g.has(c)&&(a.i=null,a.h-=a.g.get(c).length,a.g.delete(c))}function Rt(a,c){return An(a),c=gr(a,c),a.g.has(c)}t.forEach=function(a,c){An(this),this.g.forEach(function(h,g){h.forEach(function(R){a.call(c,R,g,this)},this)},this)};function Ws(a,c){An(a);let h=[];if(typeof c=="string")Rt(a,c)&&(h=h.concat(a.g.get(gr(a,c))));else for(a=Array.from(a.g.values()),c=0;c<a.length;c++)h=h.concat(a[c]);return h}t.set=function(a,c){return An(this),this.i=null,a=gr(this,a),Rt(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[c]),this.h+=1,this},t.get=function(a,c){return a?(a=Ws(this,a),a.length>0?String(a[0]):c):c};function Ba(a,c,h){ho(a,c),h.length>0&&(a.i=null,a.g.set(gr(a,c),I(h)),a.h+=h.length)}t.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],c=Array.from(this.g.keys());for(let g=0;g<c.length;g++){var h=c[g];const R=dn(h);h=Ws(this,h);for(let N=0;N<h.length;N++){let $=R;h[N]!==""&&($+="="+dn(h[N])),a.push($)}}return this.i=a.join("&")};function Gs(a){const c=new mr;return c.i=a.i,a.g&&(c.g=new Map(a.g),c.h=a.h),c}function gr(a,c){return c=String(c),a.j&&(c=c.toLowerCase()),c}function cc(a,c){c&&!a.j&&(An(a),a.i=null,a.g.forEach(function(h,g){const R=g.toLowerCase();g!=R&&(ho(this,g),Ba(this,R,h))},a)),a.j=c}function dc(a,c){const h=new Hs;if(o.Image){const g=new Image;g.onload=f(q,h,"TestLoadImage: loaded",!0,c,g),g.onerror=f(q,h,"TestLoadImage: error",!1,c,g),g.onabort=f(q,h,"TestLoadImage: abort",!1,c,g),g.ontimeout=f(q,h,"TestLoadImage: timeout",!1,c,g),o.setTimeout(function(){g.ontimeout&&g.ontimeout()},1e4),g.src=a}else c(!1)}function z(a,c){const h=new Hs,g=new AbortController,R=setTimeout(()=>{g.abort(),q(h,"TestPingServer: timeout",!1,c)},1e4);fetch(a,{signal:g.signal}).then(N=>{clearTimeout(R),N.ok?q(h,"TestPingServer: ok",!0,c):q(h,"TestPingServer: server error",!1,c)}).catch(()=>{clearTimeout(R),q(h,"TestPingServer: error",!1,c)})}function q(a,c,h,g,R){try{R&&(R.onload=null,R.onerror=null,R.onabort=null,R.ontimeout=null),g(h)}catch{}}function O(){this.g=new Bs}function Z(a){this.i=a.Sb||null,this.h=a.ab||!1}m(Z,Zi),Z.prototype.g=function(){return new W(this.i,this.h)};function W(a,c){et.call(this),this.H=a,this.o=c,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}m(W,et),t=W.prototype,t.open=function(a,c){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=c,this.readyState=1,Fe(this)},t.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const c={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(c.body=a),(this.H||o).fetch(new Request(this.D,c)).then(this.Pa.bind(this),this.ga.bind(this))},t.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,de(this)),this.readyState=0},t.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,Fe(this)),this.g&&(this.readyState=3,Fe(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;te(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function te(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}t.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var c=a.value?a.value:new Uint8Array(0);(c=this.B.decode(c,{stream:!a.done}))&&(this.response=this.responseText+=c)}a.done?de(this):Fe(this),this.readyState==3&&te(this)}},t.Oa=function(a){this.g&&(this.response=this.responseText=a,de(this))},t.Na=function(a){this.g&&(this.response=a,de(this))},t.ga=function(){this.g&&de(this)};function de(a){a.readyState=4,a.l=null,a.j=null,a.B=null,Fe(a)}t.setRequestHeader=function(a,c){this.A.append(a,c)},t.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},t.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],c=this.h.entries();for(var h=c.next();!h.done;)h=h.value,a.push(h[0]+": "+h[1]),h=c.next();return a.join(`\r
`)};function Fe(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(W.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function rt(a){let c="";return Y(a,function(h,g){c+=g,c+=":",c+=h,c+=`\r
`}),c}function Kt(a,c,h){e:{for(g in h){var g=!1;break e}g=!0}g||(h=rt(h),typeof a=="string"?h!=null&&dn(h):ge(a,c,h))}function pe(a){et.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}m(pe,et);var yr=/^https?$/i,Ne=["POST","PUT"];t=pe.prototype,t.Fa=function(a){this.H=a},t.ea=function(a,c,h,g){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);c=c?c.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():nt.g(),this.g.onreadystatechange=v(d(this.Ca,this));try{this.B=!0,this.g.open(c,String(a),!0),this.B=!1}catch(N){bt(this,N);return}if(a=h||"",h=new Map(this.headers),g)if(Object.getPrototypeOf(g)===Object.prototype)for(var R in g)h.set(R,g[R]);else if(typeof g.keys=="function"&&typeof g.get=="function")for(const N of g.keys())h.set(N,g.get(N));else throw Error("Unknown input type for opt_headers: "+String(g));g=Array.from(h.keys()).find(N=>N.toLowerCase()=="content-type"),R=o.FormData&&a instanceof o.FormData,!(Array.prototype.indexOf.call(Ne,c,void 0)>=0)||g||R||h.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[N,$]of h)this.g.setRequestHeader(N,$);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(N){bt(this,N)}};function bt(a,c){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=c,a.o=5,Ks(a),Qt(a)}function Ks(a){a.A||(a.A=!0,tt(a,"complete"),tt(a,"error"))}t.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,tt(this,"complete"),tt(this,"abort"),Qt(this))},t.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Qt(this,!0)),pe.Z.N.call(this)},t.Ca=function(){this.u||(this.B||this.v||this.j?Qs(this):this.Xa())},t.Xa=function(){Qs(this)};function Qs(a){if(a.h&&typeof i<"u"){if(a.v&&Yt(a)==4)setTimeout(a.Ca.bind(a),0);else if(tt(a,"readystatechange"),Yt(a)==4){a.h=!1;try{const N=a.ca();e:switch(N){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var c=!0;break e;default:c=!1}var h;if(!(h=c)){var g;if(g=N===0){let $=String(a.D).match(Gt)[1]||null;!$&&o.self&&o.self.location&&($=o.self.location.protocol.slice(0,-1)),g=!yr.test($?$.toLowerCase():"")}h=g}if(h)tt(a,"complete"),tt(a,"success");else{a.o=6;try{var R=Yt(a)>2?a.g.statusText:""}catch{R=""}a.l=R+" ["+a.ca()+"]",Ks(a)}}finally{Qt(a)}}}}function Qt(a,c){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const h=a.g;a.g=null,c||tt(a,"ready");try{h.onreadystatechange=null}catch{}}}t.isActive=function(){return!!this.g};function Yt(a){return a.g?a.g.readyState:0}t.ca=function(){try{return Yt(this)>2?this.g.status:-1}catch{return-1}},t.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},t.La=function(a){if(this.g){var c=this.g.responseText;return a&&c.indexOf(a)==0&&(c=c.substring(a.length)),ar(c)}};function $a(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function hc(a){const c={};a=(a.g&&Yt(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let g=0;g<a.length;g++){if(E(a[g]))continue;var h=cr(a[g]);const R=h[0];if(h=h[1],typeof h!="string")continue;h=h.trim();const N=c[R]||[];c[R]=N,N.push(h)}ne(c,function(g){return g.join(", ")})}t.ya=function(){return this.o},t.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function fs(a,c,h){return h&&h.internalChannelParams&&h.internalChannelParams[a]||c}function ip(a){this.za=0,this.i=[],this.j=new Hs,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=fs("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=fs("baseRetryDelayMs",5e3,a),this.Za=fs("retryDelaySeedMs",1e4,a),this.Ta=fs("forwardChannelMaxRetries",2,a),this.va=fs("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new ao(a&&a.concurrentRequestLimit),this.Ba=new O,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}t=ip.prototype,t.ka=8,t.I=1,t.connect=function(a,c,h,g){Qe(0),this.W=a,this.H=c||{},h&&g!==void 0&&(this.H.OSID=h,this.H.OAID=g),this.F=this.X,this.J=pp(this,null,this.W),Ha(this)};function fc(a){if(op(a),a.I==3){var c=a.V++,h=Oe(a.J);if(ge(h,"SID",a.M),ge(h,"RID",c),ge(h,"TYPE","terminate"),fo(a,h),c=new Un(a,a.j,c),c.M=2,c.A=hs(Oe(h)),h=!1,o.navigator&&o.navigator.sendBeacon)try{h=o.navigator.sendBeacon(c.A.toString(),"")}catch{}!h&&o.Image&&(new Image().src=c.A,h=!0),h||(c.g=mp(c.j,null),c.g.ea(c.A)),c.F=Date.now(),Se(c)}fp(a)}function qa(a){a.g&&(mc(a),a.g.cancel(),a.g=null)}function op(a){qa(a),a.v&&(o.clearTimeout(a.v),a.v=null),Wa(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&o.clearTimeout(a.m),a.m=null)}function Ha(a){if(!Ct(a.h)&&!a.m){a.m=!0;var c=a.Ea;F||y(),B||(F(),B=!0),w.add(c,a),a.D=0}}function h_(a,c){return cs(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=c.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=is(d(a.Ea,a,c),hp(a,a.D)),a.D++,!0)}t.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const R=new Un(this,this.j,a);let N=this.o;if(this.U&&(N?(N=ie(N),ln(N,this.U)):N=this.U),this.u!==null||this.R||(R.J=N,N=null),this.S)e:{for(var c=0,h=0;h<this.i.length;h++){t:{var g=this.i[h];if("__data__"in g.map&&(g=g.map.__data__,typeof g=="string")){g=g.length;break t}g=void 0}if(g===void 0)break;if(c+=g,c>4096){c=h;break e}if(c===4096||h===this.i.length-1){c=h+1;break e}}c=1e3}else c=1e3;c=lp(this,R,c),h=Oe(this.J),ge(h,"RID",a),ge(h,"CVER",22),this.G&&ge(h,"X-HTTP-Session-Id",this.G),fo(this,h),N&&(this.R?c="headers="+dn(rt(N))+"&"+c:this.u&&Kt(h,this.u,N)),ds(this.h,R),this.Ra&&ge(h,"TYPE","init"),this.S?(ge(h,"$req",c),ge(h,"SID","null"),R.U=!0,dr(R,h,null)):dr(R,h,c),this.I=2}}else this.I==3&&(a?ap(this,a):this.i.length==0||Ct(this.h)||ap(this))};function ap(a,c){var h;c?h=c.l:h=a.V++;const g=Oe(a.J);ge(g,"SID",a.M),ge(g,"RID",h),ge(g,"AID",a.K),fo(a,g),a.u&&a.o&&Kt(g,a.u,a.o),h=new Un(a,a.j,h,a.D+1),a.u===null&&(h.J=a.o),c&&(a.i=c.G.concat(a.i)),c=lp(a,h,1e3),h.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),ds(a.h,h),dr(h,g,c)}function fo(a,c){a.H&&Y(a.H,function(h,g){ge(c,g,h)}),a.l&&Y({},function(h,g){ge(c,g,h)})}function lp(a,c,h){h=Math.min(a.i.length,h);const g=a.l?d(a.l.Ka,a.l,a):null;e:{var R=a.i;let oe=-1;for(;;){const Ye=["count="+h];oe==-1?h>0?(oe=R[0].g,Ye.push("ofs="+oe)):oe=0:Ye.push("ofs="+oe);let we=!0;for(let st=0;st<h;st++){var N=R[st].g;const Cn=R[st].map;if(N-=oe,N<0)oe=Math.max(0,R[st].g-100),we=!1;else try{N="req"+N+"_"||"";try{var $=Cn instanceof Map?Cn:Object.entries(Cn);for(const[ms,vr]of $){let _r=vr;l(vr)&&(_r=Sn(vr)),Ye.push(N+ms+"="+encodeURIComponent(_r))}}catch(ms){throw Ye.push(N+"type="+encodeURIComponent("_badmap")),ms}}catch{g&&g(Cn)}}if(we){$=Ye.join("&");break e}}$=void 0}return a=a.i.splice(0,h),c.G=a,$}function up(a){if(!a.g&&!a.v){a.Y=1;var c=a.Da;F||y(),B||(F(),B=!0),w.add(c,a),a.A=0}}function pc(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=is(d(a.Da,a),hp(a,a.A)),a.A++,!0)}t.Da=function(){if(this.v=null,cp(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=is(d(this.Wa,this),a)}},t.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Qe(10),qa(this),cp(this))};function mc(a){a.B!=null&&(o.clearTimeout(a.B),a.B=null)}function cp(a){a.g=new Un(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var c=Oe(a.na);ge(c,"RID","rpc"),ge(c,"SID",a.M),ge(c,"AID",a.K),ge(c,"CI",a.F?"0":"1"),!a.F&&a.ia&&ge(c,"TO",a.ia),ge(c,"TYPE","xmlhttp"),fo(a,c),a.u&&a.o&&Kt(c,a.u,a.o),a.O&&(a.g.H=a.O);var h=a.g;a=a.ba,h.M=1,h.A=hs(Oe(c)),h.u=null,h.R=!0,La(h,a)}t.Va=function(){this.C!=null&&(this.C=null,qa(this),pc(this),Qe(19))};function Wa(a){a.C!=null&&(o.clearTimeout(a.C),a.C=null)}function dp(a,c){var h=null;if(a.g==c){Wa(a),mc(a),a.g=null;var g=2}else if(qe(a.h,c))h=c.G,$n(a.h,c),g=1;else return;if(a.I!=0){if(c.o)if(g==1){h=c.u?c.u.length:0,c=Date.now()-c.F;var R=a.D;g=rs(),tt(g,new ro(g,h)),Ha(a)}else up(a);else if(R=c.m,R==3||R==0&&c.X>0||!(g==1&&h_(a,c)||g==2&&pc(a)))switch(h&&h.length>0&&(c=a.h,c.i=c.i.concat(h)),R){case 1:ps(a,5);break;case 4:ps(a,10);break;case 3:ps(a,6);break;default:ps(a,2)}}}function hp(a,c){let h=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(h*=2),h*c}function ps(a,c){if(a.j.info("Error code "+c),c==2){var h=d(a.bb,a),g=a.Ua;const R=!g;g=new Ce(g||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||hn(g,"https"),hs(g),R?dc(g.toString(),h):z(g.toString(),h)}else Qe(2);a.I=0,a.l&&a.l.pa(c),fp(a),op(a)}t.bb=function(a){a?(this.j.info("Successfully pinged google.com"),Qe(2)):(this.j.info("Failed to ping google.com"),Qe(1))};function fp(a){if(a.I=0,a.ja=[],a.l){const c=hr(a.h);(c.length!=0||a.i.length!=0)&&(A(a.ja,c),A(a.ja,a.i),a.h.i.length=0,I(a.i),a.i.length=0),a.l.oa()}}function pp(a,c,h){var g=h instanceof Ce?Oe(h):new Ce(h);if(g.g!="")c&&(g.g=c+"."+g.g),fn(g,g.u);else{var R=o.location;g=R.protocol,c=c?c+"."+R.hostname:R.hostname,R=+R.port;const N=new Ce(null);g&&hn(N,g),c&&(N.g=c),R&&fn(N,R),h&&(N.h=h),g=N}return h=a.G,c=a.wa,h&&c&&ge(g,h,c),ge(g,"VER",a.ka),fo(a,g),g}function mp(a,c,h){if(c&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return c=a.Aa&&!a.ma?new pe(new Z({ab:h})):new pe(a.ma),c.Fa(a.L),c}t.isActive=function(){return!!this.l&&this.l.isActive(this)};function gp(){}t=gp.prototype,t.ra=function(){},t.qa=function(){},t.pa=function(){},t.oa=function(){},t.isActive=function(){return!0},t.Ka=function(){};function Ga(){}Ga.prototype.g=function(a,c){return new jt(a,c)};function jt(a,c){et.call(this),this.g=new ip(c),this.l=a,this.h=c&&c.messageUrlParams||null,a=c&&c.messageHeaders||null,c&&c.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=c&&c.initMessageHeaders||null,c&&c.messageContentType&&(a?a["X-WebChannel-Content-Type"]=c.messageContentType:a={"X-WebChannel-Content-Type":c.messageContentType}),c&&c.sa&&(a?a["X-WebChannel-Client-Profile"]=c.sa:a={"X-WebChannel-Client-Profile":c.sa}),this.g.U=a,(a=c&&c.Qb)&&!E(a)&&(this.g.u=a),this.A=c&&c.supportsCrossDomainXhr||!1,this.v=c&&c.sendRawJson||!1,(c=c&&c.httpSessionIdParam)&&!E(c)&&(this.g.G=c,a=this.h,a!==null&&c in a&&(a=this.h,c in a&&delete a[c])),this.j=new Ys(this)}m(jt,et),jt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},jt.prototype.close=function(){fc(this.g)},jt.prototype.o=function(a){var c=this.g;if(typeof a=="string"){var h={};h.__data__=a,a=h}else this.v&&(h={},h.__data__=Sn(a),a=h);c.i.push(new Oa(c.Ya++,a)),c.I==3&&Ha(c)},jt.prototype.N=function(){this.g.l=null,delete this.j,fc(this.g),delete this.g,jt.Z.N.call(this)};function yp(a){$s.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var c=a.__sm__;if(c){e:{for(const h in c){a=h;break e}a=void 0}(this.i=a)&&(a=this.i,c=c!==null&&a in c?c[a]:void 0),this.data=c}else this.data=a}m(yp,$s);function vp(){to.call(this),this.status=1}m(vp,to);function Ys(a){this.g=a}m(Ys,gp),Ys.prototype.ra=function(){tt(this.g,"a")},Ys.prototype.qa=function(a){tt(this.g,new yp(a))},Ys.prototype.pa=function(a){tt(this.g,new vp)},Ys.prototype.oa=function(){tt(this.g,"b")},Ga.prototype.createWebChannel=Ga.prototype.g,jt.prototype.send=jt.prototype.o,jt.prototype.open=jt.prototype.m,jt.prototype.close=jt.prototype.close,Sv=function(){return new Ga},bv=function(){return rs()},Tv=kn,Jd={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},ur.NO_ERROR=0,ur.TIMEOUT=8,ur.HTTP_ERROR=6,Vl=ur,so.COMPLETE="complete",Ev=so,eo.EventType=ns,ns.OPEN="a",ns.CLOSE="b",ns.ERROR="c",ns.MESSAGE="d",et.prototype.listen=et.prototype.J,Ao=eo,pe.prototype.listenOnce=pe.prototype.K,pe.prototype.getLastError=pe.prototype.Ha,pe.prototype.getLastErrorCode=pe.prototype.ya,pe.prototype.getStatus=pe.prototype.ca,pe.prototype.getResponseJson=pe.prototype.La,pe.prototype.getResponseText=pe.prototype.la,pe.prototype.send=pe.prototype.ea,pe.prototype.setWithCredentials=pe.prototype.Fa,xv=pe}).apply(typeof hl<"u"?hl:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}vt.UNAUTHENTICATED=new vt(null),vt.GOOGLE_CREDENTIALS=new vt("google-credentials-uid"),vt.FIRST_PARTY=new vt("first-party-uid"),vt.MOCK_USER=new vt("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let $i="12.12.0";function TE(t){$i=t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ps=new pv("@firebase/firestore");function Js(){return Ps.logLevel}function K(t,...e){if(Ps.logLevel<=fe.DEBUG){const n=e.map(yf);Ps.debug(`Firestore (${$i}): ${t}`,...n)}}function nr(t,...e){if(Ps.logLevel<=fe.ERROR){const n=e.map(yf);Ps.error(`Firestore (${$i}): ${t}`,...n)}}function Ns(t,...e){if(Ps.logLevel<=fe.WARN){const n=e.map(yf);Ps.warn(`Firestore (${$i}): ${t}`,...n)}}function yf(t){if(typeof t=="string")return t;try{return function(n){return JSON.stringify(n)}(t)}catch{return t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(t,e,n){let r="Unexpected state";typeof e=="string"?r=e:n=e,kv(t,r,n)}function kv(t,e,n){let r=`FIRESTORE (${$i}) INTERNAL ASSERTION FAILED: ${e} (ID: ${t.toString(16)})`;if(n!==void 0)try{r+=" CONTEXT: "+JSON.stringify(n)}catch{r+=" CONTEXT: "+n}throw nr(r),new Error(r)}function ye(t,e,n,r){let s="Unexpected state";typeof n=="string"?s=n:r=n,t||kv(e,s,r)}function se(t,e){return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const L={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class G extends Bi{constructor(e,n){super(e,n),this.code=e,this.message=n,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zr{constructor(){this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iv{constructor(e,n){this.user=n,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class bE{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,n){e.enqueueRetryable(()=>n(vt.UNAUTHENTICATED))}shutdown(){}}class SE{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,n){this.changeListener=n,e.enqueueRetryable(()=>n(this.token.user))}shutdown(){this.changeListener=null}}class kE{constructor(e){this.t=e,this.currentUser=vt.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,n){ye(this.o===void 0,42304);let r=this.i;const s=u=>this.i!==r?(r=this.i,n(u)):Promise.resolve();let i=new zr;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new zr,e.enqueueRetryable(()=>s(this.currentUser))};const o=()=>{const u=i;e.enqueueRetryable(async()=>{await u.promise,await s(this.currentUser)})},l=u=>{K("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.o&&(this.auth.addAuthTokenListener(this.o),o())};this.t.onInit(u=>l(u)),setTimeout(()=>{if(!this.auth){const u=this.t.getImmediate({optional:!0});u?l(u):(K("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new zr)}},0),o()}getToken(){const e=this.i,n=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(n).then(r=>this.i!==e?(K("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(ye(typeof r.accessToken=="string",31837,{l:r}),new Iv(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return ye(e===null||typeof e=="string",2055,{h:e}),new vt(e)}}class IE{constructor(e,n,r){this.P=e,this.T=n,this.I=r,this.type="FirstParty",this.user=vt.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class AE{constructor(e,n,r){this.P=e,this.T=n,this.I=r}getToken(){return Promise.resolve(new IE(this.P,this.T,this.I))}start(e,n){e.enqueueRetryable(()=>n(vt.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class zm{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class CE{constructor(e,n){this.V=n,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,oE(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,n){ye(this.o===void 0,3512);const r=i=>{i.error!=null&&K("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.m;return this.m=i.token,K("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?n(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable(()=>r(i))};const s=i=>{K("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(i=>s(i)),setTimeout(()=>{if(!this.appCheck){const i=this.V.getImmediate({optional:!0});i?s(i):K("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new zm(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(n=>n?(ye(typeof n.token=="string",44558,{tokenResult:n}),this.m=n.token,new zm(n.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function RE(t){const e=typeof self<"u"&&(self.crypto||self.msCrypto),n=new Uint8Array(t);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(n);else for(let r=0;r<t;r++)n[r]=Math.floor(256*Math.random());return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vf{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",n=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const s=RE(40);for(let i=0;i<s.length;++i)r.length<20&&s[i]<n&&(r+=e.charAt(s[i]%62))}return r}}function le(t,e){return t<e?-1:t>e?1:0}function Zd(t,e){const n=Math.min(t.length,e.length);for(let r=0;r<n;r++){const s=t.charAt(r),i=e.charAt(r);if(s!==i)return Gc(s)===Gc(i)?le(s,i):Gc(s)?1:-1}return le(t.length,e.length)}const PE=55296,NE=57343;function Gc(t){const e=t.charCodeAt(0);return e>=PE&&e<=NE}function Di(t,e,n){return t.length===e.length&&t.every((r,s)=>n(r,e[s]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Um="__name__";class Nn{constructor(e,n,r){n===void 0?n=0:n>e.length&&ee(637,{offset:n,range:e.length}),r===void 0?r=e.length-n:r>e.length-n&&ee(1746,{length:r,range:e.length-n}),this.segments=e,this.offset=n,this.len=r}get length(){return this.len}isEqual(e){return Nn.comparator(this,e)===0}child(e){const n=this.segments.slice(this.offset,this.limit());return e instanceof Nn?e.forEach(r=>{n.push(r)}):n.push(e),this.construct(n)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let n=0;n<this.length;n++)if(this.get(n)!==e.get(n))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let n=0;n<this.length;n++)if(this.get(n)!==e.get(n))return!1;return!0}forEach(e){for(let n=this.offset,r=this.limit();n<r;n++)e(this.segments[n])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,n){const r=Math.min(e.length,n.length);for(let s=0;s<r;s++){const i=Nn.compareSegments(e.get(s),n.get(s));if(i!==0)return i}return le(e.length,n.length)}static compareSegments(e,n){const r=Nn.isNumericId(e),s=Nn.isNumericId(n);return r&&!s?-1:!r&&s?1:r&&s?Nn.extractNumericId(e).compare(Nn.extractNumericId(n)):Zd(e,n)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Fr.fromString(e.substring(4,e.length-2))}}class xe extends Nn{construct(e,n,r){return new xe(e,n,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const n=[];for(const r of e){if(r.indexOf("//")>=0)throw new G(L.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);n.push(...r.split("/").filter(s=>s.length>0))}return new xe(n)}static emptyPath(){return new xe([])}}const VE=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class dt extends Nn{construct(e,n,r){return new dt(e,n,r)}static isValidIdentifier(e){return VE.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),dt.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Um}static keyField(){return new dt([Um])}static fromServerFormat(e){const n=[];let r="",s=0;const i=()=>{if(r.length===0)throw new G(L.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);n.push(r),r=""};let o=!1;for(;s<e.length;){const l=e[s];if(l==="\\"){if(s+1===e.length)throw new G(L.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[s+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new G(L.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=u,s+=2}else l==="`"?(o=!o,s++):l!=="."||o?(r+=l,s++):(i(),s++)}if(i(),o)throw new G(L.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new dt(n)}static emptyPath(){return new dt([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X{constructor(e){this.path=e}static fromPath(e){return new X(xe.fromString(e))}static fromName(e){return new X(xe.fromString(e).popFirst(5))}static empty(){return new X(xe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&xe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,n){return xe.comparator(e.path,n.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new X(new xe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Av(t,e,n){if(!n)throw new G(L.INVALID_ARGUMENT,`Function ${t}() cannot be called with an empty ${e}.`)}function DE(t,e,n,r){if(e===!0&&r===!0)throw new G(L.INVALID_ARGUMENT,`${t} and ${n} cannot be used together.`)}function Bm(t){if(!X.isDocumentKey(t))throw new G(L.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`)}function $m(t){if(X.isDocumentKey(t))throw new G(L.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${t} has ${t.length}.`)}function Cv(t){return typeof t=="object"&&t!==null&&(Object.getPrototypeOf(t)===Object.prototype||Object.getPrototypeOf(t)===null)}function qu(t){if(t===void 0)return"undefined";if(t===null)return"null";if(typeof t=="string")return t.length>20&&(t=`${t.substring(0,20)}...`),JSON.stringify(t);if(typeof t=="number"||typeof t=="boolean")return""+t;if(typeof t=="object"){if(t instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(t);return e?`a custom ${e} object`:"an object"}}return typeof t=="function"?"a function":ee(12329,{type:typeof t})}function hu(t,e){if("_delegate"in t&&(t=t._delegate),!(t instanceof e)){if(e.name===t.constructor.name)throw new G(L.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const n=qu(t);throw new G(L.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${n}`)}}return t}function ME(t,e){if(e<=0)throw new G(L.INVALID_ARGUMENT,`Function ${t}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ke(t,e){const n={typeString:t};return e&&(n.value=e),n}function ka(t,e){if(!Cv(t))throw new G(L.INVALID_ARGUMENT,"JSON must be an object");let n;for(const r in e)if(e[r]){const s=e[r].typeString,i="value"in e[r]?{value:e[r].value}:void 0;if(!(r in t)){n=`JSON missing required field: '${r}'`;break}const o=t[r];if(s&&typeof o!==s){n=`JSON field '${r}' must be a ${s}.`;break}if(i!==void 0&&o!==i.value){n=`Expected '${r}' field to equal '${i.value}'`;break}}if(n)throw new G(L.INVALID_ARGUMENT,n);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qm=-62135596800,Hm=1e6;class Ie{static now(){return Ie.fromMillis(Date.now())}static fromDate(e){return Ie.fromMillis(e.getTime())}static fromMillis(e){const n=Math.floor(e/1e3),r=Math.floor((e-1e3*n)*Hm);return new Ie(n,r)}constructor(e,n){if(this.seconds=e,this.nanoseconds=n,n<0)throw new G(L.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+n);if(n>=1e9)throw new G(L.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+n);if(e<qm)throw new G(L.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new G(L.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Hm}_compareTo(e){return this.seconds===e.seconds?le(this.nanoseconds,e.nanoseconds):le(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Ie._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(ka(e,Ie._jsonSchema))return new Ie(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-qm;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Ie._jsonSchemaVersion="firestore/timestamp/1.0",Ie._jsonSchema={type:Ke("string",Ie._jsonSchemaVersion),seconds:Ke("number"),nanoseconds:Ke("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class re{static fromTimestamp(e){return new re(e)}static min(){return new re(new Ie(0,0))}static max(){return new re(new Ie(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ha=-1;function LE(t,e){const n=t.toTimestamp().seconds,r=t.toTimestamp().nanoseconds+1,s=re.fromTimestamp(r===1e9?new Ie(n+1,0):new Ie(n,r));return new qr(s,X.empty(),e)}function jE(t){return new qr(t.readTime,t.key,ha)}class qr{constructor(e,n,r){this.readTime=e,this.documentKey=n,this.largestBatchId=r}static min(){return new qr(re.min(),X.empty(),ha)}static max(){return new qr(re.max(),X.empty(),ha)}}function OE(t,e){let n=t.readTime.compareTo(e.readTime);return n!==0?n:(n=X.comparator(t.documentKey,e.documentKey),n!==0?n:le(t.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FE="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class zE{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qi(t){if(t.code!==L.FAILED_PRECONDITION||t.message!==FE)throw t;K("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class j{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(n=>{this.isDone=!0,this.result=n,this.nextCallback&&this.nextCallback(n)},n=>{this.isDone=!0,this.error=n,this.catchCallback&&this.catchCallback(n)})}catch(e){return this.next(void 0,e)}next(e,n){return this.callbackAttached&&ee(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(n,this.error):this.wrapSuccess(e,this.result):new j((r,s)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(r,s)},this.catchCallback=i=>{this.wrapFailure(n,i).next(r,s)}})}toPromise(){return new Promise((e,n)=>{this.next(e,n)})}wrapUserFunction(e){try{const n=e();return n instanceof j?n:j.resolve(n)}catch(n){return j.reject(n)}}wrapSuccess(e,n){return e?this.wrapUserFunction(()=>e(n)):j.resolve(n)}wrapFailure(e,n){return e?this.wrapUserFunction(()=>e(n)):j.reject(n)}static resolve(e){return new j((n,r)=>{n(e)})}static reject(e){return new j((n,r)=>{r(e)})}static waitFor(e){return new j((n,r)=>{let s=0,i=0,o=!1;e.forEach(l=>{++s,l.next(()=>{++i,o&&i===s&&n()},u=>r(u))}),o=!0,i===s&&n()})}static or(e){let n=j.resolve(!1);for(const r of e)n=n.next(s=>s?j.resolve(s):r());return n}static forEach(e,n){const r=[];return e.forEach((s,i)=>{r.push(n.call(this,s,i))}),this.waitFor(r)}static mapArray(e,n){return new j((r,s)=>{const i=e.length,o=new Array(i);let l=0;for(let u=0;u<i;u++){const d=u;n(e[d]).next(f=>{o[d]=f,++l,l===i&&r(o)},f=>s(f))}})}static doWhile(e,n){return new j((r,s)=>{const i=()=>{e()===!0?n().next(()=>{i()},s):r()};i()})}}function UE(t){const e=t.match(/Android ([\d.]+)/i),n=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(n)}function Hi(t){return t.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hu{constructor(e,n){this.previousValue=e,n&&(n.sequenceNumberHandler=r=>this.ae(r),this.ue=r=>n.writeSequenceNumber(r))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}Hu.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _f=-1;function Wu(t){return t==null}function fu(t){return t===0&&1/t==-1/0}function BE(t){return typeof t=="number"&&Number.isInteger(t)&&!fu(t)&&t<=Number.MAX_SAFE_INTEGER&&t>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rv="";function $E(t){let e="";for(let n=0;n<t.length;n++)e.length>0&&(e=Wm(e)),e=qE(t.get(n),e);return Wm(e)}function qE(t,e){let n=e;const r=t.length;for(let s=0;s<r;s++){const i=t.charAt(s);switch(i){case"\0":n+="";break;case Rv:n+="";break;default:n+=i}}return n}function Wm(t){return t+Rv+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gm(t){let e=0;for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e++;return e}function Ls(t,e){for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e(n,t[n])}function Pv(t){for(const e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e,n){this.comparator=e,this.root=n||ct.EMPTY}insert(e,n){return new Le(this.comparator,this.root.insert(e,n,this.comparator).copy(null,null,ct.BLACK,null,null))}remove(e){return new Le(this.comparator,this.root.remove(e,this.comparator).copy(null,null,ct.BLACK,null,null))}get(e){let n=this.root;for(;!n.isEmpty();){const r=this.comparator(e,n.key);if(r===0)return n.value;r<0?n=n.left:r>0&&(n=n.right)}return null}indexOf(e){let n=0,r=this.root;for(;!r.isEmpty();){const s=this.comparator(e,r.key);if(s===0)return n+r.left.size;s<0?r=r.left:(n+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((n,r)=>(e(n,r),!1))}toString(){const e=[];return this.inorderTraversal((n,r)=>(e.push(`${n}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new fl(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new fl(this.root,e,this.comparator,!1)}getReverseIterator(){return new fl(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new fl(this.root,e,this.comparator,!0)}}class fl{constructor(e,n,r,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=n?r(e.key,n):1,n&&s&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const n={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return n}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class ct{constructor(e,n,r,s,i){this.key=e,this.value=n,this.color=r??ct.RED,this.left=s??ct.EMPTY,this.right=i??ct.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,n,r,s,i){return new ct(e??this.key,n??this.value,r??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,n,r){let s=this;const i=r(e,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(e,n,r),null):i===0?s.copy(null,n,null,null,null):s.copy(null,null,null,null,s.right.insert(e,n,r)),s.fixUp()}removeMin(){if(this.left.isEmpty())return ct.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,n){let r,s=this;if(n(e,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(e,n),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),n(e,s.key)===0){if(s.right.isEmpty())return ct.EMPTY;r=s.right.min(),s=s.copy(r.key,r.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(e,n))}return s.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ct.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ct.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),n=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,n)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw ee(43730,{key:this.key,value:this.value});if(this.right.isRed())throw ee(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw ee(27949);return e+(this.isRed()?0:1)}}ct.EMPTY=null,ct.RED=!0,ct.BLACK=!1;ct.EMPTY=new class{constructor(){this.size=0}get key(){throw ee(57766)}get value(){throw ee(16141)}get color(){throw ee(16727)}get left(){throw ee(29726)}get right(){throw ee(36894)}copy(e,n,r,s,i){return this}insert(e,n,r){return new ct(e,n)}remove(e,n){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ze{constructor(e){this.comparator=e,this.data=new Le(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((n,r)=>(e(n),!1))}forEachInRange(e,n){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const s=r.getNext();if(this.comparator(s.key,e[1])>=0)return;n(s.key)}}forEachWhile(e,n){let r;for(r=n!==void 0?this.data.getIteratorFrom(n):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const n=this.data.getIteratorFrom(e);return n.hasNext()?n.getNext().key:null}getIterator(){return new Km(this.data.getIterator())}getIteratorFrom(e){return new Km(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let n=this;return n.size<e.size&&(n=e,e=this),e.forEach(r=>{n=n.add(r)}),n}isEqual(e){if(!(e instanceof Ze)||this.size!==e.size)return!1;const n=this.data.getIterator(),r=e.data.getIterator();for(;n.hasNext();){const s=n.getNext().key,i=r.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(n=>{e.push(n)}),e}toString(){const e=[];return this.forEach(n=>e.push(n)),"SortedSet("+e.toString()+")"}copy(e){const n=new Ze(this.comparator);return n.data=e,n}}class Km{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n{constructor(e){this.fields=e,e.sort(dt.comparator)}static empty(){return new _n([])}unionWith(e){let n=new Ze(dt.comparator);for(const r of this.fields)n=n.add(r);for(const r of e)n=n.add(r);return new _n(n.toArray())}covers(e){for(const n of this.fields)if(n.isPrefixOf(e))return!0;return!1}isEqual(e){return Di(this.fields,e.fields,(n,r)=>n.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nv extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pt{constructor(e){this.binaryString=e}static fromBase64String(e){const n=function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new Nv("Invalid base64 string: "+i):i}}(e);return new pt(n)}static fromUint8Array(e){const n=function(s){let i="";for(let o=0;o<s.length;++o)i+=String.fromCharCode(s[o]);return i}(e);return new pt(n)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(n){return btoa(n)}(this.binaryString)}toUint8Array(){return function(n){const r=new Uint8Array(n.length);for(let s=0;s<n.length;s++)r[s]=n.charCodeAt(s);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return le(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}pt.EMPTY_BYTE_STRING=new pt("");const HE=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Hr(t){if(ye(!!t,39018),typeof t=="string"){let e=0;const n=HE.exec(t);if(ye(!!n,46558,{timestamp:t}),n[1]){let s=n[1];s=(s+"000000000").substr(0,9),e=Number(s)}const r=new Date(t);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:Be(t.seconds),nanos:Be(t.nanos)}}function Be(t){return typeof t=="number"?t:typeof t=="string"?Number(t):0}function Wr(t){return typeof t=="string"?pt.fromBase64String(t):pt.fromUint8Array(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vv="server_timestamp",Dv="__type__",Mv="__previous_value__",Lv="__local_write_time__";function wf(t){var n,r;return((r=(((n=t==null?void 0:t.mapValue)==null?void 0:n.fields)||{})[Dv])==null?void 0:r.stringValue)===Vv}function Gu(t){const e=t.mapValue.fields[Mv];return wf(e)?Gu(e):e}function fa(t){const e=Hr(t.mapValue.fields[Lv].timestampValue);return new Ie(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WE{constructor(e,n,r,s,i,o,l,u,d,f,m){this.databaseId=e,this.appId=n,this.persistenceKey=r,this.host=s,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=l,this.longPollingOptions=u,this.useFetchStreams=d,this.isUsingEmulator=f,this.apiKey=m}}const pu="(default)";class pa{constructor(e,n){this.projectId=e,this.database=n||pu}static empty(){return new pa("","")}get isDefaultDatabase(){return this.database===pu}isEqual(e){return e instanceof pa&&e.projectId===this.projectId&&e.database===this.database}}function GE(t,e){if(!Object.prototype.hasOwnProperty.apply(t.options,["projectId"]))throw new G(L.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new pa(t.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jv="__type__",KE="__max__",pl={mapValue:{}},Ov="__vector__",mu="value";function Gr(t){return"nullValue"in t?0:"booleanValue"in t?1:"integerValue"in t||"doubleValue"in t?2:"timestampValue"in t?3:"stringValue"in t?5:"bytesValue"in t?6:"referenceValue"in t?7:"geoPointValue"in t?8:"arrayValue"in t?9:"mapValue"in t?wf(t)?4:YE(t)?9007199254740991:QE(t)?10:11:ee(28295,{value:t})}function zn(t,e){if(t===e)return!0;const n=Gr(t);if(n!==Gr(e))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return t.booleanValue===e.booleanValue;case 4:return fa(t).isEqual(fa(e));case 3:return function(s,i){if(typeof s.timestampValue=="string"&&typeof i.timestampValue=="string"&&s.timestampValue.length===i.timestampValue.length)return s.timestampValue===i.timestampValue;const o=Hr(s.timestampValue),l=Hr(i.timestampValue);return o.seconds===l.seconds&&o.nanos===l.nanos}(t,e);case 5:return t.stringValue===e.stringValue;case 6:return function(s,i){return Wr(s.bytesValue).isEqual(Wr(i.bytesValue))}(t,e);case 7:return t.referenceValue===e.referenceValue;case 8:return function(s,i){return Be(s.geoPointValue.latitude)===Be(i.geoPointValue.latitude)&&Be(s.geoPointValue.longitude)===Be(i.geoPointValue.longitude)}(t,e);case 2:return function(s,i){if("integerValue"in s&&"integerValue"in i)return Be(s.integerValue)===Be(i.integerValue);if("doubleValue"in s&&"doubleValue"in i){const o=Be(s.doubleValue),l=Be(i.doubleValue);return o===l?fu(o)===fu(l):isNaN(o)&&isNaN(l)}return!1}(t,e);case 9:return Di(t.arrayValue.values||[],e.arrayValue.values||[],zn);case 10:case 11:return function(s,i){const o=s.mapValue.fields||{},l=i.mapValue.fields||{};if(Gm(o)!==Gm(l))return!1;for(const u in o)if(o.hasOwnProperty(u)&&(l[u]===void 0||!zn(o[u],l[u])))return!1;return!0}(t,e);default:return ee(52216,{left:t})}}function ma(t,e){return(t.values||[]).find(n=>zn(n,e))!==void 0}function Mi(t,e){if(t===e)return 0;const n=Gr(t),r=Gr(e);if(n!==r)return le(n,r);switch(n){case 0:case 9007199254740991:return 0;case 1:return le(t.booleanValue,e.booleanValue);case 2:return function(i,o){const l=Be(i.integerValue||i.doubleValue),u=Be(o.integerValue||o.doubleValue);return l<u?-1:l>u?1:l===u?0:isNaN(l)?isNaN(u)?0:-1:1}(t,e);case 3:return Qm(t.timestampValue,e.timestampValue);case 4:return Qm(fa(t),fa(e));case 5:return Zd(t.stringValue,e.stringValue);case 6:return function(i,o){const l=Wr(i),u=Wr(o);return l.compareTo(u)}(t.bytesValue,e.bytesValue);case 7:return function(i,o){const l=i.split("/"),u=o.split("/");for(let d=0;d<l.length&&d<u.length;d++){const f=le(l[d],u[d]);if(f!==0)return f}return le(l.length,u.length)}(t.referenceValue,e.referenceValue);case 8:return function(i,o){const l=le(Be(i.latitude),Be(o.latitude));return l!==0?l:le(Be(i.longitude),Be(o.longitude))}(t.geoPointValue,e.geoPointValue);case 9:return Ym(t.arrayValue,e.arrayValue);case 10:return function(i,o){var v,I,A,P;const l=i.fields||{},u=o.fields||{},d=(v=l[mu])==null?void 0:v.arrayValue,f=(I=u[mu])==null?void 0:I.arrayValue,m=le(((A=d==null?void 0:d.values)==null?void 0:A.length)||0,((P=f==null?void 0:f.values)==null?void 0:P.length)||0);return m!==0?m:Ym(d,f)}(t.mapValue,e.mapValue);case 11:return function(i,o){if(i===pl.mapValue&&o===pl.mapValue)return 0;if(i===pl.mapValue)return 1;if(o===pl.mapValue)return-1;const l=i.fields||{},u=Object.keys(l),d=o.fields||{},f=Object.keys(d);u.sort(),f.sort();for(let m=0;m<u.length&&m<f.length;++m){const v=Zd(u[m],f[m]);if(v!==0)return v;const I=Mi(l[u[m]],d[f[m]]);if(I!==0)return I}return le(u.length,f.length)}(t.mapValue,e.mapValue);default:throw ee(23264,{he:n})}}function Qm(t,e){if(typeof t=="string"&&typeof e=="string"&&t.length===e.length)return le(t,e);const n=Hr(t),r=Hr(e),s=le(n.seconds,r.seconds);return s!==0?s:le(n.nanos,r.nanos)}function Ym(t,e){const n=t.values||[],r=e.values||[];for(let s=0;s<n.length&&s<r.length;++s){const i=Mi(n[s],r[s]);if(i)return i}return le(n.length,r.length)}function Li(t){return eh(t)}function eh(t){return"nullValue"in t?"null":"booleanValue"in t?""+t.booleanValue:"integerValue"in t?""+t.integerValue:"doubleValue"in t?""+t.doubleValue:"timestampValue"in t?function(n){const r=Hr(n);return`time(${r.seconds},${r.nanos})`}(t.timestampValue):"stringValue"in t?t.stringValue:"bytesValue"in t?function(n){return Wr(n).toBase64()}(t.bytesValue):"referenceValue"in t?function(n){return X.fromName(n).toString()}(t.referenceValue):"geoPointValue"in t?function(n){return`geo(${n.latitude},${n.longitude})`}(t.geoPointValue):"arrayValue"in t?function(n){let r="[",s=!0;for(const i of n.values||[])s?s=!1:r+=",",r+=eh(i);return r+"]"}(t.arrayValue):"mapValue"in t?function(n){const r=Object.keys(n.fields||{}).sort();let s="{",i=!0;for(const o of r)i?i=!1:s+=",",s+=`${o}:${eh(n.fields[o])}`;return s+"}"}(t.mapValue):ee(61005,{value:t})}function Dl(t){switch(Gr(t)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Gu(t);return e?16+Dl(e):16;case 5:return 2*t.stringValue.length;case 6:return Wr(t.bytesValue).approximateByteSize();case 7:return t.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((s,i)=>s+Dl(i),0)}(t.arrayValue);case 10:case 11:return function(r){let s=0;return Ls(r.fields,(i,o)=>{s+=i.length+Dl(o)}),s}(t.mapValue);default:throw ee(13486,{value:t})}}function Xm(t,e){return{referenceValue:`projects/${t.projectId}/databases/${t.database}/documents/${e.path.canonicalString()}`}}function th(t){return!!t&&"integerValue"in t}function xf(t){return!!t&&"arrayValue"in t}function Jm(t){return!!t&&"nullValue"in t}function Zm(t){return!!t&&"doubleValue"in t&&isNaN(Number(t.doubleValue))}function Ml(t){return!!t&&"mapValue"in t}function QE(t){var n,r;return((r=(((n=t==null?void 0:t.mapValue)==null?void 0:n.fields)||{})[jv])==null?void 0:r.stringValue)===Ov}function Uo(t){if(t.geoPointValue)return{geoPointValue:{...t.geoPointValue}};if(t.timestampValue&&typeof t.timestampValue=="object")return{timestampValue:{...t.timestampValue}};if(t.mapValue){const e={mapValue:{fields:{}}};return Ls(t.mapValue.fields,(n,r)=>e.mapValue.fields[n]=Uo(r)),e}if(t.arrayValue){const e={arrayValue:{values:[]}};for(let n=0;n<(t.arrayValue.values||[]).length;++n)e.arrayValue.values[n]=Uo(t.arrayValue.values[n]);return e}return{...t}}function YE(t){return(((t.mapValue||{}).fields||{}).__type__||{}).stringValue===KE}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tn{constructor(e){this.value=e}static empty(){return new tn({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let n=this.value;for(let r=0;r<e.length-1;++r)if(n=(n.mapValue.fields||{})[e.get(r)],!Ml(n))return null;return n=(n.mapValue.fields||{})[e.lastSegment()],n||null}}set(e,n){this.getFieldsMap(e.popLast())[e.lastSegment()]=Uo(n)}setAll(e){let n=dt.emptyPath(),r={},s=[];e.forEach((o,l)=>{if(!n.isImmediateParentOf(l)){const u=this.getFieldsMap(n);this.applyChanges(u,r,s),r={},s=[],n=l.popLast()}o?r[l.lastSegment()]=Uo(o):s.push(l.lastSegment())});const i=this.getFieldsMap(n);this.applyChanges(i,r,s)}delete(e){const n=this.field(e.popLast());Ml(n)&&n.mapValue.fields&&delete n.mapValue.fields[e.lastSegment()]}isEqual(e){return zn(this.value,e.value)}getFieldsMap(e){let n=this.value;n.mapValue.fields||(n.mapValue={fields:{}});for(let r=0;r<e.length;++r){let s=n.mapValue.fields[e.get(r)];Ml(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},n.mapValue.fields[e.get(r)]=s),n=s}return n.mapValue.fields}applyChanges(e,n,r){Ls(n,(s,i)=>e[s]=i);for(const s of r)delete e[s]}clone(){return new tn(Uo(this.value))}}function Fv(t){const e=[];return Ls(t.fields,(n,r)=>{const s=new dt([n]);if(Ml(r)){const i=Fv(r.mapValue).fields;if(i.length===0)e.push(s);else for(const o of i)e.push(s.child(o))}else e.push(s)}),new _n(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(e,n,r,s,i,o,l){this.key=e,this.documentType=n,this.version=r,this.readTime=s,this.createTime=i,this.data=o,this.documentState=l}static newInvalidDocument(e){return new wt(e,0,re.min(),re.min(),re.min(),tn.empty(),0)}static newFoundDocument(e,n,r,s){return new wt(e,1,n,re.min(),r,s,0)}static newNoDocument(e,n){return new wt(e,2,n,re.min(),re.min(),tn.empty(),0)}static newUnknownDocument(e,n){return new wt(e,3,n,re.min(),re.min(),tn.empty(),2)}convertToFoundDocument(e,n){return!this.createTime.isEqual(re.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=n,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=tn.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=tn.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=re.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof wt&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new wt(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gu{constructor(e,n){this.position=e,this.inclusive=n}}function eg(t,e,n){let r=0;for(let s=0;s<t.position.length;s++){const i=e[s],o=t.position[s];if(i.field.isKeyField()?r=X.comparator(X.fromName(o.referenceValue),n.key):r=Mi(o,n.data.field(i.field)),i.dir==="desc"&&(r*=-1),r!==0)break}return r}function tg(t,e){if(t===null)return e===null;if(e===null||t.inclusive!==e.inclusive||t.position.length!==e.position.length)return!1;for(let n=0;n<t.position.length;n++)if(!zn(t.position[n],e.position[n]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ga{constructor(e,n="asc"){this.field=e,this.dir=n}}function XE(t,e){return t.dir===e.dir&&t.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zv{}class Ge extends zv{constructor(e,n,r){super(),this.field=e,this.op=n,this.value=r}static create(e,n,r){return e.isKeyField()?n==="in"||n==="not-in"?this.createKeyFieldInFilter(e,n,r):new ZE(e,n,r):n==="array-contains"?new nT(e,r):n==="in"?new rT(e,r):n==="not-in"?new sT(e,r):n==="array-contains-any"?new iT(e,r):new Ge(e,n,r)}static createKeyFieldInFilter(e,n,r){return n==="in"?new eT(e,r):new tT(e,r)}matches(e){const n=e.data.field(this.field);return this.op==="!="?n!==null&&n.nullValue===void 0&&this.matchesComparison(Mi(n,this.value)):n!==null&&Gr(this.value)===Gr(n)&&this.matchesComparison(Mi(n,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return ee(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class bn extends zv{constructor(e,n){super(),this.filters=e,this.op=n,this.Pe=null}static create(e,n){return new bn(e,n)}matches(e){return Uv(this)?this.filters.find(n=>!n.matches(e))===void 0:this.filters.find(n=>n.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,n)=>e.concat(n.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function Uv(t){return t.op==="and"}function Bv(t){return JE(t)&&Uv(t)}function JE(t){for(const e of t.filters)if(e instanceof bn)return!1;return!0}function nh(t){if(t instanceof Ge)return t.field.canonicalString()+t.op.toString()+Li(t.value);if(Bv(t))return t.filters.map(e=>nh(e)).join(",");{const e=t.filters.map(n=>nh(n)).join(",");return`${t.op}(${e})`}}function $v(t,e){return t instanceof Ge?function(r,s){return s instanceof Ge&&r.op===s.op&&r.field.isEqual(s.field)&&zn(r.value,s.value)}(t,e):t instanceof bn?function(r,s){return s instanceof bn&&r.op===s.op&&r.filters.length===s.filters.length?r.filters.reduce((i,o,l)=>i&&$v(o,s.filters[l]),!0):!1}(t,e):void ee(19439)}function qv(t){return t instanceof Ge?function(n){return`${n.field.canonicalString()} ${n.op} ${Li(n.value)}`}(t):t instanceof bn?function(n){return n.op.toString()+" {"+n.getFilters().map(qv).join(" ,")+"}"}(t):"Filter"}class ZE extends Ge{constructor(e,n,r){super(e,n,r),this.key=X.fromName(r.referenceValue)}matches(e){const n=X.comparator(e.key,this.key);return this.matchesComparison(n)}}class eT extends Ge{constructor(e,n){super(e,"in",n),this.keys=Hv("in",n)}matches(e){return this.keys.some(n=>n.isEqual(e.key))}}class tT extends Ge{constructor(e,n){super(e,"not-in",n),this.keys=Hv("not-in",n)}matches(e){return!this.keys.some(n=>n.isEqual(e.key))}}function Hv(t,e){var n;return(((n=e.arrayValue)==null?void 0:n.values)||[]).map(r=>X.fromName(r.referenceValue))}class nT extends Ge{constructor(e,n){super(e,"array-contains",n)}matches(e){const n=e.data.field(this.field);return xf(n)&&ma(n.arrayValue,this.value)}}class rT extends Ge{constructor(e,n){super(e,"in",n)}matches(e){const n=e.data.field(this.field);return n!==null&&ma(this.value.arrayValue,n)}}class sT extends Ge{constructor(e,n){super(e,"not-in",n)}matches(e){if(ma(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const n=e.data.field(this.field);return n!==null&&n.nullValue===void 0&&!ma(this.value.arrayValue,n)}}class iT extends Ge{constructor(e,n){super(e,"array-contains-any",n)}matches(e){const n=e.data.field(this.field);return!(!xf(n)||!n.arrayValue.values)&&n.arrayValue.values.some(r=>ma(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oT{constructor(e,n=null,r=[],s=[],i=null,o=null,l=null){this.path=e,this.collectionGroup=n,this.orderBy=r,this.filters=s,this.limit=i,this.startAt=o,this.endAt=l,this.Te=null}}function ng(t,e=null,n=[],r=[],s=null,i=null,o=null){return new oT(t,e,n,r,s,i,o)}function Ef(t){const e=se(t);if(e.Te===null){let n=e.path.canonicalString();e.collectionGroup!==null&&(n+="|cg:"+e.collectionGroup),n+="|f:",n+=e.filters.map(r=>nh(r)).join(","),n+="|ob:",n+=e.orderBy.map(r=>function(i){return i.field.canonicalString()+i.dir}(r)).join(","),Wu(e.limit)||(n+="|l:",n+=e.limit),e.startAt&&(n+="|lb:",n+=e.startAt.inclusive?"b:":"a:",n+=e.startAt.position.map(r=>Li(r)).join(",")),e.endAt&&(n+="|ub:",n+=e.endAt.inclusive?"a:":"b:",n+=e.endAt.position.map(r=>Li(r)).join(",")),e.Te=n}return e.Te}function Tf(t,e){if(t.limit!==e.limit||t.orderBy.length!==e.orderBy.length)return!1;for(let n=0;n<t.orderBy.length;n++)if(!XE(t.orderBy[n],e.orderBy[n]))return!1;if(t.filters.length!==e.filters.length)return!1;for(let n=0;n<t.filters.length;n++)if(!$v(t.filters[n],e.filters[n]))return!1;return t.collectionGroup===e.collectionGroup&&!!t.path.isEqual(e.path)&&!!tg(t.startAt,e.startAt)&&tg(t.endAt,e.endAt)}function rh(t){return X.isDocumentKey(t.path)&&t.collectionGroup===null&&t.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wi{constructor(e,n=null,r=[],s=[],i=null,o="F",l=null,u=null){this.path=e,this.collectionGroup=n,this.explicitOrderBy=r,this.filters=s,this.limit=i,this.limitType=o,this.startAt=l,this.endAt=u,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function aT(t,e,n,r,s,i,o,l){return new Wi(t,e,n,r,s,i,o,l)}function Wv(t){return new Wi(t)}function rg(t){return t.filters.length===0&&t.limit===null&&t.startAt==null&&t.endAt==null&&(t.explicitOrderBy.length===0||t.explicitOrderBy.length===1&&t.explicitOrderBy[0].field.isKeyField())}function lT(t){return X.isDocumentKey(t.path)&&t.collectionGroup===null&&t.filters.length===0}function Gv(t){return t.collectionGroup!==null}function Bo(t){const e=se(t);if(e.Ee===null){e.Ee=[];const n=new Set;for(const i of e.explicitOrderBy)e.Ee.push(i),n.add(i.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let l=new Ze(dt.comparator);return o.filters.forEach(u=>{u.getFlattenedFilters().forEach(d=>{d.isInequality()&&(l=l.add(d.field))})}),l})(e).forEach(i=>{n.has(i.canonicalString())||i.isKeyField()||e.Ee.push(new ga(i,r))}),n.has(dt.keyField().canonicalString())||e.Ee.push(new ga(dt.keyField(),r))}return e.Ee}function Ln(t){const e=se(t);return e.Ie||(e.Ie=uT(e,Bo(t))),e.Ie}function uT(t,e){if(t.limitType==="F")return ng(t.path,t.collectionGroup,e,t.filters,t.limit,t.startAt,t.endAt);{e=e.map(s=>{const i=s.dir==="desc"?"asc":"desc";return new ga(s.field,i)});const n=t.endAt?new gu(t.endAt.position,t.endAt.inclusive):null,r=t.startAt?new gu(t.startAt.position,t.startAt.inclusive):null;return ng(t.path,t.collectionGroup,e,t.filters,t.limit,n,r)}}function sh(t,e){const n=t.filters.concat([e]);return new Wi(t.path,t.collectionGroup,t.explicitOrderBy.slice(),n,t.limit,t.limitType,t.startAt,t.endAt)}function cT(t,e){const n=t.explicitOrderBy.concat([e]);return new Wi(t.path,t.collectionGroup,n,t.filters.slice(),t.limit,t.limitType,t.startAt,t.endAt)}function yu(t,e,n){return new Wi(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),e,n,t.startAt,t.endAt)}function Ku(t,e){return Tf(Ln(t),Ln(e))&&t.limitType===e.limitType}function Kv(t){return`${Ef(Ln(t))}|lt:${t.limitType}`}function Zs(t){return`Query(target=${function(n){let r=n.path.canonicalString();return n.collectionGroup!==null&&(r+=" collectionGroup="+n.collectionGroup),n.filters.length>0&&(r+=`, filters: [${n.filters.map(s=>qv(s)).join(", ")}]`),Wu(n.limit)||(r+=", limit: "+n.limit),n.orderBy.length>0&&(r+=`, orderBy: [${n.orderBy.map(s=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(s)).join(", ")}]`),n.startAt&&(r+=", startAt: ",r+=n.startAt.inclusive?"b:":"a:",r+=n.startAt.position.map(s=>Li(s)).join(",")),n.endAt&&(r+=", endAt: ",r+=n.endAt.inclusive?"a:":"b:",r+=n.endAt.position.map(s=>Li(s)).join(",")),`Target(${r})`}(Ln(t))}; limitType=${t.limitType})`}function Qu(t,e){return e.isFoundDocument()&&function(r,s){const i=s.key.path;return r.collectionGroup!==null?s.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(i):X.isDocumentKey(r.path)?r.path.isEqual(i):r.path.isImmediateParentOf(i)}(t,e)&&function(r,s){for(const i of Bo(r))if(!i.field.isKeyField()&&s.data.field(i.field)===null)return!1;return!0}(t,e)&&function(r,s){for(const i of r.filters)if(!i.matches(s))return!1;return!0}(t,e)&&function(r,s){return!(r.startAt&&!function(o,l,u){const d=eg(o,l,u);return o.inclusive?d<=0:d<0}(r.startAt,Bo(r),s)||r.endAt&&!function(o,l,u){const d=eg(o,l,u);return o.inclusive?d>=0:d>0}(r.endAt,Bo(r),s))}(t,e)}function dT(t){return t.collectionGroup||(t.path.length%2==1?t.path.lastSegment():t.path.get(t.path.length-2))}function Qv(t){return(e,n)=>{let r=!1;for(const s of Bo(t)){const i=hT(s,e,n);if(i!==0)return i;r=r||s.field.isKeyField()}return 0}}function hT(t,e,n){const r=t.field.isKeyField()?X.comparator(e.key,n.key):function(i,o,l){const u=o.data.field(i),d=l.data.field(i);return u!==null&&d!==null?Mi(u,d):ee(42886)}(t.field,e,n);switch(t.dir){case"asc":return r;case"desc":return-1*r;default:return ee(19790,{direction:t.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class js{constructor(e,n){this.mapKeyFn=e,this.equalsFn=n,this.inner={},this.innerSize=0}get(e){const n=this.mapKeyFn(e),r=this.inner[n];if(r!==void 0){for(const[s,i]of r)if(this.equalsFn(s,e))return i}}has(e){return this.get(e)!==void 0}set(e,n){const r=this.mapKeyFn(e),s=this.inner[r];if(s===void 0)return this.inner[r]=[[e,n]],void this.innerSize++;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return void(s[i]=[e,n]);s.push([e,n]),this.innerSize++}delete(e){const n=this.mapKeyFn(e),r=this.inner[n];if(r===void 0)return!1;for(let s=0;s<r.length;s++)if(this.equalsFn(r[s][0],e))return r.length===1?delete this.inner[n]:r.splice(s,1),this.innerSize--,!0;return!1}forEach(e){Ls(this.inner,(n,r)=>{for(const[s,i]of r)e(s,i)})}isEmpty(){return Pv(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fT=new Le(X.comparator);function rr(){return fT}const Yv=new Le(X.comparator);function Co(...t){let e=Yv;for(const n of t)e=e.insert(n.key,n);return e}function Xv(t){let e=Yv;return t.forEach((n,r)=>e=e.insert(n,r.overlayedDocument)),e}function Es(){return $o()}function Jv(){return $o()}function $o(){return new js(t=>t.toString(),(t,e)=>t.isEqual(e))}const pT=new Le(X.comparator),mT=new Ze(X.comparator);function ue(...t){let e=mT;for(const n of t)e=e.add(n);return e}const gT=new Ze(le);function yT(){return gT}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bf(t,e){if(t.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:fu(e)?"-0":e}}function Zv(t){return{integerValue:""+t}}function vT(t,e){return BE(e)?Zv(e):bf(t,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yu{constructor(){this._=void 0}}function _T(t,e,n){return t instanceof ya?function(s,i){const o={fields:{[Dv]:{stringValue:Vv},[Lv]:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return i&&wf(i)&&(i=Gu(i)),i&&(o.fields[Mv]=i),{mapValue:o}}(n,e):t instanceof va?t1(t,e):t instanceof _a?n1(t,e):function(s,i){const o=e1(s,i),l=sg(o)+sg(s.Ae);return th(o)&&th(s.Ae)?Zv(l):bf(s.serializer,l)}(t,e)}function wT(t,e,n){return t instanceof va?t1(t,e):t instanceof _a?n1(t,e):n}function e1(t,e){return t instanceof vu?function(r){return th(r)||function(i){return!!i&&"doubleValue"in i}(r)}(e)?e:{integerValue:0}:null}class ya extends Yu{}class va extends Yu{constructor(e){super(),this.elements=e}}function t1(t,e){const n=r1(e);for(const r of t.elements)n.some(s=>zn(s,r))||n.push(r);return{arrayValue:{values:n}}}class _a extends Yu{constructor(e){super(),this.elements=e}}function n1(t,e){let n=r1(e);for(const r of t.elements)n=n.filter(s=>!zn(s,r));return{arrayValue:{values:n}}}class vu extends Yu{constructor(e,n){super(),this.serializer=e,this.Ae=n}}function sg(t){return Be(t.integerValue||t.doubleValue)}function r1(t){return xf(t)&&t.arrayValue.values?t.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xT{constructor(e,n){this.field=e,this.transform=n}}function ET(t,e){return t.field.isEqual(e.field)&&function(r,s){return r instanceof va&&s instanceof va||r instanceof _a&&s instanceof _a?Di(r.elements,s.elements,zn):r instanceof vu&&s instanceof vu?zn(r.Ae,s.Ae):r instanceof ya&&s instanceof ya}(t.transform,e.transform)}class TT{constructor(e,n){this.version=e,this.transformResults=n}}class Yn{constructor(e,n){this.updateTime=e,this.exists=n}static none(){return new Yn}static exists(e){return new Yn(void 0,e)}static updateTime(e){return new Yn(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Ll(t,e){return t.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(t.updateTime):t.exists===void 0||t.exists===e.isFoundDocument()}class Xu{}function s1(t,e){if(!t.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return t.isNoDocument()?new o1(t.key,Yn.none()):new Ia(t.key,t.data,Yn.none());{const n=t.data,r=tn.empty();let s=new Ze(dt.comparator);for(let i of e.fields)if(!s.has(i)){let o=n.field(i);o===null&&i.length>1&&(i=i.popLast(),o=n.field(i)),o===null?r.delete(i):r.set(i,o),s=s.add(i)}return new Os(t.key,r,new _n(s.toArray()),Yn.none())}}function bT(t,e,n){t instanceof Ia?function(s,i,o){const l=s.value.clone(),u=og(s.fieldTransforms,i,o.transformResults);l.setAll(u),i.convertToFoundDocument(o.version,l).setHasCommittedMutations()}(t,e,n):t instanceof Os?function(s,i,o){if(!Ll(s.precondition,i))return void i.convertToUnknownDocument(o.version);const l=og(s.fieldTransforms,i,o.transformResults),u=i.data;u.setAll(i1(s)),u.setAll(l),i.convertToFoundDocument(o.version,u).setHasCommittedMutations()}(t,e,n):function(s,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,n)}function qo(t,e,n,r){return t instanceof Ia?function(i,o,l,u){if(!Ll(i.precondition,o))return l;const d=i.value.clone(),f=ag(i.fieldTransforms,u,o);return d.setAll(f),o.convertToFoundDocument(o.version,d).setHasLocalMutations(),null}(t,e,n,r):t instanceof Os?function(i,o,l,u){if(!Ll(i.precondition,o))return l;const d=ag(i.fieldTransforms,u,o),f=o.data;return f.setAll(i1(i)),f.setAll(d),o.convertToFoundDocument(o.version,f).setHasLocalMutations(),l===null?null:l.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(m=>m.field))}(t,e,n,r):function(i,o,l){return Ll(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):l}(t,e,n)}function ST(t,e){let n=null;for(const r of t.fieldTransforms){const s=e.data.field(r.field),i=e1(r.transform,s||null);i!=null&&(n===null&&(n=tn.empty()),n.set(r.field,i))}return n||null}function ig(t,e){return t.type===e.type&&!!t.key.isEqual(e.key)&&!!t.precondition.isEqual(e.precondition)&&!!function(r,s){return r===void 0&&s===void 0||!(!r||!s)&&Di(r,s,(i,o)=>ET(i,o))}(t.fieldTransforms,e.fieldTransforms)&&(t.type===0?t.value.isEqual(e.value):t.type!==1||t.data.isEqual(e.data)&&t.fieldMask.isEqual(e.fieldMask))}class Ia extends Xu{constructor(e,n,r,s=[]){super(),this.key=e,this.value=n,this.precondition=r,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class Os extends Xu{constructor(e,n,r,s,i=[]){super(),this.key=e,this.data=n,this.fieldMask=r,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function i1(t){const e=new Map;return t.fieldMask.fields.forEach(n=>{if(!n.isEmpty()){const r=t.data.field(n);e.set(n,r)}}),e}function og(t,e,n){const r=new Map;ye(t.length===n.length,32656,{Ve:n.length,de:t.length});for(let s=0;s<n.length;s++){const i=t[s],o=i.transform,l=e.data.field(i.field);r.set(i.field,wT(o,l,n[s]))}return r}function ag(t,e,n){const r=new Map;for(const s of t){const i=s.transform,o=n.data.field(s.field);r.set(s.field,_T(i,o,e))}return r}class o1 extends Xu{constructor(e,n){super(),this.key=e,this.precondition=n,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class kT extends Xu{constructor(e,n){super(),this.key=e,this.precondition=n,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IT{constructor(e,n,r,s){this.batchId=e,this.localWriteTime=n,this.baseMutations=r,this.mutations=s}applyToRemoteDocument(e,n){const r=n.mutationResults;for(let s=0;s<this.mutations.length;s++){const i=this.mutations[s];i.key.isEqual(e.key)&&bT(i,e,r[s])}}applyToLocalView(e,n){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(n=qo(r,e,n,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(n=qo(r,e,n,this.localWriteTime));return n}applyToLocalDocumentSet(e,n){const r=Jv();return this.mutations.forEach(s=>{const i=e.get(s.key),o=i.overlayedDocument;let l=this.applyToLocalView(o,i.mutatedFields);l=n.has(s.key)?null:l;const u=s1(o,l);u!==null&&r.set(s.key,u),o.isValidDocument()||o.convertToNoDocument(re.min())}),r}keys(){return this.mutations.reduce((e,n)=>e.add(n.key),ue())}isEqual(e){return this.batchId===e.batchId&&Di(this.mutations,e.mutations,(n,r)=>ig(n,r))&&Di(this.baseMutations,e.baseMutations,(n,r)=>ig(n,r))}}class Sf{constructor(e,n,r,s){this.batch=e,this.commitVersion=n,this.mutationResults=r,this.docVersions=s}static from(e,n,r){ye(e.mutations.length===r.length,58842,{me:e.mutations.length,fe:r.length});let s=function(){return pT}();const i=e.mutations;for(let o=0;o<i.length;o++)s=s.insert(i[o].key,r[o].version);return new Sf(e,n,r,s)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AT{constructor(e,n){this.largestBatchId=e,this.mutation=n}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CT{constructor(e,n){this.count=e,this.unchangedNames=n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var He,he;function RT(t){switch(t){case L.OK:return ee(64938);case L.CANCELLED:case L.UNKNOWN:case L.DEADLINE_EXCEEDED:case L.RESOURCE_EXHAUSTED:case L.INTERNAL:case L.UNAVAILABLE:case L.UNAUTHENTICATED:return!1;case L.INVALID_ARGUMENT:case L.NOT_FOUND:case L.ALREADY_EXISTS:case L.PERMISSION_DENIED:case L.FAILED_PRECONDITION:case L.ABORTED:case L.OUT_OF_RANGE:case L.UNIMPLEMENTED:case L.DATA_LOSS:return!0;default:return ee(15467,{code:t})}}function a1(t){if(t===void 0)return nr("GRPC error has no .code"),L.UNKNOWN;switch(t){case He.OK:return L.OK;case He.CANCELLED:return L.CANCELLED;case He.UNKNOWN:return L.UNKNOWN;case He.DEADLINE_EXCEEDED:return L.DEADLINE_EXCEEDED;case He.RESOURCE_EXHAUSTED:return L.RESOURCE_EXHAUSTED;case He.INTERNAL:return L.INTERNAL;case He.UNAVAILABLE:return L.UNAVAILABLE;case He.UNAUTHENTICATED:return L.UNAUTHENTICATED;case He.INVALID_ARGUMENT:return L.INVALID_ARGUMENT;case He.NOT_FOUND:return L.NOT_FOUND;case He.ALREADY_EXISTS:return L.ALREADY_EXISTS;case He.PERMISSION_DENIED:return L.PERMISSION_DENIED;case He.FAILED_PRECONDITION:return L.FAILED_PRECONDITION;case He.ABORTED:return L.ABORTED;case He.OUT_OF_RANGE:return L.OUT_OF_RANGE;case He.UNIMPLEMENTED:return L.UNIMPLEMENTED;case He.DATA_LOSS:return L.DATA_LOSS;default:return ee(39323,{code:t})}}(he=He||(He={}))[he.OK=0]="OK",he[he.CANCELLED=1]="CANCELLED",he[he.UNKNOWN=2]="UNKNOWN",he[he.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",he[he.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",he[he.NOT_FOUND=5]="NOT_FOUND",he[he.ALREADY_EXISTS=6]="ALREADY_EXISTS",he[he.PERMISSION_DENIED=7]="PERMISSION_DENIED",he[he.UNAUTHENTICATED=16]="UNAUTHENTICATED",he[he.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",he[he.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",he[he.ABORTED=10]="ABORTED",he[he.OUT_OF_RANGE=11]="OUT_OF_RANGE",he[he.UNIMPLEMENTED=12]="UNIMPLEMENTED",he[he.INTERNAL=13]="INTERNAL",he[he.UNAVAILABLE=14]="UNAVAILABLE",he[he.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function PT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const NT=new Fr([4294967295,4294967295],0);function lg(t){const e=PT().encode(t),n=new wv;return n.update(e),new Uint8Array(n.digest())}function ug(t){const e=new DataView(t.buffer),n=e.getUint32(0,!0),r=e.getUint32(4,!0),s=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new Fr([n,r],0),new Fr([s,i],0)]}class kf{constructor(e,n,r){if(this.bitmap=e,this.padding=n,this.hashCount=r,n<0||n>=8)throw new Ro(`Invalid padding: ${n}`);if(r<0)throw new Ro(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new Ro(`Invalid hash count: ${r}`);if(e.length===0&&n!==0)throw new Ro(`Invalid padding when bitmap length is 0: ${n}`);this.ge=8*e.length-n,this.pe=Fr.fromNumber(this.ge)}ye(e,n,r){let s=e.add(n.multiply(Fr.fromNumber(r)));return s.compare(NT)===1&&(s=new Fr([s.getBits(0),s.getBits(1)],0)),s.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const n=lg(e),[r,s]=ug(n);for(let i=0;i<this.hashCount;i++){const o=this.ye(r,s,i);if(!this.we(o))return!1}return!0}static create(e,n,r){const s=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new kf(i,s,n);return r.forEach(l=>o.insert(l)),o}insert(e){if(this.ge===0)return;const n=lg(e),[r,s]=ug(n);for(let i=0;i<this.hashCount;i++){const o=this.ye(r,s,i);this.Se(o)}}Se(e){const n=Math.floor(e/8),r=e%8;this.bitmap[n]|=1<<r}}class Ro extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ju{constructor(e,n,r,s,i){this.snapshotVersion=e,this.targetChanges=n,this.targetMismatches=r,this.documentUpdates=s,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,n,r){const s=new Map;return s.set(e,Aa.createSynthesizedTargetChangeForCurrentChange(e,n,r)),new Ju(re.min(),s,new Le(le),rr(),ue())}}class Aa{constructor(e,n,r,s,i){this.resumeToken=e,this.current=n,this.addedDocuments=r,this.modifiedDocuments=s,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,n,r){return new Aa(r,n,ue(),ue(),ue())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jl{constructor(e,n,r,s){this.be=e,this.removedTargetIds=n,this.key=r,this.De=s}}class l1{constructor(e,n){this.targetId=e,this.Ce=n}}class u1{constructor(e,n,r=pt.EMPTY_BYTE_STRING,s=null){this.state=e,this.targetIds=n,this.resumeToken=r,this.cause=s}}class cg{constructor(){this.ve=0,this.Fe=dg(),this.Me=pt.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=ue(),n=ue(),r=ue();return this.Fe.forEach((s,i)=>{switch(i){case 0:e=e.add(s);break;case 2:n=n.add(s);break;case 1:r=r.add(s);break;default:ee(38017,{changeType:i})}}),new Aa(this.Me,this.xe,e,n,r)}qe(){this.Oe=!1,this.Fe=dg()}Ke(e,n){this.Oe=!0,this.Fe=this.Fe.insert(e,n)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,ye(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class VT{constructor(e){this.Ge=e,this.ze=new Map,this.je=rr(),this.Je=ml(),this.He=ml(),this.Ze=new Le(le)}Xe(e){for(const n of e.be)e.De&&e.De.isFoundDocument()?this.Ye(n,e.De):this.et(n,e.key,e.De);for(const n of e.removedTargetIds)this.et(n,e.key,e.De)}tt(e){this.forEachTarget(e,n=>{const r=this.nt(n);switch(e.state){case 0:this.rt(n)&&r.Le(e.resumeToken);break;case 1:r.We(),r.Ne||r.qe(),r.Le(e.resumeToken);break;case 2:r.We(),r.Ne||this.removeTarget(n);break;case 3:this.rt(n)&&(r.Qe(),r.Le(e.resumeToken));break;case 4:this.rt(n)&&(this.it(n),r.Le(e.resumeToken));break;default:ee(56790,{state:e.state})}})}forEachTarget(e,n){e.targetIds.length>0?e.targetIds.forEach(n):this.ze.forEach((r,s)=>{this.rt(s)&&n(s)})}st(e){const n=e.targetId,r=e.Ce.count,s=this.ot(n);if(s){const i=s.target;if(rh(i))if(r===0){const o=new X(i.path);this.et(n,o,wt.newNoDocument(o,re.min()))}else ye(r===1,20013,{expectedCount:r});else{const o=this._t(n);if(o!==r){const l=this.ut(e),u=l?this.ct(l,e,o):1;if(u!==0){this.it(n);const d=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(n,d)}}}}}ut(e){const n=e.Ce.unchangedNames;if(!n||!n.bits)return null;const{bits:{bitmap:r="",padding:s=0},hashCount:i=0}=n;let o,l;try{o=Wr(r).toUint8Array()}catch(u){if(u instanceof Nv)return Ns("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{l=new kf(o,s,i)}catch(u){return Ns(u instanceof Ro?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return l.ge===0?null:l}ct(e,n,r){return n.Ce.count===r-this.Pt(e,n.targetId)?0:2}Pt(e,n){const r=this.Ge.getRemoteKeysForTarget(n);let s=0;return r.forEach(i=>{const o=this.Ge.ht(),l=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(l)||(this.et(n,i,null),s++)}),s}Tt(e){const n=new Map;this.ze.forEach((i,o)=>{const l=this.ot(o);if(l){if(i.current&&rh(l.target)){const u=new X(l.target.path);this.Et(u).has(o)||this.It(o,u)||this.et(o,u,wt.newNoDocument(u,e))}i.Be&&(n.set(o,i.ke()),i.qe())}});let r=ue();this.He.forEach((i,o)=>{let l=!0;o.forEachWhile(u=>{const d=this.ot(u);return!d||d.purpose==="TargetPurposeLimboResolution"||(l=!1,!1)}),l&&(r=r.add(i))}),this.je.forEach((i,o)=>o.setReadTime(e));const s=new Ju(e,n,this.Ze,this.je,r);return this.je=rr(),this.Je=ml(),this.He=ml(),this.Ze=new Le(le),s}Ye(e,n){if(!this.rt(e))return;const r=this.It(e,n.key)?2:0;this.nt(e).Ke(n.key,r),this.je=this.je.insert(n.key,n),this.Je=this.Je.insert(n.key,this.Et(n.key).add(e)),this.He=this.He.insert(n.key,this.Rt(n.key).add(e))}et(e,n,r){if(!this.rt(e))return;const s=this.nt(e);this.It(e,n)?s.Ke(n,1):s.Ue(n),this.He=this.He.insert(n,this.Rt(n).delete(e)),this.He=this.He.insert(n,this.Rt(n).add(e)),r&&(this.je=this.je.insert(n,r))}removeTarget(e){this.ze.delete(e)}_t(e){const n=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+n.addedDocuments.size-n.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let n=this.ze.get(e);return n||(n=new cg,this.ze.set(e,n)),n}Rt(e){let n=this.He.get(e);return n||(n=new Ze(le),this.He=this.He.insert(e,n)),n}Et(e){let n=this.Je.get(e);return n||(n=new Ze(le),this.Je=this.Je.insert(e,n)),n}rt(e){const n=this.ot(e)!==null;return n||K("WatchChangeAggregator","Detected inactive target",e),n}ot(e){const n=this.ze.get(e);return n&&n.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new cg),this.Ge.getRemoteKeysForTarget(e).forEach(n=>{this.et(e,n,null)})}It(e,n){return this.Ge.getRemoteKeysForTarget(e).has(n)}}function ml(){return new Le(X.comparator)}function dg(){return new Le(X.comparator)}const DT={asc:"ASCENDING",desc:"DESCENDING"},MT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},LT={and:"AND",or:"OR"};class jT{constructor(e,n){this.databaseId=e,this.useProto3Json=n}}function ih(t,e){return t.useProto3Json||Wu(e)?e:{value:e}}function _u(t,e){return t.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function c1(t,e){return t.useProto3Json?e.toBase64():e.toUint8Array()}function OT(t,e){return _u(t,e.toTimestamp())}function jn(t){return ye(!!t,49232),re.fromTimestamp(function(n){const r=Hr(n);return new Ie(r.seconds,r.nanos)}(t))}function If(t,e){return oh(t,e).canonicalString()}function oh(t,e){const n=function(s){return new xe(["projects",s.projectId,"databases",s.database])}(t).child("documents");return e===void 0?n:n.child(e)}function d1(t){const e=xe.fromString(t);return ye(g1(e),10190,{key:e.toString()}),e}function ah(t,e){return If(t.databaseId,e.path)}function Kc(t,e){const n=d1(e);if(n.get(1)!==t.databaseId.projectId)throw new G(L.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+t.databaseId.projectId);if(n.get(3)!==t.databaseId.database)throw new G(L.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+t.databaseId.database);return new X(f1(n))}function h1(t,e){return If(t.databaseId,e)}function FT(t){const e=d1(t);return e.length===4?xe.emptyPath():f1(e)}function lh(t){return new xe(["projects",t.databaseId.projectId,"databases",t.databaseId.database]).canonicalString()}function f1(t){return ye(t.length>4&&t.get(4)==="documents",29091,{key:t.toString()}),t.popFirst(5)}function hg(t,e,n){return{name:ah(t,e),fields:n.value.mapValue.fields}}function zT(t,e){let n;if("targetChange"in e){e.targetChange;const r=function(d){return d==="NO_CHANGE"?0:d==="ADD"?1:d==="REMOVE"?2:d==="CURRENT"?3:d==="RESET"?4:ee(39313,{state:d})}(e.targetChange.targetChangeType||"NO_CHANGE"),s=e.targetChange.targetIds||[],i=function(d,f){return d.useProto3Json?(ye(f===void 0||typeof f=="string",58123),pt.fromBase64String(f||"")):(ye(f===void 0||f instanceof Buffer||f instanceof Uint8Array,16193),pt.fromUint8Array(f||new Uint8Array))}(t,e.targetChange.resumeToken),o=e.targetChange.cause,l=o&&function(d){const f=d.code===void 0?L.UNKNOWN:a1(d.code);return new G(f,d.message||"")}(o);n=new u1(r,s,i,l||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const s=Kc(t,r.document.name),i=jn(r.document.updateTime),o=r.document.createTime?jn(r.document.createTime):re.min(),l=new tn({mapValue:{fields:r.document.fields}}),u=wt.newFoundDocument(s,i,o,l),d=r.targetIds||[],f=r.removedTargetIds||[];n=new jl(d,f,u.key,u)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const s=Kc(t,r.document),i=r.readTime?jn(r.readTime):re.min(),o=wt.newNoDocument(s,i),l=r.removedTargetIds||[];n=new jl([],l,o.key,o)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const s=Kc(t,r.document),i=r.removedTargetIds||[];n=new jl([],i,s,null)}else{if(!("filter"in e))return ee(11601,{Vt:e});{e.filter;const r=e.filter;r.targetId;const{count:s=0,unchangedNames:i}=r,o=new CT(s,i),l=r.targetId;n=new l1(l,o)}}return n}function UT(t,e){let n;if(e instanceof Ia)n={update:hg(t,e.key,e.value)};else if(e instanceof o1)n={delete:ah(t,e.key)};else if(e instanceof Os)n={update:hg(t,e.key,e.data),updateMask:YT(e.fieldMask)};else{if(!(e instanceof kT))return ee(16599,{dt:e.type});n={verify:ah(t,e.key)}}return e.fieldTransforms.length>0&&(n.updateTransforms=e.fieldTransforms.map(r=>function(i,o){const l=o.transform;if(l instanceof ya)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(l instanceof va)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:l.elements}};if(l instanceof _a)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:l.elements}};if(l instanceof vu)return{fieldPath:o.field.canonicalString(),increment:l.Ae};throw ee(20930,{transform:o.transform})}(0,r))),e.precondition.isNone||(n.currentDocument=function(s,i){return i.updateTime!==void 0?{updateTime:OT(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:ee(27497)}(t,e.precondition)),n}function BT(t,e){return t&&t.length>0?(ye(e!==void 0,14353),t.map(n=>function(s,i){let o=s.updateTime?jn(s.updateTime):jn(i);return o.isEqual(re.min())&&(o=jn(i)),new TT(o,s.transformResults||[])}(n,e))):[]}function $T(t,e){return{documents:[h1(t,e.path)]}}function qT(t,e){const n={structuredQuery:{}},r=e.path;let s;e.collectionGroup!==null?(s=r,n.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(s=r.popLast(),n.structuredQuery.from=[{collectionId:r.lastSegment()}]),n.parent=h1(t,s);const i=function(d){if(d.length!==0)return m1(bn.create(d,"and"))}(e.filters);i&&(n.structuredQuery.where=i);const o=function(d){if(d.length!==0)return d.map(f=>function(v){return{field:ei(v.field),direction:GT(v.dir)}}(f))}(e.orderBy);o&&(n.structuredQuery.orderBy=o);const l=ih(t,e.limit);return l!==null&&(n.structuredQuery.limit=l),e.startAt&&(n.structuredQuery.startAt=function(d){return{before:d.inclusive,values:d.position}}(e.startAt)),e.endAt&&(n.structuredQuery.endAt=function(d){return{before:!d.inclusive,values:d.position}}(e.endAt)),{ft:n,parent:s}}function HT(t){let e=FT(t.parent);const n=t.structuredQuery,r=n.from?n.from.length:0;let s=null;if(r>0){ye(r===1,65062);const f=n.from[0];f.allDescendants?s=f.collectionId:e=e.child(f.collectionId)}let i=[];n.where&&(i=function(m){const v=p1(m);return v instanceof bn&&Bv(v)?v.getFilters():[v]}(n.where));let o=[];n.orderBy&&(o=function(m){return m.map(v=>function(A){return new ga(ti(A.field),function(M){switch(M){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(A.direction))}(v))}(n.orderBy));let l=null;n.limit&&(l=function(m){let v;return v=typeof m=="object"?m.value:m,Wu(v)?null:v}(n.limit));let u=null;n.startAt&&(u=function(m){const v=!!m.before,I=m.values||[];return new gu(I,v)}(n.startAt));let d=null;return n.endAt&&(d=function(m){const v=!m.before,I=m.values||[];return new gu(I,v)}(n.endAt)),aT(e,s,o,i,l,"F",u,d)}function WT(t,e){const n=function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ee(28987,{purpose:s})}}(e.purpose);return n==null?null:{"goog-listen-tags":n}}function p1(t){return t.unaryFilter!==void 0?function(n){switch(n.unaryFilter.op){case"IS_NAN":const r=ti(n.unaryFilter.field);return Ge.create(r,"==",{doubleValue:NaN});case"IS_NULL":const s=ti(n.unaryFilter.field);return Ge.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=ti(n.unaryFilter.field);return Ge.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=ti(n.unaryFilter.field);return Ge.create(o,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return ee(61313);default:return ee(60726)}}(t):t.fieldFilter!==void 0?function(n){return Ge.create(ti(n.fieldFilter.field),function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return ee(58110);default:return ee(50506)}}(n.fieldFilter.op),n.fieldFilter.value)}(t):t.compositeFilter!==void 0?function(n){return bn.create(n.compositeFilter.filters.map(r=>p1(r)),function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return ee(1026)}}(n.compositeFilter.op))}(t):ee(30097,{filter:t})}function GT(t){return DT[t]}function KT(t){return MT[t]}function QT(t){return LT[t]}function ei(t){return{fieldPath:t.canonicalString()}}function ti(t){return dt.fromServerFormat(t.fieldPath)}function m1(t){return t instanceof Ge?function(n){if(n.op==="=="){if(Zm(n.value))return{unaryFilter:{field:ei(n.field),op:"IS_NAN"}};if(Jm(n.value))return{unaryFilter:{field:ei(n.field),op:"IS_NULL"}}}else if(n.op==="!="){if(Zm(n.value))return{unaryFilter:{field:ei(n.field),op:"IS_NOT_NAN"}};if(Jm(n.value))return{unaryFilter:{field:ei(n.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:ei(n.field),op:KT(n.op),value:n.value}}}(t):t instanceof bn?function(n){const r=n.getFilters().map(s=>m1(s));return r.length===1?r[0]:{compositeFilter:{op:QT(n.op),filters:r}}}(t):ee(54877,{filter:t})}function YT(t){const e=[];return t.fields.forEach(n=>e.push(n.canonicalString())),{fieldPaths:e}}function g1(t){return t.length>=4&&t.get(0)==="projects"&&t.get(2)==="databases"}function y1(t){return!!t&&typeof t._toProto=="function"&&t._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ar{constructor(e,n,r,s,i=re.min(),o=re.min(),l=pt.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=n,this.purpose=r,this.sequenceNumber=s,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=l,this.expectedCount=u}withSequenceNumber(e){return new Ar(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,n){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,n,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XT{constructor(e){this.yt=e}}function JT(t){const e=HT({parent:t.parent,structuredQuery:t.structuredQuery});return t.limitType==="LAST"?yu(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ZT{constructor(){this.bn=new eb}addToCollectionParentIndex(e,n){return this.bn.add(n),j.resolve()}getCollectionParents(e,n){return j.resolve(this.bn.getEntries(n))}addFieldIndex(e,n){return j.resolve()}deleteFieldIndex(e,n){return j.resolve()}deleteAllFieldIndexes(e){return j.resolve()}createTargetIndexes(e,n){return j.resolve()}getDocumentsMatchingTarget(e,n){return j.resolve(null)}getIndexType(e,n){return j.resolve(0)}getFieldIndexes(e,n){return j.resolve([])}getNextCollectionGroupToUpdate(e){return j.resolve(null)}getMinOffset(e,n){return j.resolve(qr.min())}getMinOffsetFromCollectionGroup(e,n){return j.resolve(qr.min())}updateCollectionGroup(e,n,r){return j.resolve()}updateIndexEntries(e,n){return j.resolve()}}class eb{constructor(){this.index={}}add(e){const n=e.lastSegment(),r=e.popLast(),s=this.index[n]||new Ze(xe.comparator),i=!s.has(r);return this.index[n]=s.add(r),i}has(e){const n=e.lastSegment(),r=e.popLast(),s=this.index[n];return s&&s.has(r)}getEntries(e){return(this.index[e]||new Ze(xe.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fg={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},v1=41943040;class Pt{static withCacheSize(e){return new Pt(e,Pt.DEFAULT_COLLECTION_PERCENTILE,Pt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,n,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=n,this.maximumSequenceNumbersToCollect=r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Pt.DEFAULT_COLLECTION_PERCENTILE=10,Pt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,Pt.DEFAULT=new Pt(v1,Pt.DEFAULT_COLLECTION_PERCENTILE,Pt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),Pt.DISABLED=new Pt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ji{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new ji(0)}static ar(){return new ji(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pg="LruGarbageCollector",tb=1048576;function mg([t,e],[n,r]){const s=le(t,n);return s===0?le(e,r):s}class nb{constructor(e){this.Pr=e,this.buffer=new Ze(mg),this.Tr=0}Er(){return++this.Tr}Ir(e){const n=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(n);else{const r=this.buffer.last();mg(n,r)<0&&(this.buffer=this.buffer.delete(r).add(n))}}get maxValue(){return this.buffer.last()[0]}}class rb{constructor(e,n,r){this.garbageCollector=e,this.asyncQueue=n,this.localStore=r,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){K(pg,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(n){Hi(n)?K(pg,"Ignoring IndexedDB error during garbage collection: ",n):await qi(n)}await this.Ar(3e5)})}}class sb{constructor(e,n){this.Vr=e,this.params=n}calculateTargetCount(e,n){return this.Vr.dr(e).next(r=>Math.floor(n/100*r))}nthSequenceNumber(e,n){if(n===0)return j.resolve(Hu.ce);const r=new nb(n);return this.Vr.forEachTarget(e,s=>r.Ir(s.sequenceNumber)).next(()=>this.Vr.mr(e,s=>r.Ir(s))).next(()=>r.maxValue)}removeTargets(e,n,r){return this.Vr.removeTargets(e,n,r)}removeOrphanedDocuments(e,n){return this.Vr.removeOrphanedDocuments(e,n)}collect(e,n){return this.params.cacheSizeCollectionThreshold===-1?(K("LruGarbageCollector","Garbage collection skipped; disabled"),j.resolve(fg)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(K("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),fg):this.gr(e,n))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,n){let r,s,i,o,l,u,d;const f=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(K("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),s=this.params.maximumSequenceNumbersToCollect):s=m,o=Date.now(),this.nthSequenceNumber(e,s))).next(m=>(r=m,l=Date.now(),this.removeTargets(e,r,n))).next(m=>(i=m,u=Date.now(),this.removeOrphanedDocuments(e,r))).next(m=>(d=Date.now(),Js()<=fe.DEBUG&&K("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-f}ms
	Determined least recently used ${s} in `+(l-o)+`ms
	Removed ${i} targets in `+(u-l)+`ms
	Removed ${m} documents in `+(d-u)+`ms
Total Duration: ${d-f}ms`),j.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:i,documentsRemoved:m})))}}function ib(t,e){return new sb(t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ob{constructor(){this.changes=new js(e=>e.toString(),(e,n)=>e.isEqual(n)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,n){this.assertNotApplied(),this.changes.set(e,wt.newInvalidDocument(e).setReadTime(n))}getEntry(e,n){this.assertNotApplied();const r=this.changes.get(n);return r!==void 0?j.resolve(r):this.getFromCache(e,n)}getEntries(e,n){return this.getAllFromCache(e,n)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ab{constructor(e,n){this.overlayedDocument=e,this.mutatedFields=n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lb{constructor(e,n,r,s){this.remoteDocumentCache=e,this.mutationQueue=n,this.documentOverlayCache=r,this.indexManager=s}getDocument(e,n){let r=null;return this.documentOverlayCache.getOverlay(e,n).next(s=>(r=s,this.remoteDocumentCache.getEntry(e,n))).next(s=>(r!==null&&qo(r.mutation,s,_n.empty(),Ie.now()),s))}getDocuments(e,n){return this.remoteDocumentCache.getEntries(e,n).next(r=>this.getLocalViewOfDocuments(e,r,ue()).next(()=>r))}getLocalViewOfDocuments(e,n,r=ue()){const s=Es();return this.populateOverlays(e,s,n).next(()=>this.computeViews(e,n,s,r).next(i=>{let o=Co();return i.forEach((l,u)=>{o=o.insert(l,u.overlayedDocument)}),o}))}getOverlayedDocuments(e,n){const r=Es();return this.populateOverlays(e,r,n).next(()=>this.computeViews(e,n,r,ue()))}populateOverlays(e,n,r){const s=[];return r.forEach(i=>{n.has(i)||s.push(i)}),this.documentOverlayCache.getOverlays(e,s).next(i=>{i.forEach((o,l)=>{n.set(o,l)})})}computeViews(e,n,r,s){let i=rr();const o=$o(),l=function(){return $o()}();return n.forEach((u,d)=>{const f=r.get(d.key);s.has(d.key)&&(f===void 0||f.mutation instanceof Os)?i=i.insert(d.key,d):f!==void 0?(o.set(d.key,f.mutation.getFieldMask()),qo(f.mutation,d,f.mutation.getFieldMask(),Ie.now())):o.set(d.key,_n.empty())}),this.recalculateAndSaveOverlays(e,i).next(u=>(u.forEach((d,f)=>o.set(d,f)),n.forEach((d,f)=>l.set(d,new ab(f,o.get(d)??null))),l))}recalculateAndSaveOverlays(e,n){const r=$o();let s=new Le((o,l)=>o-l),i=ue();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,n).next(o=>{for(const l of o)l.keys().forEach(u=>{const d=n.get(u);if(d===null)return;let f=r.get(u)||_n.empty();f=l.applyToLocalView(d,f),r.set(u,f);const m=(s.get(l.batchId)||ue()).add(u);s=s.insert(l.batchId,m)})}).next(()=>{const o=[],l=s.getReverseIterator();for(;l.hasNext();){const u=l.getNext(),d=u.key,f=u.value,m=Jv();f.forEach(v=>{if(!i.has(v)){const I=s1(n.get(v),r.get(v));I!==null&&m.set(v,I),i=i.add(v)}}),o.push(this.documentOverlayCache.saveOverlays(e,d,m))}return j.waitFor(o)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,n){return this.remoteDocumentCache.getEntries(e,n).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,n,r,s){return lT(n)?this.getDocumentsMatchingDocumentQuery(e,n.path):Gv(n)?this.getDocumentsMatchingCollectionGroupQuery(e,n,r,s):this.getDocumentsMatchingCollectionQuery(e,n,r,s)}getNextDocuments(e,n,r,s){return this.remoteDocumentCache.getAllFromCollectionGroup(e,n,r,s).next(i=>{const o=s-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,n,r.largestBatchId,s-i.size):j.resolve(Es());let l=ha,u=i;return o.next(d=>j.forEach(d,(f,m)=>(l<m.largestBatchId&&(l=m.largestBatchId),i.get(f)?j.resolve():this.remoteDocumentCache.getEntry(e,f).next(v=>{u=u.insert(f,v)}))).next(()=>this.populateOverlays(e,d,i)).next(()=>this.computeViews(e,u,d,ue())).next(f=>({batchId:l,changes:Xv(f)})))})}getDocumentsMatchingDocumentQuery(e,n){return this.getDocument(e,new X(n)).next(r=>{let s=Co();return r.isFoundDocument()&&(s=s.insert(r.key,r)),s})}getDocumentsMatchingCollectionGroupQuery(e,n,r,s){const i=n.collectionGroup;let o=Co();return this.indexManager.getCollectionParents(e,i).next(l=>j.forEach(l,u=>{const d=function(m,v){return new Wi(v,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(n,u.child(i));return this.getDocumentsMatchingCollectionQuery(e,d,r,s).next(f=>{f.forEach((m,v)=>{o=o.insert(m,v)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,n,r,s){let i;return this.documentOverlayCache.getOverlaysForCollection(e,n.path,r.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,n,r,i,s))).next(o=>{i.forEach((u,d)=>{const f=d.getKey();o.get(f)===null&&(o=o.insert(f,wt.newInvalidDocument(f)))});let l=Co();return o.forEach((u,d)=>{const f=i.get(u);f!==void 0&&qo(f.mutation,d,_n.empty(),Ie.now()),Qu(n,d)&&(l=l.insert(u,d))}),l})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ub{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,n){return j.resolve(this.Nr.get(n))}saveBundleMetadata(e,n){return this.Nr.set(n.id,function(s){return{id:s.id,version:s.version,createTime:jn(s.createTime)}}(n)),j.resolve()}getNamedQuery(e,n){return j.resolve(this.Br.get(n))}saveNamedQuery(e,n){return this.Br.set(n.name,function(s){return{name:s.name,query:JT(s.bundledQuery),readTime:jn(s.readTime)}}(n)),j.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cb{constructor(){this.overlays=new Le(X.comparator),this.Lr=new Map}getOverlay(e,n){return j.resolve(this.overlays.get(n))}getOverlays(e,n){const r=Es();return j.forEach(n,s=>this.getOverlay(e,s).next(i=>{i!==null&&r.set(s,i)})).next(()=>r)}saveOverlays(e,n,r){return r.forEach((s,i)=>{this.St(e,n,i)}),j.resolve()}removeOverlaysForBatchId(e,n,r){const s=this.Lr.get(r);return s!==void 0&&(s.forEach(i=>this.overlays=this.overlays.remove(i)),this.Lr.delete(r)),j.resolve()}getOverlaysForCollection(e,n,r){const s=Es(),i=n.length+1,o=new X(n.child("")),l=this.overlays.getIteratorFrom(o);for(;l.hasNext();){const u=l.getNext().value,d=u.getKey();if(!n.isPrefixOf(d.path))break;d.path.length===i&&u.largestBatchId>r&&s.set(u.getKey(),u)}return j.resolve(s)}getOverlaysForCollectionGroup(e,n,r,s){let i=new Le((d,f)=>d-f);const o=this.overlays.getIterator();for(;o.hasNext();){const d=o.getNext().value;if(d.getKey().getCollectionGroup()===n&&d.largestBatchId>r){let f=i.get(d.largestBatchId);f===null&&(f=Es(),i=i.insert(d.largestBatchId,f)),f.set(d.getKey(),d)}}const l=Es(),u=i.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach((d,f)=>l.set(d,f)),!(l.size()>=s)););return j.resolve(l)}St(e,n,r){const s=this.overlays.get(r.key);if(s!==null){const o=this.Lr.get(s.largestBatchId).delete(r.key);this.Lr.set(s.largestBatchId,o)}this.overlays=this.overlays.insert(r.key,new AT(n,r));let i=this.Lr.get(n);i===void 0&&(i=ue(),this.Lr.set(n,i)),this.Lr.set(n,i.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class db{constructor(){this.sessionToken=pt.EMPTY_BYTE_STRING}getSessionToken(e){return j.resolve(this.sessionToken)}setSessionToken(e,n){return this.sessionToken=n,j.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Af{constructor(){this.kr=new Ze(it.qr),this.Kr=new Ze(it.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,n){const r=new it(e,n);this.kr=this.kr.add(r),this.Kr=this.Kr.add(r)}$r(e,n){e.forEach(r=>this.addReference(r,n))}removeReference(e,n){this.Wr(new it(e,n))}Qr(e,n){e.forEach(r=>this.removeReference(r,n))}Gr(e){const n=new X(new xe([])),r=new it(n,e),s=new it(n,e+1),i=[];return this.Kr.forEachInRange([r,s],o=>{this.Wr(o),i.push(o.key)}),i}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const n=new X(new xe([])),r=new it(n,e),s=new it(n,e+1);let i=ue();return this.Kr.forEachInRange([r,s],o=>{i=i.add(o.key)}),i}containsKey(e){const n=new it(e,0),r=this.kr.firstAfterOrEqual(n);return r!==null&&e.isEqual(r.key)}}class it{constructor(e,n){this.key=e,this.Jr=n}static qr(e,n){return X.comparator(e.key,n.key)||le(e.Jr,n.Jr)}static Ur(e,n){return le(e.Jr,n.Jr)||X.comparator(e.key,n.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hb{constructor(e,n){this.indexManager=e,this.referenceDelegate=n,this.mutationQueue=[],this.Yn=1,this.Hr=new Ze(it.qr)}checkEmpty(e){return j.resolve(this.mutationQueue.length===0)}addMutationBatch(e,n,r,s){const i=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new IT(i,n,r,s);this.mutationQueue.push(o);for(const l of s)this.Hr=this.Hr.add(new it(l.key,i)),this.indexManager.addToCollectionParentIndex(e,l.key.path.popLast());return j.resolve(o)}lookupMutationBatch(e,n){return j.resolve(this.Zr(n))}getNextMutationBatchAfterBatchId(e,n){const r=n+1,s=this.Xr(r),i=s<0?0:s;return j.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return j.resolve(this.mutationQueue.length===0?_f:this.Yn-1)}getAllMutationBatches(e){return j.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,n){const r=new it(n,0),s=new it(n,Number.POSITIVE_INFINITY),i=[];return this.Hr.forEachInRange([r,s],o=>{const l=this.Zr(o.Jr);i.push(l)}),j.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,n){let r=new Ze(le);return n.forEach(s=>{const i=new it(s,0),o=new it(s,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([i,o],l=>{r=r.add(l.Jr)})}),j.resolve(this.Yr(r))}getAllMutationBatchesAffectingQuery(e,n){const r=n.path,s=r.length+1;let i=r;X.isDocumentKey(i)||(i=i.child(""));const o=new it(new X(i),0);let l=new Ze(le);return this.Hr.forEachWhile(u=>{const d=u.key.path;return!!r.isPrefixOf(d)&&(d.length===s&&(l=l.add(u.Jr)),!0)},o),j.resolve(this.Yr(l))}Yr(e){const n=[];return e.forEach(r=>{const s=this.Zr(r);s!==null&&n.push(s)}),n}removeMutationBatch(e,n){ye(this.ei(n.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.Hr;return j.forEach(n.mutations,s=>{const i=new it(s.key,n.batchId);return r=r.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,s.key)}).next(()=>{this.Hr=r})}nr(e){}containsKey(e,n){const r=new it(n,0),s=this.Hr.firstAfterOrEqual(r);return j.resolve(n.isEqual(s&&s.key))}performConsistencyCheck(e){return this.mutationQueue.length,j.resolve()}ei(e,n){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const n=this.Xr(e);return n<0||n>=this.mutationQueue.length?null:this.mutationQueue[n]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fb{constructor(e){this.ti=e,this.docs=function(){return new Le(X.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,n){const r=n.key,s=this.docs.get(r),i=s?s.size:0,o=this.ti(n);return this.docs=this.docs.insert(r,{document:n.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const n=this.docs.get(e);n&&(this.docs=this.docs.remove(e),this.size-=n.size)}getEntry(e,n){const r=this.docs.get(n);return j.resolve(r?r.document.mutableCopy():wt.newInvalidDocument(n))}getEntries(e,n){let r=rr();return n.forEach(s=>{const i=this.docs.get(s);r=r.insert(s,i?i.document.mutableCopy():wt.newInvalidDocument(s))}),j.resolve(r)}getDocumentsMatchingQuery(e,n,r,s){let i=rr();const o=n.path,l=new X(o.child("__id-9223372036854775808__")),u=this.docs.getIteratorFrom(l);for(;u.hasNext();){const{key:d,value:{document:f}}=u.getNext();if(!o.isPrefixOf(d.path))break;d.path.length>o.length+1||OE(jE(f),r)<=0||(s.has(f.key)||Qu(n,f))&&(i=i.insert(f.key,f.mutableCopy()))}return j.resolve(i)}getAllFromCollectionGroup(e,n,r,s){ee(9500)}ni(e,n){return j.forEach(this.docs,r=>n(r))}newChangeBuffer(e){return new pb(this)}getSize(e){return j.resolve(this.size)}}class pb extends ob{constructor(e){super(),this.Mr=e}applyChanges(e){const n=[];return this.changes.forEach((r,s)=>{s.isValidDocument()?n.push(this.Mr.addEntry(e,s)):this.Mr.removeEntry(r)}),j.waitFor(n)}getFromCache(e,n){return this.Mr.getEntry(e,n)}getAllFromCache(e,n){return this.Mr.getEntries(e,n)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mb{constructor(e){this.persistence=e,this.ri=new js(n=>Ef(n),Tf),this.lastRemoteSnapshotVersion=re.min(),this.highestTargetId=0,this.ii=0,this.si=new Af,this.targetCount=0,this.oi=ji._r()}forEachTarget(e,n){return this.ri.forEach((r,s)=>n(s)),j.resolve()}getLastRemoteSnapshotVersion(e){return j.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return j.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),j.resolve(this.highestTargetId)}setTargetsMetadata(e,n,r){return r&&(this.lastRemoteSnapshotVersion=r),n>this.ii&&(this.ii=n),j.resolve()}lr(e){this.ri.set(e.target,e);const n=e.targetId;n>this.highestTargetId&&(this.oi=new ji(n),this.highestTargetId=n),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,n){return this.lr(n),this.targetCount+=1,j.resolve()}updateTargetData(e,n){return this.lr(n),j.resolve()}removeTargetData(e,n){return this.ri.delete(n.target),this.si.Gr(n.targetId),this.targetCount-=1,j.resolve()}removeTargets(e,n,r){let s=0;const i=[];return this.ri.forEach((o,l)=>{l.sequenceNumber<=n&&r.get(l.targetId)===null&&(this.ri.delete(o),i.push(this.removeMatchingKeysForTargetId(e,l.targetId)),s++)}),j.waitFor(i).next(()=>s)}getTargetCount(e){return j.resolve(this.targetCount)}getTargetData(e,n){const r=this.ri.get(n)||null;return j.resolve(r)}addMatchingKeys(e,n,r){return this.si.$r(n,r),j.resolve()}removeMatchingKeys(e,n,r){this.si.Qr(n,r);const s=this.persistence.referenceDelegate,i=[];return s&&n.forEach(o=>{i.push(s.markPotentiallyOrphaned(e,o))}),j.waitFor(i)}removeMatchingKeysForTargetId(e,n){return this.si.Gr(n),j.resolve()}getMatchingKeysForTargetId(e,n){const r=this.si.jr(n);return j.resolve(r)}containsKey(e,n){return j.resolve(this.si.containsKey(n))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _1{constructor(e,n){this._i={},this.overlays={},this.ai=new Hu(0),this.ui=!1,this.ui=!0,this.ci=new db,this.referenceDelegate=e(this),this.li=new mb(this),this.indexManager=new ZT,this.remoteDocumentCache=function(s){return new fb(s)}(r=>this.referenceDelegate.hi(r)),this.serializer=new XT(n),this.Pi=new ub(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let n=this.overlays[e.toKey()];return n||(n=new cb,this.overlays[e.toKey()]=n),n}getMutationQueue(e,n){let r=this._i[e.toKey()];return r||(r=new hb(n,this.referenceDelegate),this._i[e.toKey()]=r),r}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,n,r){K("MemoryPersistence","Starting transaction:",e);const s=new gb(this.ai.next());return this.referenceDelegate.Ti(),r(s).next(i=>this.referenceDelegate.Ei(s).next(()=>i)).toPromise().then(i=>(s.raiseOnCommittedEvent(),i))}Ii(e,n){return j.or(Object.values(this._i).map(r=>()=>r.containsKey(e,n)))}}class gb extends zE{constructor(e){super(),this.currentSequenceNumber=e}}class Cf{constructor(e){this.persistence=e,this.Ri=new Af,this.Ai=null}static Vi(e){return new Cf(e)}get di(){if(this.Ai)return this.Ai;throw ee(60996)}addReference(e,n,r){return this.Ri.addReference(r,n),this.di.delete(r.toString()),j.resolve()}removeReference(e,n,r){return this.Ri.removeReference(r,n),this.di.add(r.toString()),j.resolve()}markPotentiallyOrphaned(e,n){return this.di.add(n.toString()),j.resolve()}removeTarget(e,n){this.Ri.Gr(n.targetId).forEach(s=>this.di.add(s.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,n.targetId).next(s=>{s.forEach(i=>this.di.add(i.toString()))}).next(()=>r.removeTargetData(e,n))}Ti(){this.Ai=new Set}Ei(e){const n=this.persistence.getRemoteDocumentCache().newChangeBuffer();return j.forEach(this.di,r=>{const s=X.fromPath(r);return this.mi(e,s).next(i=>{i||n.removeEntry(s,re.min())})}).next(()=>(this.Ai=null,n.apply(e)))}updateLimboDocument(e,n){return this.mi(e,n).next(r=>{r?this.di.delete(n.toString()):this.di.add(n.toString())})}hi(e){return 0}mi(e,n){return j.or([()=>j.resolve(this.Ri.containsKey(n)),()=>this.persistence.getTargetCache().containsKey(e,n),()=>this.persistence.Ii(e,n)])}}class wu{constructor(e,n){this.persistence=e,this.fi=new js(r=>$E(r.path),(r,s)=>r.isEqual(s)),this.garbageCollector=ib(this,n)}static Vi(e,n){return new wu(e,n)}Ti(){}Ei(e){return j.resolve()}forEachTarget(e,n){return this.persistence.getTargetCache().forEachTarget(e,n)}dr(e){const n=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(r=>n.next(s=>r+s))}pr(e){let n=0;return this.mr(e,r=>{n++}).next(()=>n)}mr(e,n){return j.forEach(this.fi,(r,s)=>this.wr(e,r,s).next(i=>i?j.resolve():n(s)))}removeTargets(e,n,r){return this.persistence.getTargetCache().removeTargets(e,n,r)}removeOrphanedDocuments(e,n){let r=0;const s=this.persistence.getRemoteDocumentCache(),i=s.newChangeBuffer();return s.ni(e,o=>this.wr(e,o,n).next(l=>{l||(r++,i.removeEntry(o,re.min()))})).next(()=>i.apply(e)).next(()=>r)}markPotentiallyOrphaned(e,n){return this.fi.set(n,e.currentSequenceNumber),j.resolve()}removeTarget(e,n){const r=n.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,r)}addReference(e,n,r){return this.fi.set(r,e.currentSequenceNumber),j.resolve()}removeReference(e,n,r){return this.fi.set(r,e.currentSequenceNumber),j.resolve()}updateLimboDocument(e,n){return this.fi.set(n,e.currentSequenceNumber),j.resolve()}hi(e){let n=e.key.toString().length;return e.isFoundDocument()&&(n+=Dl(e.data.value)),n}wr(e,n,r){return j.or([()=>this.persistence.Ii(e,n),()=>this.persistence.getTargetCache().containsKey(e,n),()=>{const s=this.fi.get(n);return j.resolve(s!==void 0&&s>r)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rf{constructor(e,n,r,s){this.targetId=e,this.fromCache=n,this.Ts=r,this.Es=s}static Is(e,n){let r=ue(),s=ue();for(const i of n.docChanges)switch(i.type){case 0:r=r.add(i.doc.key);break;case 1:s=s.add(i.doc.key)}return new Rf(e,n.fromCache,r,s)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yb{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vb{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return n2()?8:UE(e2())>0?6:4}()}initialize(e,n){this.fs=e,this.indexManager=n,this.Rs=!0}getDocumentsMatchingQuery(e,n,r,s){const i={result:null};return this.gs(e,n).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.ps(e,n,s,r).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new yb;return this.ys(e,n,o).next(l=>{if(i.result=l,this.As)return this.ws(e,n,o,l.size)})}).next(()=>i.result)}ws(e,n,r,s){return r.documentReadCount<this.Vs?(Js()<=fe.DEBUG&&K("QueryEngine","SDK will not create cache indexes for query:",Zs(n),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),j.resolve()):(Js()<=fe.DEBUG&&K("QueryEngine","Query:",Zs(n),"scans",r.documentReadCount,"local documents and returns",s,"documents as results."),r.documentReadCount>this.ds*s?(Js()<=fe.DEBUG&&K("QueryEngine","The SDK decides to create cache indexes for query:",Zs(n),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,Ln(n))):j.resolve())}gs(e,n){if(rg(n))return j.resolve(null);let r=Ln(n);return this.indexManager.getIndexType(e,r).next(s=>s===0?null:(n.limit!==null&&s===1&&(n=yu(n,null,"F"),r=Ln(n)),this.indexManager.getDocumentsMatchingTarget(e,r).next(i=>{const o=ue(...i);return this.fs.getDocuments(e,o).next(l=>this.indexManager.getMinOffset(e,r).next(u=>{const d=this.Ss(n,l);return this.bs(n,d,o,u.readTime)?this.gs(e,yu(n,null,"F")):this.Ds(e,d,n,u)}))})))}ps(e,n,r,s){return rg(n)||s.isEqual(re.min())?j.resolve(null):this.fs.getDocuments(e,r).next(i=>{const o=this.Ss(n,i);return this.bs(n,o,r,s)?j.resolve(null):(Js()<=fe.DEBUG&&K("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),Zs(n)),this.Ds(e,o,n,LE(s,ha)).next(l=>l))})}Ss(e,n){let r=new Ze(Qv(e));return n.forEach((s,i)=>{Qu(e,i)&&(r=r.add(i))}),r}bs(e,n,r,s){if(e.limit===null)return!1;if(r.size!==n.size)return!0;const i=e.limitType==="F"?n.last():n.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(s)>0)}ys(e,n,r){return Js()<=fe.DEBUG&&K("QueryEngine","Using full collection scan to execute query:",Zs(n)),this.fs.getDocumentsMatchingQuery(e,n,qr.min(),r)}Ds(e,n,r,s){return this.fs.getDocumentsMatchingQuery(e,r,s).next(i=>(n.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pf="LocalStore",_b=3e8;class wb{constructor(e,n,r,s){this.persistence=e,this.Cs=n,this.serializer=s,this.vs=new Le(le),this.Fs=new js(i=>Ef(i),Tf),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(r)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new lb(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",n=>e.collect(n,this.vs))}}function xb(t,e,n,r){return new wb(t,e,n,r)}async function w1(t,e){const n=se(t);return await n.persistence.runTransaction("Handle user change","readonly",r=>{let s;return n.mutationQueue.getAllMutationBatches(r).next(i=>(s=i,n.Os(e),n.mutationQueue.getAllMutationBatches(r))).next(i=>{const o=[],l=[];let u=ue();for(const d of s){o.push(d.batchId);for(const f of d.mutations)u=u.add(f.key)}for(const d of i){l.push(d.batchId);for(const f of d.mutations)u=u.add(f.key)}return n.localDocuments.getDocuments(r,u).next(d=>({Ns:d,removedBatchIds:o,addedBatchIds:l}))})})}function Eb(t,e){const n=se(t);return n.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const s=e.batch.keys(),i=n.xs.newChangeBuffer({trackRemovals:!0});return function(l,u,d,f){const m=d.batch,v=m.keys();let I=j.resolve();return v.forEach(A=>{I=I.next(()=>f.getEntry(u,A)).next(P=>{const M=d.docVersions.get(A);ye(M!==null,48541),P.version.compareTo(M)<0&&(m.applyToRemoteDocument(P,d),P.isValidDocument()&&(P.setReadTime(d.commitVersion),f.addEntry(P)))})}),I.next(()=>l.mutationQueue.removeMutationBatch(u,m))}(n,r,e,i).next(()=>i.apply(r)).next(()=>n.mutationQueue.performConsistencyCheck(r)).next(()=>n.documentOverlayCache.removeOverlaysForBatchId(r,s,e.batch.batchId)).next(()=>n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(l){let u=ue();for(let d=0;d<l.mutationResults.length;++d)l.mutationResults[d].transformResults.length>0&&(u=u.add(l.batch.mutations[d].key));return u}(e))).next(()=>n.localDocuments.getDocuments(r,s))})}function x1(t){const e=se(t);return e.persistence.runTransaction("Get last remote snapshot version","readonly",n=>e.li.getLastRemoteSnapshotVersion(n))}function Tb(t,e){const n=se(t),r=e.snapshotVersion;let s=n.vs;return n.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=n.xs.newChangeBuffer({trackRemovals:!0});s=n.vs;const l=[];e.targetChanges.forEach((f,m)=>{const v=s.get(m);if(!v)return;l.push(n.li.removeMatchingKeys(i,f.removedDocuments,m).next(()=>n.li.addMatchingKeys(i,f.addedDocuments,m)));let I=v.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(m)!==null?I=I.withResumeToken(pt.EMPTY_BYTE_STRING,re.min()).withLastLimboFreeSnapshotVersion(re.min()):f.resumeToken.approximateByteSize()>0&&(I=I.withResumeToken(f.resumeToken,r)),s=s.insert(m,I),function(P,M,S){return P.resumeToken.approximateByteSize()===0||M.snapshotVersion.toMicroseconds()-P.snapshotVersion.toMicroseconds()>=_b?!0:S.addedDocuments.size+S.modifiedDocuments.size+S.removedDocuments.size>0}(v,I,f)&&l.push(n.li.updateTargetData(i,I))});let u=rr(),d=ue();if(e.documentUpdates.forEach(f=>{e.resolvedLimboDocuments.has(f)&&l.push(n.persistence.referenceDelegate.updateLimboDocument(i,f))}),l.push(bb(i,o,e.documentUpdates).next(f=>{u=f.Bs,d=f.Ls})),!r.isEqual(re.min())){const f=n.li.getLastRemoteSnapshotVersion(i).next(m=>n.li.setTargetsMetadata(i,i.currentSequenceNumber,r));l.push(f)}return j.waitFor(l).next(()=>o.apply(i)).next(()=>n.localDocuments.getLocalViewOfDocuments(i,u,d)).next(()=>u)}).then(i=>(n.vs=s,i))}function bb(t,e,n){let r=ue(),s=ue();return n.forEach(i=>r=r.add(i)),e.getEntries(t,r).next(i=>{let o=rr();return n.forEach((l,u)=>{const d=i.get(l);u.isFoundDocument()!==d.isFoundDocument()&&(s=s.add(l)),u.isNoDocument()&&u.version.isEqual(re.min())?(e.removeEntry(l,u.readTime),o=o.insert(l,u)):!d.isValidDocument()||u.version.compareTo(d.version)>0||u.version.compareTo(d.version)===0&&d.hasPendingWrites?(e.addEntry(u),o=o.insert(l,u)):K(Pf,"Ignoring outdated watch update for ",l,". Current version:",d.version," Watch version:",u.version)}),{Bs:o,Ls:s}})}function Sb(t,e){const n=se(t);return n.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=_f),n.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function kb(t,e){const n=se(t);return n.persistence.runTransaction("Allocate target","readwrite",r=>{let s;return n.li.getTargetData(r,e).next(i=>i?(s=i,j.resolve(s)):n.li.allocateTargetId(r).next(o=>(s=new Ar(e,o,"TargetPurposeListen",r.currentSequenceNumber),n.li.addTargetData(r,s).next(()=>s))))}).then(r=>{const s=n.vs.get(r.targetId);return(s===null||r.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(n.vs=n.vs.insert(r.targetId,r),n.Fs.set(e,r.targetId)),r})}async function uh(t,e,n){const r=se(t),s=r.vs.get(e),i=n?"readwrite":"readwrite-primary";try{n||await r.persistence.runTransaction("Release target",i,o=>r.persistence.referenceDelegate.removeTarget(o,s))}catch(o){if(!Hi(o))throw o;K(Pf,`Failed to update sequence numbers for target ${e}: ${o}`)}r.vs=r.vs.remove(e),r.Fs.delete(s.target)}function gg(t,e,n){const r=se(t);let s=re.min(),i=ue();return r.persistence.runTransaction("Execute query","readwrite",o=>function(u,d,f){const m=se(u),v=m.Fs.get(f);return v!==void 0?j.resolve(m.vs.get(v)):m.li.getTargetData(d,f)}(r,o,Ln(e)).next(l=>{if(l)return s=l.lastLimboFreeSnapshotVersion,r.li.getMatchingKeysForTargetId(o,l.targetId).next(u=>{i=u})}).next(()=>r.Cs.getDocumentsMatchingQuery(o,e,n?s:re.min(),n?i:ue())).next(l=>(Ib(r,dT(e),l),{documents:l,ks:i})))}function Ib(t,e,n){let r=t.Ms.get(e)||re.min();n.forEach((s,i)=>{i.readTime.compareTo(r)>0&&(r=i.readTime)}),t.Ms.set(e,r)}class yg{constructor(){this.activeTargetIds=yT()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class Ab{constructor(){this.vo=new yg,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,n,r){}addLocalQueryTarget(e,n=!0){return n&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,n,r){this.Fo[e]=n}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new yg,Promise.resolve()}handleUserChange(e,n,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cb{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vg="ConnectivityMonitor";class _g{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){K(vg,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){K(vg,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let gl=null;function ch(){return gl===null?gl=function(){return 268435456+Math.round(2147483648*Math.random())}():gl++,"0x"+gl.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qc="RestConnection",Rb={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class Pb{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const n=e.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.Ko=n+"://"+e.host,this.Uo=`projects/${r}/databases/${s}`,this.$o=this.databaseId.database===pu?`project_id=${r}`:`project_id=${r}&database_id=${s}`}Wo(e,n,r,s,i){const o=ch(),l=this.Qo(e,n.toUriEncodedString());K(Qc,`Sending RPC '${e}' ${o}:`,l,r);const u={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(u,s,i);const{host:d}=new URL(l),f=fv(d);return this.zo(e,l,u,r,f).then(m=>(K(Qc,`Received RPC '${e}' ${o}: `,m),m),m=>{throw Ns(Qc,`RPC '${e}' ${o} failed with error: `,m,"url: ",l,"request:",r),m})}jo(e,n,r,s,i,o){return this.Wo(e,n,r,s,i)}Go(e,n,r){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+$i}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),n&&n.headers.forEach((s,i)=>e[i]=s),r&&r.headers.forEach((s,i)=>e[i]=s)}Qo(e,n){const r=Rb[e];let s=`${this.Ko}/v1/${n}:${r}`;return this.databaseInfo.apiKey&&(s=`${s}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),s}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nb{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yt="WebChannelConnection",Eo=(t,e,n)=>{t.listen(e,r=>{try{n(r)}catch(s){setTimeout(()=>{throw s},0)}})};class Ei extends Pb{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!Ei.c_){const e=bv();Eo(e,Tv.STAT_EVENT,n=>{n.stat===Jd.PROXY?K(yt,"STAT_EVENT: detected buffering proxy"):n.stat===Jd.NOPROXY&&K(yt,"STAT_EVENT: detected no buffering proxy")}),Ei.c_=!0}}zo(e,n,r,s,i){const o=ch();return new Promise((l,u)=>{const d=new xv;d.setWithCredentials(!0),d.listenOnce(Ev.COMPLETE,()=>{try{switch(d.getLastErrorCode()){case Vl.NO_ERROR:const m=d.getResponseJson();K(yt,`XHR for RPC '${e}' ${o} received:`,JSON.stringify(m)),l(m);break;case Vl.TIMEOUT:K(yt,`RPC '${e}' ${o} timed out`),u(new G(L.DEADLINE_EXCEEDED,"Request time out"));break;case Vl.HTTP_ERROR:const v=d.getStatus();if(K(yt,`RPC '${e}' ${o} failed with status:`,v,"response text:",d.getResponseText()),v>0){let I=d.getResponseJson();Array.isArray(I)&&(I=I[0]);const A=I==null?void 0:I.error;if(A&&A.status&&A.message){const P=function(S){const x=S.toLowerCase().replace(/_/g,"-");return Object.values(L).indexOf(x)>=0?x:L.UNKNOWN}(A.status);u(new G(P,A.message))}else u(new G(L.UNKNOWN,"Server responded with status "+d.getStatus()))}else u(new G(L.UNAVAILABLE,"Connection failed."));break;default:ee(9055,{l_:e,streamId:o,h_:d.getLastErrorCode(),P_:d.getLastError()})}}finally{K(yt,`RPC '${e}' ${o} completed.`)}});const f=JSON.stringify(s);K(yt,`RPC '${e}' ${o} sending request:`,s),d.send(n,"POST",f,r,15)})}T_(e,n,r){const s=ch(),i=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=this.createWebChannelTransport(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.useFetchStreams=!0),this.Go(l.initMessageHeaders,n,r),l.encodeInitMessageHeaders=!0;const d=i.join("");K(yt,`Creating RPC '${e}' stream ${s}: ${d}`,l);const f=o.createWebChannel(d,l);this.E_(f);let m=!1,v=!1;const I=new Nb({Jo:A=>{v?K(yt,`Not sending because RPC '${e}' stream ${s} is closed:`,A):(m||(K(yt,`Opening RPC '${e}' stream ${s} transport.`),f.open(),m=!0),K(yt,`RPC '${e}' stream ${s} sending:`,A),f.send(A))},Ho:()=>f.close()});return Eo(f,Ao.EventType.OPEN,()=>{v||(K(yt,`RPC '${e}' stream ${s} transport opened.`),I.i_())}),Eo(f,Ao.EventType.CLOSE,()=>{v||(v=!0,K(yt,`RPC '${e}' stream ${s} transport closed`),I.o_(),this.I_(f))}),Eo(f,Ao.EventType.ERROR,A=>{v||(v=!0,Ns(yt,`RPC '${e}' stream ${s} transport errored. Name:`,A.name,"Message:",A.message),I.o_(new G(L.UNAVAILABLE,"The operation could not be completed")))}),Eo(f,Ao.EventType.MESSAGE,A=>{var P;if(!v){const M=A.data[0];ye(!!M,16349);const S=M,x=(S==null?void 0:S.error)||((P=S[0])==null?void 0:P.error);if(x){K(yt,`RPC '${e}' stream ${s} received error:`,x);const k=x.status;let V=function(w){const y=He[w];if(y!==void 0)return a1(y)}(k),F=x.message;k==="NOT_FOUND"&&F.includes("database")&&F.includes("does not exist")&&F.includes(this.databaseId.database)&&Ns(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),V===void 0&&(V=L.INTERNAL,F="Unknown error status: "+k+" with message "+x.message),v=!0,I.o_(new G(V,F)),f.close()}else K(yt,`RPC '${e}' stream ${s} received:`,M),I.__(M)}}),Ei.u_(),setTimeout(()=>{I.s_()},0),I}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(n=>n===e)}Go(e,n,r){super.Go(e,n,r),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Sv()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vb(t){return new Ei(t)}function Yc(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zu(t){return new jT(t,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ei.c_=!1;class E1{constructor(e,n,r=1e3,s=1.5,i=6e4){this.Ci=e,this.timerId=n,this.R_=r,this.A_=s,this.V_=i,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const n=Math.floor(this.d_+this.y_()),r=Math.max(0,Date.now()-this.f_),s=Math.max(0,n-r);s>0&&K("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.d_} ms, delay with jitter: ${n} ms, last attempt: ${r} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,s,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wg="PersistentStream";class T1{constructor(e,n,r,s,i,o,l,u){this.Ci=e,this.S_=r,this.b_=s,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=l,this.listener=u,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new E1(e,n)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,n){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():n&&n.code===L.RESOURCE_EXHAUSTED?(nr(n.toString()),nr("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):n&&n.code===L.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(n)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),n=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,s])=>{this.D_===n&&this.G_(r,s)},r=>{e(()=>{const s=new G(L.UNKNOWN,"Fetching auth token failed: "+r.message);return this.z_(s)})})}G_(e,n){const r=this.Q_(this.D_);this.stream=this.j_(e,n),this.stream.Zo(()=>{r(()=>this.listener.Zo())}),this.stream.Yo(()=>{r(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(s=>{r(()=>this.z_(s))}),this.stream.onMessage(s=>{r(()=>++this.F_==1?this.J_(s):this.onNext(s))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return K(wg,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return n=>{this.Ci.enqueueAndForget(()=>this.D_===e?n():(K(wg,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class Db extends T1{constructor(e,n,r,s,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",n,r,s,o),this.serializer=i}j_(e,n){return this.connection.T_("Listen",e,n)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const n=zT(this.serializer,e),r=function(i){if(!("targetChange"in i))return re.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?re.min():o.readTime?jn(o.readTime):re.min()}(e);return this.listener.H_(n,r)}Z_(e){const n={};n.database=lh(this.serializer),n.addTarget=function(i,o){let l;const u=o.target;if(l=rh(u)?{documents:$T(i,u)}:{query:qT(i,u).ft},l.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){l.resumeToken=c1(i,o.resumeToken);const d=ih(i,o.expectedCount);d!==null&&(l.expectedCount=d)}else if(o.snapshotVersion.compareTo(re.min())>0){l.readTime=_u(i,o.snapshotVersion.toTimestamp());const d=ih(i,o.expectedCount);d!==null&&(l.expectedCount=d)}return l}(this.serializer,e);const r=WT(this.serializer,e);r&&(n.labels=r),this.q_(n)}X_(e){const n={};n.database=lh(this.serializer),n.removeTarget=e,this.q_(n)}}class Mb extends T1{constructor(e,n,r,s,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",n,r,s,o),this.serializer=i}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,n){return this.connection.T_("Write",e,n)}J_(e){return ye(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,ye(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){ye(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const n=BT(e.writeResults,e.commitTime),r=jn(e.commitTime);return this.listener.na(r,n)}ra(){const e={};e.database=lh(this.serializer),this.q_(e)}ea(e){const n={streamToken:this.lastStreamToken,writes:e.map(r=>UT(this.serializer,r))};this.q_(n)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lb{}class jb extends Lb{constructor(e,n,r,s){super(),this.authCredentials=e,this.appCheckCredentials=n,this.connection=r,this.serializer=s,this.ia=!1}sa(){if(this.ia)throw new G(L.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,n,r,s){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.Wo(e,oh(n,r),s,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===L.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new G(L.UNKNOWN,i.toString())})}jo(e,n,r,s,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,l])=>this.connection.jo(e,oh(n,r),s,o,l,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===L.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new G(L.UNKNOWN,o.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function Ob(t,e,n,r){return new jb(t,e,n,r)}class Fb{constructor(e,n){this.asyncQueue=e,this.onlineStateHandler=n,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const n=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(nr(n),this.aa=!1):K("OnlineStateTracker",n)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vs="RemoteStore";class zb{constructor(e,n,r,s,i){this.localStore=e,this.datastore=n,this.asyncQueue=r,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=i,this.Aa.Mo(o=>{r.enqueueAndForget(async()=>{Fs(this)&&(K(Vs,"Restarting streams for network reachability change."),await async function(u){const d=se(u);d.Ia.add(4),await Ca(d),d.Va.set("Unknown"),d.Ia.delete(4),await ec(d)}(this))})}),this.Va=new Fb(r,s)}}async function ec(t){if(Fs(t))for(const e of t.Ra)await e(!0)}async function Ca(t){for(const e of t.Ra)await e(!1)}function b1(t,e){const n=se(t);n.Ea.has(e.targetId)||(n.Ea.set(e.targetId,e),Mf(n)?Df(n):Gi(n).O_()&&Vf(n,e))}function Nf(t,e){const n=se(t),r=Gi(n);n.Ea.delete(e),r.O_()&&S1(n,e),n.Ea.size===0&&(r.O_()?r.L_():Fs(n)&&n.Va.set("Unknown"))}function Vf(t,e){if(t.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(re.min())>0){const n=t.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(n)}Gi(t).Z_(e)}function S1(t,e){t.da.$e(e),Gi(t).X_(e)}function Df(t){t.da=new VT({getRemoteKeysForTarget:e=>t.remoteSyncer.getRemoteKeysForTarget(e),At:e=>t.Ea.get(e)||null,ht:()=>t.datastore.serializer.databaseId}),Gi(t).start(),t.Va.ua()}function Mf(t){return Fs(t)&&!Gi(t).x_()&&t.Ea.size>0}function Fs(t){return se(t).Ia.size===0}function k1(t){t.da=void 0}async function Ub(t){t.Va.set("Online")}async function Bb(t){t.Ea.forEach((e,n)=>{Vf(t,e)})}async function $b(t,e){k1(t),Mf(t)?(t.Va.ha(e),Df(t)):t.Va.set("Unknown")}async function qb(t,e,n){if(t.Va.set("Online"),e instanceof u1&&e.state===2&&e.cause)try{await async function(s,i){const o=i.cause;for(const l of i.targetIds)s.Ea.has(l)&&(await s.remoteSyncer.rejectListen(l,o),s.Ea.delete(l),s.da.removeTarget(l))}(t,e)}catch(r){K(Vs,"Failed to remove targets %s: %s ",e.targetIds.join(","),r),await xu(t,r)}else if(e instanceof jl?t.da.Xe(e):e instanceof l1?t.da.st(e):t.da.tt(e),!n.isEqual(re.min()))try{const r=await x1(t.localStore);n.compareTo(r)>=0&&await function(i,o){const l=i.da.Tt(o);return l.targetChanges.forEach((u,d)=>{if(u.resumeToken.approximateByteSize()>0){const f=i.Ea.get(d);f&&i.Ea.set(d,f.withResumeToken(u.resumeToken,o))}}),l.targetMismatches.forEach((u,d)=>{const f=i.Ea.get(u);if(!f)return;i.Ea.set(u,f.withResumeToken(pt.EMPTY_BYTE_STRING,f.snapshotVersion)),S1(i,u);const m=new Ar(f.target,u,d,f.sequenceNumber);Vf(i,m)}),i.remoteSyncer.applyRemoteEvent(l)}(t,n)}catch(r){K(Vs,"Failed to raise snapshot:",r),await xu(t,r)}}async function xu(t,e,n){if(!Hi(e))throw e;t.Ia.add(1),await Ca(t),t.Va.set("Offline"),n||(n=()=>x1(t.localStore)),t.asyncQueue.enqueueRetryable(async()=>{K(Vs,"Retrying IndexedDB access"),await n(),t.Ia.delete(1),await ec(t)})}function I1(t,e){return e().catch(n=>xu(t,n,e))}async function tc(t){const e=se(t),n=Kr(e);let r=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:_f;for(;Hb(e);)try{const s=await Sb(e.localStore,r);if(s===null){e.Ta.length===0&&n.L_();break}r=s.batchId,Wb(e,s)}catch(s){await xu(e,s)}A1(e)&&C1(e)}function Hb(t){return Fs(t)&&t.Ta.length<10}function Wb(t,e){t.Ta.push(e);const n=Kr(t);n.O_()&&n.Y_&&n.ea(e.mutations)}function A1(t){return Fs(t)&&!Kr(t).x_()&&t.Ta.length>0}function C1(t){Kr(t).start()}async function Gb(t){Kr(t).ra()}async function Kb(t){const e=Kr(t);for(const n of t.Ta)e.ea(n.mutations)}async function Qb(t,e,n){const r=t.Ta.shift(),s=Sf.from(r,e,n);await I1(t,()=>t.remoteSyncer.applySuccessfulWrite(s)),await tc(t)}async function Yb(t,e){e&&Kr(t).Y_&&await async function(r,s){if(function(o){return RT(o)&&o!==L.ABORTED}(s.code)){const i=r.Ta.shift();Kr(r).B_(),await I1(r,()=>r.remoteSyncer.rejectFailedWrite(i.batchId,s)),await tc(r)}}(t,e),A1(t)&&C1(t)}async function xg(t,e){const n=se(t);n.asyncQueue.verifyOperationInProgress(),K(Vs,"RemoteStore received new credentials");const r=Fs(n);n.Ia.add(3),await Ca(n),r&&n.Va.set("Unknown"),await n.remoteSyncer.handleCredentialChange(e),n.Ia.delete(3),await ec(n)}async function Xb(t,e){const n=se(t);e?(n.Ia.delete(2),await ec(n)):e||(n.Ia.add(2),await Ca(n),n.Va.set("Unknown"))}function Gi(t){return t.ma||(t.ma=function(n,r,s){const i=se(n);return i.sa(),new Db(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(t.datastore,t.asyncQueue,{Zo:Ub.bind(null,t),Yo:Bb.bind(null,t),t_:$b.bind(null,t),H_:qb.bind(null,t)}),t.Ra.push(async e=>{e?(t.ma.B_(),Mf(t)?Df(t):t.Va.set("Unknown")):(await t.ma.stop(),k1(t))})),t.ma}function Kr(t){return t.fa||(t.fa=function(n,r,s){const i=se(n);return i.sa(),new Mb(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(t.datastore,t.asyncQueue,{Zo:()=>Promise.resolve(),Yo:Gb.bind(null,t),t_:Yb.bind(null,t),ta:Kb.bind(null,t),na:Qb.bind(null,t)}),t.Ra.push(async e=>{e?(t.fa.B_(),await tc(t)):(await t.fa.stop(),t.Ta.length>0&&(K(Vs,`Stopping write stream with ${t.Ta.length} pending writes`),t.Ta=[]))})),t.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lf{constructor(e,n,r,s,i){this.asyncQueue=e,this.timerId=n,this.targetTimeMs=r,this.op=s,this.removalCallback=i,this.deferred=new zr,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,n,r,s,i){const o=Date.now()+r,l=new Lf(e,n,o,s,i);return l.start(r),l}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new G(L.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function jf(t,e){if(nr("AsyncQueue",`${e}: ${t}`),Hi(t))return new G(L.UNAVAILABLE,`${e}: ${t}`);throw t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ti{static emptySet(e){return new Ti(e.comparator)}constructor(e){this.comparator=e?(n,r)=>e(n,r)||X.comparator(n.key,r.key):(n,r)=>X.comparator(n.key,r.key),this.keyedMap=Co(),this.sortedSet=new Le(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const n=this.keyedMap.get(e);return n?this.sortedSet.indexOf(n):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((n,r)=>(e(n),!1))}add(e){const n=this.delete(e.key);return n.copy(n.keyedMap.insert(e.key,e),n.sortedSet.insert(e,null))}delete(e){const n=this.get(e);return n?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(n)):this}isEqual(e){if(!(e instanceof Ti)||this.size!==e.size)return!1;const n=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;n.hasNext();){const s=n.getNext().key,i=r.getNext().key;if(!s.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(n=>{e.push(n.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,n){const r=new Ti;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=n,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Eg{constructor(){this.ga=new Le(X.comparator)}track(e){const n=e.doc.key,r=this.ga.get(n);r?e.type!==0&&r.type===3?this.ga=this.ga.insert(n,e):e.type===3&&r.type!==1?this.ga=this.ga.insert(n,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.ga=this.ga.insert(n,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.ga=this.ga.insert(n,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.ga=this.ga.remove(n):e.type===1&&r.type===2?this.ga=this.ga.insert(n,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.ga=this.ga.insert(n,{type:2,doc:e.doc}):ee(63341,{Vt:e,pa:r}):this.ga=this.ga.insert(n,e)}ya(){const e=[];return this.ga.inorderTraversal((n,r)=>{e.push(r)}),e}}class Oi{constructor(e,n,r,s,i,o,l,u,d){this.query=e,this.docs=n,this.oldDocs=r,this.docChanges=s,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=l,this.excludesMetadataChanges=u,this.hasCachedResults=d}static fromInitialDocuments(e,n,r,s,i){const o=[];return n.forEach(l=>{o.push({type:0,doc:l})}),new Oi(e,n,Ti.emptySet(n),o,r,s,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&Ku(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const n=this.docChanges,r=e.docChanges;if(n.length!==r.length)return!1;for(let s=0;s<n.length;s++)if(n[s].type!==r[s].type||!n[s].doc.isEqual(r[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jb{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class Zb{constructor(){this.queries=Tg(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(n,r){const s=se(n),i=s.queries;s.queries=Tg(),i.forEach((o,l)=>{for(const u of l.Sa)u.onError(r)})})(this,new G(L.ABORTED,"Firestore shutting down"))}}function Tg(){return new js(t=>Kv(t),Ku)}async function eS(t,e){const n=se(t);let r=3;const s=e.query;let i=n.queries.get(s);i?!i.ba()&&e.Da()&&(r=2):(i=new Jb,r=e.Da()?0:1);try{switch(r){case 0:i.wa=await n.onListen(s,!0);break;case 1:i.wa=await n.onListen(s,!1);break;case 2:await n.onFirstRemoteStoreListen(s)}}catch(o){const l=jf(o,`Initialization of query '${Zs(e.query)}' failed`);return void e.onError(l)}n.queries.set(s,i),i.Sa.push(e),e.va(n.onlineState),i.wa&&e.Fa(i.wa)&&Of(n)}async function tS(t,e){const n=se(t),r=e.query;let s=3;const i=n.queries.get(r);if(i){const o=i.Sa.indexOf(e);o>=0&&(i.Sa.splice(o,1),i.Sa.length===0?s=e.Da()?0:1:!i.ba()&&e.Da()&&(s=2))}switch(s){case 0:return n.queries.delete(r),n.onUnlisten(r,!0);case 1:return n.queries.delete(r),n.onUnlisten(r,!1);case 2:return n.onLastRemoteStoreUnlisten(r);default:return}}function nS(t,e){const n=se(t);let r=!1;for(const s of e){const i=s.query,o=n.queries.get(i);if(o){for(const l of o.Sa)l.Fa(s)&&(r=!0);o.wa=s}}r&&Of(n)}function rS(t,e,n){const r=se(t),s=r.queries.get(e);if(s)for(const i of s.Sa)i.onError(n);r.queries.delete(e)}function Of(t){t.Ca.forEach(e=>{e.next()})}var dh,bg;(bg=dh||(dh={})).Ma="default",bg.Cache="cache";class sS{constructor(e,n,r){this.query=e,this.xa=n,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=r||{}}Fa(e){if(!this.options.includeMetadataChanges){const r=[];for(const s of e.docChanges)s.type!==3&&r.push(s);e=new Oi(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let n=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),n=!0):this.La(e,this.onlineState)&&(this.ka(e),n=!0),this.Na=e,n}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let n=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),n=!0),n}La(e,n){if(!e.fromCache||!this.Da())return!0;const r=n!=="Offline";return(!this.options.qa||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||n==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const n=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!n)&&this.options.includeMetadataChanges===!0}ka(e){e=Oi.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==dh.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R1{constructor(e){this.key=e}}class P1{constructor(e){this.key=e}}class iS{constructor(e,n){this.query=e,this.Za=n,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=ue(),this.mutatedKeys=ue(),this.eu=Qv(e),this.tu=new Ti(this.eu)}get nu(){return this.Za}ru(e,n){const r=n?n.iu:new Eg,s=n?n.tu:this.tu;let i=n?n.mutatedKeys:this.mutatedKeys,o=s,l=!1;const u=this.query.limitType==="F"&&s.size===this.query.limit?s.last():null,d=this.query.limitType==="L"&&s.size===this.query.limit?s.first():null;if(e.inorderTraversal((f,m)=>{const v=s.get(f),I=Qu(this.query,m)?m:null,A=!!v&&this.mutatedKeys.has(v.key),P=!!I&&(I.hasLocalMutations||this.mutatedKeys.has(I.key)&&I.hasCommittedMutations);let M=!1;v&&I?v.data.isEqual(I.data)?A!==P&&(r.track({type:3,doc:I}),M=!0):this.su(v,I)||(r.track({type:2,doc:I}),M=!0,(u&&this.eu(I,u)>0||d&&this.eu(I,d)<0)&&(l=!0)):!v&&I?(r.track({type:0,doc:I}),M=!0):v&&!I&&(r.track({type:1,doc:v}),M=!0,(u||d)&&(l=!0)),M&&(I?(o=o.add(I),i=P?i.add(f):i.delete(f)):(o=o.delete(f),i=i.delete(f)))}),this.query.limit!==null)for(;o.size>this.query.limit;){const f=this.query.limitType==="F"?o.last():o.first();o=o.delete(f.key),i=i.delete(f.key),r.track({type:1,doc:f})}return{tu:o,iu:r,bs:l,mutatedKeys:i}}su(e,n){return e.hasLocalMutations&&n.hasCommittedMutations&&!n.hasLocalMutations}applyChanges(e,n,r,s){const i=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const o=e.iu.ya();o.sort((f,m)=>function(I,A){const P=M=>{switch(M){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ee(20277,{Vt:M})}};return P(I)-P(A)}(f.type,m.type)||this.eu(f.doc,m.doc)),this.ou(r),s=s??!1;const l=n&&!s?this._u():[],u=this.Ya.size===0&&this.current&&!s?1:0,d=u!==this.Xa;return this.Xa=u,o.length!==0||d?{snapshot:new Oi(this.query,e.tu,i,o,e.mutatedKeys,u===0,d,!1,!!r&&r.resumeToken.approximateByteSize()>0),au:l}:{au:l}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new Eg,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(n=>this.Za=this.Za.add(n)),e.modifiedDocuments.forEach(n=>{}),e.removedDocuments.forEach(n=>this.Za=this.Za.delete(n)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=ue(),this.tu.forEach(r=>{this.uu(r.key)&&(this.Ya=this.Ya.add(r.key))});const n=[];return e.forEach(r=>{this.Ya.has(r)||n.push(new P1(r))}),this.Ya.forEach(r=>{e.has(r)||n.push(new R1(r))}),n}cu(e){this.Za=e.ks,this.Ya=ue();const n=this.ru(e.documents);return this.applyChanges(n,!0)}lu(){return Oi.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Ff="SyncEngine";class oS{constructor(e,n,r){this.query=e,this.targetId=n,this.view=r}}class aS{constructor(e){this.key=e,this.hu=!1}}class lS{constructor(e,n,r,s,i,o){this.localStore=e,this.remoteStore=n,this.eventManager=r,this.sharedClientState=s,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.Pu={},this.Tu=new js(l=>Kv(l),Ku),this.Eu=new Map,this.Iu=new Set,this.Ru=new Le(X.comparator),this.Au=new Map,this.Vu=new Af,this.du={},this.mu=new Map,this.fu=ji.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function uS(t,e,n=!0){const r=j1(t);let s;const i=r.Tu.get(e);return i?(r.sharedClientState.addLocalQueryTarget(i.targetId),s=i.view.lu()):s=await N1(r,e,n,!0),s}async function cS(t,e){const n=j1(t);await N1(n,e,!0,!1)}async function N1(t,e,n,r){const s=await kb(t.localStore,Ln(e)),i=s.targetId,o=t.sharedClientState.addLocalQueryTarget(i,n);let l;return r&&(l=await dS(t,e,i,o==="current",s.resumeToken)),t.isPrimaryClient&&n&&b1(t.remoteStore,s),l}async function dS(t,e,n,r,s){t.pu=(m,v,I)=>async function(P,M,S,x){let k=M.view.ru(S);k.bs&&(k=await gg(P.localStore,M.query,!1).then(({documents:w})=>M.view.ru(w,k)));const V=x&&x.targetChanges.get(M.targetId),F=x&&x.targetMismatches.get(M.targetId)!=null,B=M.view.applyChanges(k,P.isPrimaryClient,V,F);return kg(P,M.targetId,B.au),B.snapshot}(t,m,v,I);const i=await gg(t.localStore,e,!0),o=new iS(e,i.ks),l=o.ru(i.documents),u=Aa.createSynthesizedTargetChangeForCurrentChange(n,r&&t.onlineState!=="Offline",s),d=o.applyChanges(l,t.isPrimaryClient,u);kg(t,n,d.au);const f=new oS(e,n,o);return t.Tu.set(e,f),t.Eu.has(n)?t.Eu.get(n).push(e):t.Eu.set(n,[e]),d.snapshot}async function hS(t,e,n){const r=se(t),s=r.Tu.get(e),i=r.Eu.get(s.targetId);if(i.length>1)return r.Eu.set(s.targetId,i.filter(o=>!Ku(o,e))),void r.Tu.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(s.targetId),r.sharedClientState.isActiveQueryTarget(s.targetId)||await uh(r.localStore,s.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(s.targetId),n&&Nf(r.remoteStore,s.targetId),hh(r,s.targetId)}).catch(qi)):(hh(r,s.targetId),await uh(r.localStore,s.targetId,!0))}async function fS(t,e){const n=se(t),r=n.Tu.get(e),s=n.Eu.get(r.targetId);n.isPrimaryClient&&s.length===1&&(n.sharedClientState.removeLocalQueryTarget(r.targetId),Nf(n.remoteStore,r.targetId))}async function pS(t,e,n){const r=xS(t);try{const s=await function(o,l){const u=se(o),d=Ie.now(),f=l.reduce((I,A)=>I.add(A.key),ue());let m,v;return u.persistence.runTransaction("Locally write mutations","readwrite",I=>{let A=rr(),P=ue();return u.xs.getEntries(I,f).next(M=>{A=M,A.forEach((S,x)=>{x.isValidDocument()||(P=P.add(S))})}).next(()=>u.localDocuments.getOverlayedDocuments(I,A)).next(M=>{m=M;const S=[];for(const x of l){const k=ST(x,m.get(x.key).overlayedDocument);k!=null&&S.push(new Os(x.key,k,Fv(k.value.mapValue),Yn.exists(!0)))}return u.mutationQueue.addMutationBatch(I,d,S,l)}).next(M=>{v=M;const S=M.applyToLocalDocumentSet(m,P);return u.documentOverlayCache.saveOverlays(I,M.batchId,S)})}).then(()=>({batchId:v.batchId,changes:Xv(m)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(s.batchId),function(o,l,u){let d=o.du[o.currentUser.toKey()];d||(d=new Le(le)),d=d.insert(l,u),o.du[o.currentUser.toKey()]=d}(r,s.batchId,n),await Ra(r,s.changes),await tc(r.remoteStore)}catch(s){const i=jf(s,"Failed to persist write");n.reject(i)}}async function V1(t,e){const n=se(t);try{const r=await Tb(n.localStore,e);e.targetChanges.forEach((s,i)=>{const o=n.Au.get(i);o&&(ye(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1,22616),s.addedDocuments.size>0?o.hu=!0:s.modifiedDocuments.size>0?ye(o.hu,14607):s.removedDocuments.size>0&&(ye(o.hu,42227),o.hu=!1))}),await Ra(n,r,e)}catch(r){await qi(r)}}function Sg(t,e,n){const r=se(t);if(r.isPrimaryClient&&n===0||!r.isPrimaryClient&&n===1){const s=[];r.Tu.forEach((i,o)=>{const l=o.view.va(e);l.snapshot&&s.push(l.snapshot)}),function(o,l){const u=se(o);u.onlineState=l;let d=!1;u.queries.forEach((f,m)=>{for(const v of m.Sa)v.va(l)&&(d=!0)}),d&&Of(u)}(r.eventManager,e),s.length&&r.Pu.H_(s),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function mS(t,e,n){const r=se(t);r.sharedClientState.updateQueryState(e,"rejected",n);const s=r.Au.get(e),i=s&&s.key;if(i){let o=new Le(X.comparator);o=o.insert(i,wt.newNoDocument(i,re.min()));const l=ue().add(i),u=new Ju(re.min(),new Map,new Le(le),o,l);await V1(r,u),r.Ru=r.Ru.remove(i),r.Au.delete(e),zf(r)}else await uh(r.localStore,e,!1).then(()=>hh(r,e,n)).catch(qi)}async function gS(t,e){const n=se(t),r=e.batch.batchId;try{const s=await Eb(n.localStore,e);M1(n,r,null),D1(n,r),n.sharedClientState.updateMutationState(r,"acknowledged"),await Ra(n,s)}catch(s){await qi(s)}}async function yS(t,e,n){const r=se(t);try{const s=await function(o,l){const u=se(o);return u.persistence.runTransaction("Reject batch","readwrite-primary",d=>{let f;return u.mutationQueue.lookupMutationBatch(d,l).next(m=>(ye(m!==null,37113),f=m.keys(),u.mutationQueue.removeMutationBatch(d,m))).next(()=>u.mutationQueue.performConsistencyCheck(d)).next(()=>u.documentOverlayCache.removeOverlaysForBatchId(d,f,l)).next(()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(d,f)).next(()=>u.localDocuments.getDocuments(d,f))})}(r.localStore,e);M1(r,e,n),D1(r,e),r.sharedClientState.updateMutationState(e,"rejected",n),await Ra(r,s)}catch(s){await qi(s)}}function D1(t,e){(t.mu.get(e)||[]).forEach(n=>{n.resolve()}),t.mu.delete(e)}function M1(t,e,n){const r=se(t);let s=r.du[r.currentUser.toKey()];if(s){const i=s.get(e);i&&(n?i.reject(n):i.resolve(),s=s.remove(e)),r.du[r.currentUser.toKey()]=s}}function hh(t,e,n=null){t.sharedClientState.removeLocalQueryTarget(e);for(const r of t.Eu.get(e))t.Tu.delete(r),n&&t.Pu.yu(r,n);t.Eu.delete(e),t.isPrimaryClient&&t.Vu.Gr(e).forEach(r=>{t.Vu.containsKey(r)||L1(t,r)})}function L1(t,e){t.Iu.delete(e.path.canonicalString());const n=t.Ru.get(e);n!==null&&(Nf(t.remoteStore,n),t.Ru=t.Ru.remove(e),t.Au.delete(n),zf(t))}function kg(t,e,n){for(const r of n)r instanceof R1?(t.Vu.addReference(r.key,e),vS(t,r)):r instanceof P1?(K(Ff,"Document no longer in limbo: "+r.key),t.Vu.removeReference(r.key,e),t.Vu.containsKey(r.key)||L1(t,r.key)):ee(19791,{wu:r})}function vS(t,e){const n=e.key,r=n.path.canonicalString();t.Ru.get(n)||t.Iu.has(r)||(K(Ff,"New document in limbo: "+n),t.Iu.add(r),zf(t))}function zf(t){for(;t.Iu.size>0&&t.Ru.size<t.maxConcurrentLimboResolutions;){const e=t.Iu.values().next().value;t.Iu.delete(e);const n=new X(xe.fromString(e)),r=t.fu.next();t.Au.set(r,new aS(n)),t.Ru=t.Ru.insert(n,r),b1(t.remoteStore,new Ar(Ln(Wv(n.path)),r,"TargetPurposeLimboResolution",Hu.ce))}}async function Ra(t,e,n){const r=se(t),s=[],i=[],o=[];r.Tu.isEmpty()||(r.Tu.forEach((l,u)=>{o.push(r.pu(u,e,n).then(d=>{var f;if((d||n)&&r.isPrimaryClient){const m=d?!d.fromCache:(f=n==null?void 0:n.targetChanges.get(u.targetId))==null?void 0:f.current;r.sharedClientState.updateQueryState(u.targetId,m?"current":"not-current")}if(d){s.push(d);const m=Rf.Is(u.targetId,d);i.push(m)}}))}),await Promise.all(o),r.Pu.H_(s),await async function(u,d){const f=se(u);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>j.forEach(d,v=>j.forEach(v.Ts,I=>f.persistence.referenceDelegate.addReference(m,v.targetId,I)).next(()=>j.forEach(v.Es,I=>f.persistence.referenceDelegate.removeReference(m,v.targetId,I)))))}catch(m){if(!Hi(m))throw m;K(Pf,"Failed to update sequence numbers: "+m)}for(const m of d){const v=m.targetId;if(!m.fromCache){const I=f.vs.get(v),A=I.snapshotVersion,P=I.withLastLimboFreeSnapshotVersion(A);f.vs=f.vs.insert(v,P)}}}(r.localStore,i))}async function _S(t,e){const n=se(t);if(!n.currentUser.isEqual(e)){K(Ff,"User change. New user:",e.toKey());const r=await w1(n.localStore,e);n.currentUser=e,function(i,o){i.mu.forEach(l=>{l.forEach(u=>{u.reject(new G(L.CANCELLED,o))})}),i.mu.clear()}(n,"'waitForPendingWrites' promise is rejected due to a user change."),n.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await Ra(n,r.Ns)}}function wS(t,e){const n=se(t),r=n.Au.get(e);if(r&&r.hu)return ue().add(r.key);{let s=ue();const i=n.Eu.get(e);if(!i)return s;for(const o of i){const l=n.Tu.get(o);s=s.unionWith(l.view.nu)}return s}}function j1(t){const e=se(t);return e.remoteStore.remoteSyncer.applyRemoteEvent=V1.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=wS.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=mS.bind(null,e),e.Pu.H_=nS.bind(null,e.eventManager),e.Pu.yu=rS.bind(null,e.eventManager),e}function xS(t){const e=se(t);return e.remoteStore.remoteSyncer.applySuccessfulWrite=gS.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=yS.bind(null,e),e}class Eu{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Zu(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,n){return null}Mu(e,n){return null}vu(e){return xb(this.persistence,new vb,e.initialUser,this.serializer)}Cu(e){return new _1(Cf.Vi,this.serializer)}Du(e){return new Ab}async terminate(){var e,n;(e=this.gcScheduler)==null||e.stop(),(n=this.indexBackfillerScheduler)==null||n.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Eu.provider={build:()=>new Eu};class ES extends Eu{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,n){ye(this.persistence.referenceDelegate instanceof wu,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new rb(r,e.asyncQueue,n)}Cu(e){const n=this.cacheSizeBytes!==void 0?Pt.withCacheSize(this.cacheSizeBytes):Pt.DEFAULT;return new _1(r=>wu.Vi(r,n),this.serializer)}}class fh{async initialize(e,n){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(n),this.remoteStore=this.createRemoteStore(n),this.eventManager=this.createEventManager(n),this.syncEngine=this.createSyncEngine(n,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>Sg(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=_S.bind(null,this.syncEngine),await Xb(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new Zb}()}createDatastore(e){const n=Zu(e.databaseInfo.databaseId),r=Vb(e.databaseInfo);return Ob(e.authCredentials,e.appCheckCredentials,r,n)}createRemoteStore(e){return function(r,s,i,o,l){return new zb(r,s,i,o,l)}(this.localStore,this.datastore,e.asyncQueue,n=>Sg(this.syncEngine,n,0),function(){return _g.v()?new _g:new Cb}())}createSyncEngine(e,n){return function(s,i,o,l,u,d,f){const m=new lS(s,i,o,l,u,d);return f&&(m.gu=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,n)}async terminate(){var e,n;await async function(s){const i=se(s);K(Vs,"RemoteStore shutting down."),i.Ia.add(5),await Ca(i),i.Aa.shutdown(),i.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(n=this.eventManager)==null||n.terminate()}}fh.provider={build:()=>new fh};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TS{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):nr("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,n){setTimeout(()=>{this.muted||e(n)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qr="FirestoreClient";class bS{constructor(e,n,r,s,i){this.authCredentials=e,this.appCheckCredentials=n,this.asyncQueue=r,this._databaseInfo=s,this.user=vt.UNAUTHENTICATED,this.clientId=vf.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(r,async o=>{K(Qr,"Received user=",o.uid),await this.authCredentialListener(o),this.user=o}),this.appCheckCredentials.start(r,o=>(K(Qr,"Received new app check token=",o),this.appCheckCredentialListener(o,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new zr;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(n){const r=jf(n,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function Xc(t,e){t.asyncQueue.verifyOperationInProgress(),K(Qr,"Initializing OfflineComponentProvider");const n=t.configuration;await e.initialize(n);let r=n.initialUser;t.setCredentialChangeListener(async s=>{r.isEqual(s)||(await w1(e.localStore,s),r=s)}),e.persistence.setDatabaseDeletedListener(()=>t.terminate()),t._offlineComponents=e}async function Ig(t,e){t.asyncQueue.verifyOperationInProgress();const n=await SS(t);K(Qr,"Initializing OnlineComponentProvider"),await e.initialize(n,t.configuration),t.setCredentialChangeListener(r=>xg(e.remoteStore,r)),t.setAppCheckTokenChangeListener((r,s)=>xg(e.remoteStore,s)),t._onlineComponents=e}async function SS(t){if(!t._offlineComponents)if(t._uninitializedComponentsProvider){K(Qr,"Using user provided OfflineComponentProvider");try{await Xc(t,t._uninitializedComponentsProvider._offline)}catch(e){const n=e;if(!function(s){return s.name==="FirebaseError"?s.code===L.FAILED_PRECONDITION||s.code===L.UNIMPLEMENTED:!(typeof DOMException<"u"&&s instanceof DOMException)||s.code===22||s.code===20||s.code===11}(n))throw n;Ns("Error using user provided cache. Falling back to memory cache: "+n),await Xc(t,new Eu)}}else K(Qr,"Using default OfflineComponentProvider"),await Xc(t,new ES(void 0));return t._offlineComponents}async function O1(t){return t._onlineComponents||(t._uninitializedComponentsProvider?(K(Qr,"Using user provided OnlineComponentProvider"),await Ig(t,t._uninitializedComponentsProvider._online)):(K(Qr,"Using default OnlineComponentProvider"),await Ig(t,new fh))),t._onlineComponents}function kS(t){return O1(t).then(e=>e.syncEngine)}async function IS(t){const e=await O1(t),n=e.eventManager;return n.onListen=uS.bind(null,e.syncEngine),n.onUnlisten=hS.bind(null,e.syncEngine),n.onFirstRemoteStoreListen=cS.bind(null,e.syncEngine),n.onLastRemoteStoreUnlisten=fS.bind(null,e.syncEngine),n}function AS(t,e,n={}){const r=new zr;return t.asyncQueue.enqueueAndForget(async()=>function(i,o,l,u,d){const f=new TS({next:v=>{f.Nu(),o.enqueueAndForget(()=>tS(i,m)),v.fromCache&&u.source==="server"?d.reject(new G(L.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):d.resolve(v)},error:v=>d.reject(v)}),m=new sS(l,f,{includeMetadataChanges:!0,qa:!0});return eS(i,m)}(await IS(t),t.asyncQueue,e,n,r)),r.promise}function CS(t,e){const n=new zr;return t.asyncQueue.enqueueAndForget(async()=>pS(await kS(t),e,n)),n.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function F1(t){const e={};return t.timeoutSeconds!==void 0&&(e.timeoutSeconds=t.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const RS="ComponentProvider",Ag=new Map;function PS(t,e,n,r,s){return new WE(t,e,n,s.host,s.ssl,s.experimentalForceLongPolling,s.experimentalAutoDetectLongPolling,F1(s.experimentalLongPollingOptions),s.useFetchStreams,s.isUsingEmulator,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const z1="firestore.googleapis.com",Cg=!0;class Rg{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new G(L.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=z1,this.ssl=Cg}else this.host=e.host,this.ssl=e.ssl??Cg;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=v1;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<tb)throw new G(L.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}DE("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=F1(e.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new G(L.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new G(L.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new G(L.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,s){return r.timeoutSeconds===s.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class nc{constructor(e,n,r,s){this._authCredentials=e,this._appCheckCredentials=n,this._databaseId=r,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Rg({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new G(L.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new G(L.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Rg(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new bE;switch(r.type){case"firstParty":return new AE(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new G(L.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(n){const r=Ag.get(n);r&&(K(RS,"Removing Datastore"),Ag.delete(n),r.terminate())}(this),Promise.resolve()}}function NS(t,e,n,r={}){var d;t=hu(t,nc);const s=fv(e),i=t._getSettings(),o={...i,emulatorOptions:t._getEmulatorOptions()},l=`${e}:${n}`;s&&l2(`https://${l}`),i.host!==z1&&i.host!==l&&Ns("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...i,host:l,ssl:s,emulatorOptions:r};if(!cu(u,o)&&(t._setSettings(u),r.mockUserToken)){let f,m;if(typeof r.mockUserToken=="string")f=r.mockUserToken,m=vt.MOCK_USER;else{f=Zx(r.mockUserToken,(d=t._app)==null?void 0:d.options.projectId);const v=r.mockUserToken.sub||r.mockUserToken.user_id;if(!v)throw new G(L.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new vt(v)}t._authCredentials=new SE(new Iv(f,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zr{constructor(e,n,r){this.converter=n,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new Zr(this.firestore,e,this._query)}}class at{constructor(e,n,r){this.converter=n,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Ur(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new at(this.firestore,e,this._key)}toJSON(){return{type:at._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,n,r){if(ka(n,at._jsonSchema))return new at(e,r||null,new X(xe.fromString(n.referencePath)))}}at._jsonSchemaVersion="firestore/documentReference/1.0",at._jsonSchema={type:Ke("string",at._jsonSchemaVersion),referencePath:Ke("string")};class Ur extends Zr{constructor(e,n,r){super(e,n,Wv(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new at(this.firestore,null,new X(e))}withConverter(e){return new Ur(this.firestore,e,this._path)}}function rc(t,e,...n){if(t=Vi(t),Av("collection","path",e),t instanceof nc){const r=xe.fromString(e,...n);return $m(r),new Ur(t,null,r)}{if(!(t instanceof at||t instanceof Ur))throw new G(L.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=t._path.child(xe.fromString(e,...n));return $m(r),new Ur(t.firestore,null,r)}}function VS(t,e,...n){if(t=Vi(t),arguments.length===1&&(e=vf.newId()),Av("doc","path",e),t instanceof nc){const r=xe.fromString(e,...n);return Bm(r),new at(t,null,new X(r))}{if(!(t instanceof at||t instanceof Ur))throw new G(L.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=t._path.child(xe.fromString(e,...n));return Bm(r),new at(t.firestore,t instanceof Ur?t.converter:null,new X(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pg="AsyncQueue";class Ng{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new E1(this,"async_queue_retry"),this._c=()=>{const r=Yc();r&&K(Pg,"Visibility state changed to "+r.visibilityState),this.M_.w_()},this.ac=e;const n=Yc();n&&typeof n.addEventListener=="function"&&n.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const n=Yc();n&&typeof n.removeEventListener=="function"&&n.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const n=new zr;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(n.resolve,n.reject),n.promise)).then(()=>n.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!Hi(e))throw e;K(Pg,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const n=this.ac.then(()=>(this.rc=!0,e().catch(r=>{throw this.nc=r,this.rc=!1,nr("INTERNAL UNHANDLED ERROR: ",Vg(r)),r}).then(r=>(this.rc=!1,r))));return this.ac=n,n}enqueueAfterDelay(e,n,r){this.uc(),this.oc.indexOf(e)>-1&&(n=0);const s=Lf.createAndSchedule(this,e,n,r,i=>this.hc(i));return this.tc.push(s),s}uc(){this.nc&&ee(47125,{Pc:Vg(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const n of this.tc)if(n.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((n,r)=>n.targetTimeMs-r.targetTimeMs);for(const n of this.tc)if(n.skipDelay(),e!=="all"&&n.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const n=this.tc.indexOf(e);this.tc.splice(n,1)}}function Vg(t){let e=t.message||"";return t.stack&&(e=t.stack.includes(t.message)?t.stack:t.message+`
`+t.stack),e}class Uf extends nc{constructor(e,n,r,s){super(e,n,r,s),this.type="firestore",this._queue=new Ng,this._persistenceKey=(s==null?void 0:s.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Ng(e),this._firestoreClient=void 0,await e}}}function DS(t,e){const n=typeof t=="object"?t:cE(),r=typeof t=="string"?t:pu,s=iE(n,"firestore").getImmediate({identifier:r});if(!s._initialized){const i=Xx("firestore");i&&NS(s,...i)}return s}function U1(t){if(t._terminated)throw new G(L.FAILED_PRECONDITION,"The client has already been terminated.");return t._firestoreClient||MS(t),t._firestoreClient}function MS(t){var r,s,i,o;const e=t._freezeSettings(),n=PS(t._databaseId,((r=t._app)==null?void 0:r.options.appId)||"",t._persistenceKey,(s=t._app)==null?void 0:s.options.apiKey,e);t._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((o=e.localCache)!=null&&o._onlineComponentProvider)&&(t._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),t._firestoreClient=new bS(t._authCredentials,t._appCheckCredentials,t._queue,n,t._componentsProvider&&function(u){const d=u==null?void 0:u._online.build();return{_offline:u==null?void 0:u._offline.build(d),_online:d}}(t._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nn{constructor(e){this._byteString=e}static fromBase64String(e){try{return new nn(pt.fromBase64String(e))}catch(n){throw new G(L.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+n)}}static fromUint8Array(e){return new nn(pt.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:nn._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(ka(e,nn._jsonSchema))return nn.fromBase64String(e.bytes)}}nn._jsonSchemaVersion="firestore/bytes/1.0",nn._jsonSchema={type:Ke("string",nn._jsonSchemaVersion),bytes:Ke("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B1{constructor(...e){for(let n=0;n<e.length;++n)if(e[n].length===0)throw new G(L.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new dt(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bf{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class On{constructor(e,n){if(!isFinite(e)||e<-90||e>90)throw new G(L.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(n)||n<-180||n>180)throw new G(L.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+n);this._lat=e,this._long=n}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return le(this._lat,e._lat)||le(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:On._jsonSchemaVersion}}static fromJSON(e){if(ka(e,On._jsonSchema))return new On(e.latitude,e.longitude)}}On._jsonSchemaVersion="firestore/geoPoint/1.0",On._jsonSchema={type:Ke("string",On._jsonSchemaVersion),latitude:Ke("number"),longitude:Ke("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class En{constructor(e){this._values=(e||[]).map(n=>n)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(r,s){if(r.length!==s.length)return!1;for(let i=0;i<r.length;++i)if(r[i]!==s[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:En._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(ka(e,En._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(n=>typeof n=="number"))return new En(e.vectorValues);throw new G(L.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}En._jsonSchemaVersion="firestore/vectorValue/1.0",En._jsonSchema={type:Ke("string",En._jsonSchemaVersion),vectorValues:Ke("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const LS=/^__.*__$/;class jS{constructor(e,n,r){this.data=e,this.fieldMask=n,this.fieldTransforms=r}toMutation(e,n){return this.fieldMask!==null?new Os(e,this.data,this.fieldMask,n,this.fieldTransforms):new Ia(e,this.data,n,this.fieldTransforms)}}function $1(t){switch(t){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ee(40011,{dataSource:t})}}class $f{constructor(e,n,r,s,i,o){this.settings=e,this.databaseId=n,this.serializer=r,this.ignoreUndefinedProperties=s,i===void 0&&this.Ac(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new $f({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var s;const n=(s=this.path)==null?void 0:s.child(e),r=this.i({path:n,arrayElement:!1});return r.mc(e),r}fc(e){var s;const n=(s=this.path)==null?void 0:s.child(e),r=this.i({path:n,arrayElement:!1});return r.Ac(),r}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Tu(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(n=>e.isPrefixOf(n))!==void 0||this.fieldTransforms.find(n=>e.isPrefixOf(n.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if($1(this.dataSource)&&LS.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class OS{constructor(e,n,r){this.databaseId=e,this.ignoreUndefinedProperties=n,this.serializer=r||Zu(e)}I(e,n,r,s=!1){return new $f({dataSource:e,methodName:n,targetDoc:r,path:dt.emptyPath(),arrayElement:!1,hasConverter:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function q1(t){const e=t._freezeSettings(),n=Zu(t._databaseId);return new OS(t._databaseId,!!e.ignoreUndefinedProperties,n)}function FS(t,e,n,r,s,i={}){const o=t.I(i.merge||i.mergeFields?2:0,e,n,s);G1("Data must be an object, but it was:",o,r);const l=H1(r,o);let u,d;if(i.merge)u=new _n(o.fieldMask),d=o.fieldTransforms;else if(i.mergeFields){const f=[];for(const m of i.mergeFields){const v=sc(e,m,n);if(!o.contains(v))throw new G(L.INVALID_ARGUMENT,`Field '${v}' is specified in your field mask but missing from your input data.`);$S(f,v)||f.push(v)}u=new _n(f),d=o.fieldTransforms.filter(m=>u.covers(m.field))}else u=null,d=o.fieldTransforms;return new jS(new tn(l),u,d)}class qf extends Bf{_toFieldTransform(e){return new xT(e.path,new ya)}isEqual(e){return e instanceof qf}}function zS(t,e,n,r=!1){return Hf(n,t.I(r?4:3,e))}function Hf(t,e){if(W1(t=Vi(t)))return G1("Unsupported field value:",e,t),H1(t,e);if(t instanceof Bf)return function(r,s){if(!$1(s.dataSource))throw s.yc(`${r._methodName}() can only be used with update() and set()`);if(!s.path)throw s.yc(`${r._methodName}() is not currently supported inside arrays`);const i=r._toFieldTransform(s);i&&s.fieldTransforms.push(i)}(t,e),null;if(t===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),t instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(r,s){const i=[];let o=0;for(const l of r){let u=Hf(l,s.gc(o));u==null&&(u={nullValue:"NULL_VALUE"}),i.push(u),o++}return{arrayValue:{values:i}}}(t,e)}return function(r,s){if((r=Vi(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return vT(s.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const i=Ie.fromDate(r);return{timestampValue:_u(s.serializer,i)}}if(r instanceof Ie){const i=new Ie(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:_u(s.serializer,i)}}if(r instanceof On)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof nn)return{bytesValue:c1(s.serializer,r._byteString)};if(r instanceof at){const i=s.databaseId,o=r.firestore._databaseId;if(!o.isEqual(i))throw s.yc(`Document reference is for database ${o.projectId}/${o.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:If(r.firestore._databaseId||s.databaseId,r._key.path)}}if(r instanceof En)return function(o,l){const u=o instanceof En?o.toArray():o;return{mapValue:{fields:{[jv]:{stringValue:Ov},[mu]:{arrayValue:{values:u.map(f=>{if(typeof f!="number")throw l.yc("VectorValues must only contain numeric values.");return bf(l.serializer,f)})}}}}}}(r,s);if(y1(r))return r._toProto(s.serializer);throw s.yc(`Unsupported field value: ${qu(r)}`)}(t,e)}function H1(t,e){const n={};return Pv(t)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Ls(t,(r,s)=>{const i=Hf(s,e.dc(r));i!=null&&(n[r]=i)}),{mapValue:{fields:n}}}function W1(t){return!(typeof t!="object"||t===null||t instanceof Array||t instanceof Date||t instanceof Ie||t instanceof On||t instanceof nn||t instanceof at||t instanceof Bf||t instanceof En||y1(t))}function G1(t,e,n){if(!W1(n)||!Cv(n)){const r=qu(n);throw r==="an object"?e.yc(t+" a custom object"):e.yc(t+" "+r)}}function sc(t,e,n){if((e=Vi(e))instanceof B1)return e._internalPath;if(typeof e=="string")return BS(t,e);throw Tu("Field path arguments must be of type string or ",t,!1,void 0,n)}const US=new RegExp("[~\\*/\\[\\]]");function BS(t,e,n){if(e.search(US)>=0)throw Tu(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,t,!1,void 0,n);try{return new B1(...e.split("."))._internalPath}catch{throw Tu(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,t,!1,void 0,n)}}function Tu(t,e,n,r,s){const i=r&&!r.isEmpty(),o=s!==void 0;let l=`Function ${e}() called with invalid data`;n&&(l+=" (via `toFirestore()`)"),l+=". ";let u="";return(i||o)&&(u+=" (found",i&&(u+=` in field ${r}`),o&&(u+=` in document ${s}`),u+=")"),new G(L.INVALID_ARGUMENT,l+t+u)}function $S(t,e){return t.some(n=>n.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qS{convertValue(e,n="none"){switch(Gr(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Be(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,n);case 5:return e.stringValue;case 6:return this.convertBytes(Wr(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,n);case 11:return this.convertObject(e.mapValue,n);case 10:return this.convertVectorValue(e.mapValue);default:throw ee(62114,{value:e})}}convertObject(e,n){return this.convertObjectMap(e.fields,n)}convertObjectMap(e,n="none"){const r={};return Ls(e,(s,i)=>{r[s]=this.convertValue(i,n)}),r}convertVectorValue(e){var r,s,i;const n=(i=(s=(r=e.fields)==null?void 0:r[mu].arrayValue)==null?void 0:s.values)==null?void 0:i.map(o=>Be(o.doubleValue));return new En(n)}convertGeoPoint(e){return new On(Be(e.latitude),Be(e.longitude))}convertArray(e,n){return(e.values||[]).map(r=>this.convertValue(r,n))}convertServerTimestamp(e,n){switch(n){case"previous":const r=Gu(e);return r==null?null:this.convertValue(r,n);case"estimate":return this.convertTimestamp(fa(e));default:return null}}convertTimestamp(e){const n=Hr(e);return new Ie(n.seconds,n.nanos)}convertDocumentKey(e,n){const r=xe.fromString(e);ye(g1(r),9688,{name:e});const s=new pa(r.get(1),r.get(3)),i=new X(r.popFirst(5));return s.isEqual(n)||nr(`Document ${i} contains a document reference within a different database (${s.projectId}/${s.database}) which is not supported. It will be treated as a reference in the current database (${n.projectId}/${n.database}) instead.`),i}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HS extends qS{constructor(e){super(),this.firestore=e}convertBytes(e){return new nn(e)}convertReference(e){const n=this.convertDocumentKey(e,this.firestore._databaseId);return new at(this.firestore,null,n)}}function K1(){return new qf("serverTimestamp")}const Dg="@firebase/firestore",Mg="4.14.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q1{constructor(e,n,r,s,i){this._firestore=e,this._userDataWriter=n,this._key=r,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new at(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new WS(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const n=this._document.data.field(sc("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n)}}}class WS extends Q1{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function GS(t){if(t.limitType==="L"&&t.explicitOrderBy.length===0)throw new G(L.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Wf{}class Gf extends Wf{}function Kf(t,e,...n){let r=[];e instanceof Wf&&r.push(e),r=r.concat(n),function(i){const o=i.filter(u=>u instanceof Yf).length,l=i.filter(u=>u instanceof Qf).length;if(o>1||o>0&&l>0)throw new G(L.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(r);for(const s of r)t=s._apply(t);return t}class Qf extends Gf{constructor(e,n,r){super(),this._field=e,this._op=n,this._value=r,this.type="where"}static _create(e,n,r){return new Qf(e,n,r)}_apply(e){const n=this._parse(e);return Y1(e._query,n),new Zr(e.firestore,e.converter,sh(e._query,n))}_parse(e){const n=q1(e.firestore);return function(i,o,l,u,d,f,m){let v;if(d.isKeyField()){if(f==="array-contains"||f==="array-contains-any")throw new G(L.INVALID_ARGUMENT,`Invalid Query. You can't perform '${f}' queries on documentId().`);if(f==="in"||f==="not-in"){jg(m,f);const A=[];for(const P of m)A.push(Lg(u,i,P));v={arrayValue:{values:A}}}else v=Lg(u,i,m)}else f!=="in"&&f!=="not-in"&&f!=="array-contains-any"||jg(m,f),v=zS(l,o,m,f==="in"||f==="not-in");return Ge.create(d,f,v)}(e._query,"where",n,e.firestore._databaseId,this._field,this._op,this._value)}}class Yf extends Wf{constructor(e,n){super(),this.type=e,this._queryConstraints=n}static _create(e,n){return new Yf(e,n)}_parse(e){const n=this._queryConstraints.map(r=>r._parse(e)).filter(r=>r.getFilters().length>0);return n.length===1?n[0]:bn.create(n,this._getOperator())}_apply(e){const n=this._parse(e);return n.getFilters().length===0?e:(function(s,i){let o=s;const l=i.getFlattenedFilters();for(const u of l)Y1(o,u),o=sh(o,u)}(e._query,n),new Zr(e.firestore,e.converter,sh(e._query,n)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Xf extends Gf{constructor(e,n){super(),this._field=e,this._direction=n,this.type="orderBy"}static _create(e,n){return new Xf(e,n)}_apply(e){const n=function(s,i,o){if(s.startAt!==null)throw new G(L.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(s.endAt!==null)throw new G(L.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new ga(i,o)}(e._query,this._field,this._direction);return new Zr(e.firestore,e.converter,cT(e._query,n))}}function Jf(t,e="asc"){const n=e,r=sc("orderBy",t);return Xf._create(r,n)}class Zf extends Gf{constructor(e,n,r){super(),this.type=e,this._limit=n,this._limitType=r}static _create(e,n,r){return new Zf(e,n,r)}_apply(e){return new Zr(e.firestore,e.converter,yu(e._query,this._limit,this._limitType))}}function ep(t){return ME("limit",t),Zf._create("limit",t,"F")}function Lg(t,e,n){if(typeof(n=Vi(n))=="string"){if(n==="")throw new G(L.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Gv(e)&&n.indexOf("/")!==-1)throw new G(L.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${n}' contains a '/' character.`);const r=e.path.child(xe.fromString(n));if(!X.isDocumentKey(r))throw new G(L.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return Xm(t,new X(r))}if(n instanceof at)return Xm(t,n._key);throw new G(L.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${qu(n)}.`)}function jg(t,e){if(!Array.isArray(t)||t.length===0)throw new G(L.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Y1(t,e){const n=function(s,i){for(const o of s)for(const l of o.getFlattenedFilters())if(i.indexOf(l.op)>=0)return l.op;return null}(t.filters,function(s){switch(s){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(n!==null)throw n===e.op?new G(L.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new G(L.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${n.toString()}' filters.`)}function KS(t,e,n){let r;return r=t?t.toFirestore(e):e,r}class yl{constructor(e,n){this.hasPendingWrites=e,this.fromCache=n}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class bi extends Q1{constructor(e,n,r,s,i,o){super(e,n,r,s,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const n=new Ol(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(n,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,n={}){if(this._document){const r=this._document.data.field(sc("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,n.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new G(L.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,n={};return n.type=bi._jsonSchemaVersion,n.bundle="",n.bundleSource="DocumentSnapshot",n.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?n:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),n.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),n)}}bi._jsonSchemaVersion="firestore/documentSnapshot/1.0",bi._jsonSchema={type:Ke("string",bi._jsonSchemaVersion),bundleSource:Ke("string","DocumentSnapshot"),bundleName:Ke("string"),bundle:Ke("string")};class Ol extends bi{data(e={}){return super.data(e)}}class Si{constructor(e,n,r,s){this._firestore=e,this._userDataWriter=n,this._snapshot=s,this.metadata=new yl(s.hasPendingWrites,s.fromCache),this.query=r}get docs(){const e=[];return this.forEach(n=>e.push(n)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,n){this._snapshot.docs.forEach(r=>{e.call(n,new Ol(this._firestore,this._userDataWriter,r.key,r,new yl(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const n=!!e.includeMetadataChanges;if(n&&this._snapshot.excludesMetadataChanges)throw new G(L.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===n||(this._cachedChanges=function(s,i){if(s._snapshot.oldDocs.isEmpty()){let o=0;return s._snapshot.docChanges.map(l=>{const u=new Ol(s._firestore,s._userDataWriter,l.doc.key,l.doc,new yl(s._snapshot.mutatedKeys.has(l.doc.key),s._snapshot.fromCache),s.query.converter);return l.doc,{type:"added",doc:u,oldIndex:-1,newIndex:o++}})}{let o=s._snapshot.oldDocs;return s._snapshot.docChanges.filter(l=>i||l.type!==3).map(l=>{const u=new Ol(s._firestore,s._userDataWriter,l.doc.key,l.doc,new yl(s._snapshot.mutatedKeys.has(l.doc.key),s._snapshot.fromCache),s.query.converter);let d=-1,f=-1;return l.type!==0&&(d=o.indexOf(l.doc.key),o=o.delete(l.doc.key)),l.type!==1&&(o=o.add(l.doc),f=o.indexOf(l.doc.key)),{type:QS(l.type),doc:u,oldIndex:d,newIndex:f}})}}(this,n),this._cachedChangesIncludeMetadataChanges=n),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new G(L.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=Si._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=vf.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const n=[],r=[],s=[];return this.docs.forEach(i=>{i._document!==null&&(n.push(i._document),r.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),s.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function QS(t){switch(t){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return ee(61501,{type:t})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Si._jsonSchemaVersion="firestore/querySnapshot/1.0",Si._jsonSchema={type:Ke("string",Si._jsonSchemaVersion),bundleSource:Ke("string","QuerySnapshot"),bundleName:Ke("string"),bundle:Ke("string")};function X1(t){t=hu(t,Zr);const e=hu(t.firestore,Uf),n=U1(e),r=new HS(e);return GS(t._query),AS(n,t._query).then(s=>new Si(e,r,t,s))}function J1(t,e){const n=hu(t.firestore,Uf),r=VS(t),s=KS(t.converter,e),i=q1(t.firestore);return YS(n,[FS(i,"addDoc",r._key,s,t.converter!==null,{}).toMutation(r._key,Yn.exists(!1))]).then(()=>r)}function YS(t,e){const n=U1(t);return CS(n,e)}(function(e,n=!0){TE(uE),du(new ua("firestore",(r,{instanceIdentifier:s,options:i})=>{const o=r.getProvider("app").getImmediate(),l=new Uf(new kE(r.getProvider("auth-internal")),new CE(o,r.getProvider("app-check-internal")),GE(o,s),o);return i={useFetchStreams:n,...i},l._setSettings(i),l},"PUBLIC").setMultipleInstances(!0)),xi(Dg,Mg,e),xi(Dg,Mg,"esm2020")})();const XS={apiKey:"AIzaSyDGUxT4nhAPYsxzmOAESKsFgkd4jhUif4o",authDomain:"dont-touch-purple.firebaseapp.com",projectId:"dont-touch-purple",storageBucket:"dont-touch-purple.firebasestorage.app",messagingSenderId:"46782482111",appId:"1:46782482111:web:a47a1b9afc5feba4eaa80a",measurementId:"G-QVXYQ7C2WN"};let vl=null;function ic(){try{if(vl)return vl;const t=Mm().length?Mm()[0]:yv(XS);return vl=DS(t),vl}catch(t){return console.warn("[DTP-Firebase] Firestore init failed:",t),null}}async function JS(t){const e=ic();e&&await J1(rc(e,"lb_global"),{...t,ts:K1()})}async function ZS(){const t=ic();if(!t)throw new Error("no db");const e=Kf(rc(t,"lb_global"),Jf("score","desc"),ep(20));return(await X1(e)).docs.map(r=>{const s=r.data();return{score:s.score??0,initials:s.initials??"???",date:s.date??"",mode:s.mode??"classic"}})}async function ek(t,e){const n=ic();if(!n)return;const r=rc(n,"dust_wallet");Kf(r,Jf("name"),ep(50)),await J1(r,{name:t,dust:e,ts:K1()})}async function tk(t){const e=ic();if(!e)return 0;try{const n=new Date(Date.now()-6048e5).toLocaleDateString(),r=Kf(rc(e,"lb_global"),Jf("score","desc"),ep(50));return(await X1(r)).docs.map(u=>u.data()).filter(u=>u.date>=n).slice(0,3).some(u=>u.initials===t)?500:0}catch{return 0}}const bu=2e3,Z1=380,nk=.96,rk=5,tp=5,sk=12,Og="dtp-keys-p1",Fg="dtp-keys-p2",e_="dtp-lb-classic",t_="dtp-lb-evolve",zg="dtp-privacy-ok",To="dtp-player-name",n_="dtp-dust",r_="dtp-energy-data",s_="dtp-shop",Ug="dtp-weekly-bonus",i_="dtp-stored-pwr",Fn=5,Su=15*60*1e3,pi=50,ph=[{id:"default",name:"Default",cost:0,colors:{bg:"#0d0820",purple:"#c026d3",accent:"#f0abfc",text:"#f0eaff"}},{id:"neon",name:"Neon",cost:800,colors:{bg:"#001a1a",purple:"#00ffe0",accent:"#00ffa0",text:"#e0fff8"}},{id:"midnight",name:"Midnight",cost:600,colors:{bg:"#060614",purple:"#818cf8",accent:"#c7d2fe",text:"#e0e7ff"}},{id:"pastel",name:"Pastel",cost:700,colors:{bg:"#fdf0ff",purple:"#c084fc",accent:"#f9a8d4",text:"#3b0764"}},{id:"blood",name:"Blood",cost:900,colors:{bg:"#0f0000",purple:"#ef4444",accent:"#fca5a5",text:"#fff0f0"}},{id:"ocean",name:"Ocean",cost:750,colors:{bg:"#000c1a",purple:"#0ea5e9",accent:"#7dd3fc",text:"#e0f7ff"}}],ik=[{id:"freeze1",name:"Freeze ×1",icon:"❄",cost:120,desc:"Save for use mid-game"},{id:"freeze2",name:"Freeze ×2",icon:"❄❄",cost:220,desc:"Two freeze charges"},{id:"shield1",name:"Shield ×1",icon:"◈",cost:150,desc:"Save for use mid-game"},{id:"shield2",name:"Shield ×2",icon:"◈◈",cost:280,desc:"Two shield charges"}],wa=[{cols:2,rows:2,total:4,name:"Spark",mask:null},{cols:3,rows:3,total:9,name:"Cross",mask:[1,3,4,5,7]},{cols:3,rows:3,total:9,name:"Grid",mask:null},{cols:4,rows:4,total:16,name:"Diamond",mask:[1,2,4,7,8,11,13,14]},{cols:4,rows:3,total:12,name:"Block",mask:null},{cols:4,rows:4,total:16,name:"Ring",mask:[0,1,2,3,4,7,8,11,12,13,14,15]},{cols:3,rows:4,total:12,name:"Spiral",mask:[0,1,2,5,8,9,10,11,7]},{cols:4,rows:4,total:16,name:"Chaos",mask:null},{cols:5,rows:5,total:25,name:"X-Ray",mask:[0,4,6,8,12,16,18,20,24]},{cols:5,rows:5,total:25,name:"APEX",mask:null}],Jt=[{cols:2,rows:2,mask:null,minStage:0},{cols:3,rows:3,mask:[1,3,4,5,7],minStage:1},{cols:3,rows:3,mask:null,minStage:1},{cols:3,rows:3,mask:[0,2,4,6,8],minStage:1},{cols:3,rows:3,mask:[0,1,2,3,5,6,7,8],minStage:1},{cols:3,rows:3,mask:[0,1,2,5,7,8],minStage:1},{cols:3,rows:3,mask:[1,3,5,7],minStage:1},{cols:3,rows:3,mask:[0,2,3,5,6,8],minStage:1},{cols:3,rows:3,mask:[0,1,2,4,6,7,8],minStage:1},{cols:4,rows:4,mask:[1,2,4,7,8,11,13,14],minStage:3},{cols:4,rows:4,mask:null,minStage:3},{cols:4,rows:4,mask:[0,1,2,3,4,7,8,11,12,13,14,15],minStage:3},{cols:4,rows:4,mask:[0,3,5,6,9,10,12,15],minStage:3},{cols:4,rows:4,mask:[0,1,2,4,5,8,9,12,13,14],minStage:3},{cols:4,rows:4,mask:[0,1,4,5,10,11,14,15],minStage:3},{cols:4,rows:4,mask:[1,2,4,6,7,9,11,13,14],minStage:3},{cols:4,rows:3,mask:null,minStage:3},{cols:5,rows:5,mask:[0,4,6,8,12,16,18,20,24],minStage:7},{cols:5,rows:5,mask:null,minStage:7},{cols:5,rows:5,mask:[2,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,22],minStage:7},{cols:5,rows:5,mask:[0,1,2,3,4,5,9,10,14,15,19,20,21,22,23,24],minStage:7},{cols:5,rows:5,mask:[0,2,4,6,8,10,12,14,16,18,20,22,24],minStage:7},{cols:5,rows:5,mask:[0,1,4,5,6,7,8,9,10,12,14,15,16,17,18,19,20,23,24],minStage:7},{cols:3,rows:4,mask:[0,1,2,5,8,9,10,11,7],minStage:2},{cols:3,rows:4,mask:[0,2,3,5,6,8,9,11],minStage:2}],mh=[{color:"red",cssColor:"#ef4444",bg:"radial-gradient(circle at 20% 20%, #4a1010 0%, #1a0404 55%)"},{color:"blue",cssColor:"#3b82f6",bg:"radial-gradient(circle at 20% 20%, #0f1a4a 0%, #04071a 55%)"},{color:"green",cssColor:"#22c55e",bg:"radial-gradient(circle at 20% 20%, #0a3018 0%, #041a0a 55%)"},{color:"orange",cssColor:"#f97316",bg:"radial-gradient(circle at 20% 20%, #4a2010 0%, #1a0a04 55%)"},{color:"cyan",cssColor:"#06b6d4",bg:"radial-gradient(circle at 20% 20%, #083040 0%, #020e14 55%)"},{color:"pink",cssColor:"#ec4899",bg:"radial-gradient(circle at 20% 20%, #4a1030 0%, #1a0410 55%)"},{color:"yellow",cssColor:"#eab308",bg:"radial-gradient(circle at 20% 20%, #3a3010 0%, #141004 55%)"}];function ok(t){const e=Math.floor(t/8)%5;return e===0?"square":e===1?"circle":e===2?"square":e===3?"triangle":"mixed"}function ak(t){return function(){t|=0,t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function Bg(){return Math.random()*4294967295>>>0}const lk=14,uk=2.2,ck=.05,gh=4;function $g(t,e){const n=lk*Math.pow(1-ck,t),r=Math.max(uk,n),s=Math.floor(t/gh),i=(e^s*2654435769)>>>0,l=ak(i)()>.5?1:-1;return{duration:r,direction:l}}const Jc=[{min:0,max:4,texts:["Bro couldn't avoid ONE color. 💀","The grid had 12 safe colors. You still lost. 🫠","Have you considered... not touching purple?","A goldfish would've scored higher. Scientifically.","Congratulations on finding the worst possible score.","Purple: 1. You: somehow less than 1.","Even accidentally tapping would've been better.","Did you mean to play a different game? 🙃"]},{min:5,max:9,texts:["Single digits. Your fingers need a firmware update.","That was painful to watch. 😬","You tapped purple like it was the goal.","Somewhere, a purple cell is laughing at you.","Basic difficulty called. It wants a refund.","Bold strategy. Terrible execution.","The tutorial is embarrassed on your behalf."]},{min:10,max:19,texts:["Double digits. The minimum bar cleared. Barely.","You made it to double digits. The grid is unimpressed.","10+ — technically not a complete disaster.","Your thumbs are getting warmed up, apparently.","Progress! You avoided purple... some of the time.","Not bad for your first conscious attempt.","The grid acknowledges your existence. Faintly."]},{min:20,max:34,texts:["Now we're cooking. Medium rare. 🔥","The grid is starting to take you seriously.","20+ — you have actual reflexes. Interesting.","You're in the zone. Stay there.","Your thumbs are having a moment.","The purple is slightly nervous. Good.","Something resembling skill detected."]},{min:35,max:49,texts:["Serious reflexes detected. 🔥","35+? Tell your friends. Brag a little.","Your fingers are professionally trained, apparently.","The grid didn't see that coming.","Almost 50. The threshold of greatness.","You tapped so fast the purple forgot its job.","We're getting somewhere. Keep going."]},{min:50,max:74,texts:["FIFTY. You're a natural. 🏆","Half-century! Legendary energy.","50+ means fast hands and questionable hobbies.","The grid can't stop you. It's accepted this.","Your mom would be proud. Probably.","50+ and counting. You're becoming the grid.","Genuine talent spotted. Finally."]},{min:75,max:99,texts:["75+ is elite territory. 👑","Approaching triple digits. A god awakens.","Your fingers are a biological miracle.","The purple filed a formal complaint. About you.","At this point just go pro.","75+ — researchers want to study your hands.","The grid is scared. Keep it scared."]},{min:100,max:149,texts:["TRIPLE DIGITS. Frame this. 🤯","100+. You've transcended the average human.","The game is genuinely afraid of you now.","Are you using one hand?? Impressive.","100+ — this score belongs in a museum.","The grid has filed for emotional damages.","Absolute specimen. This is real now."]},{min:150,max:999,texts:["ARE YOU HUMAN?? 👾","150+ — we need to talk about your reflexes.","Legend. Myth. Tap god. You.","The purple has retired. Because of you.","Scientists want to study your nervous system.","You broke the intended difficulty curve. Congratulations.","This score should not be possible. And yet.","GOAT status confirmed. No debate."]}];function dk(t){const e=Jc.find(n=>t>=n.min&&t<=n.max)??Jc[Jc.length-1];return e.texts[Math.floor(Math.random()*e.texts.length)]}const o_=["1","2","3","4","q","w","e","r","a","s","d","f","z","x","c","v"],a_=["7","8","9","0","u","i","o","p","j","k","l",";","m",",",".","/"];function l_(t){return t?/^[a-z]$/.test(t)?t.toUpperCase():{" ":"SPC",escape:"ESC",backspace:"⌫",enter:"↵",tab:"↹",",":","}[t]??(t.length===1?t:t.slice(0,3).toUpperCase()):"?"}function qg(t,e){try{const n=localStorage.getItem(t);if(n){const r=JSON.parse(n);if(Array.isArray(r)&&r.length===16)return r}}catch{}return[...e]}function Hg(t,e){try{localStorage.setItem(t,JSON.stringify(e))}catch{}}const hk=["ass","fuck","shit","bitch","cunt","dick","cock","pussy","nigger","nigga","faggot","fag","whore","slut","bastard","damn","hell","sex","porn","nude","kill","rape","pedo","nazi"];function ku(t){const e=t.replace(/[^a-zA-Z0-9_ ]/g,"").trim().slice(0,8)||"Player",n=e.toLowerCase();for(const r of hk)if(n.includes(r))return"Player";return/https?:|www\.|\.com|\.net|\.org/i.test(e)?"Player":e}function fk(t){try{const e=localStorage.getItem(t);if(e)return JSON.parse(e)}catch{}return[]}function pk(t,e){try{localStorage.setItem(t,JSON.stringify(e.slice(0,10)))}catch{}}function mk(t,e,n){const r=ku(n),s=fk(t);s.push({score:e,date:new Date().toLocaleDateString(),initials:r}),s.sort((o,l)=>l.score-o.score);const i=s.slice(0,10);return pk(t,i),i}const Wg=["white","blue","red","orange","yellow","green","cyan","lime","teal","pink","rose","magenta"];function gk(t=0,e=!1){const n=e?Math.min(.42,.22+Math.floor(t/20)*.02):.22;return Math.random()<n?"purple":Wg[Math.floor(Math.random()*Wg.length)]}let Zc=null,u_=!1;function yk(){return Zc||(Zc=new(window.AudioContext||window.webkitAudioContext)),Zc}function Xt(t){if(!u_)try{const e=yk(),n=e.createOscillator(),r=e.createGain();n.connect(r),r.connect(e.destination);const s=e.currentTime;t==="ok"?(n.type="sine",n.frequency.setValueAtTime(880,s),n.frequency.exponentialRampToValueAtTime(1320,s+.08),r.gain.setValueAtTime(.15,s),r.gain.exponentialRampToValueAtTime(.001,s+.12),n.start(),n.stop(s+.12)):t==="bad"?(n.type="sawtooth",n.frequency.setValueAtTime(220,s),n.frequency.exponentialRampToValueAtTime(55,s+.25),r.gain.setValueAtTime(.25,s),r.gain.exponentialRampToValueAtTime(.001,s+.28),n.start(),n.stop(s+.28)):t==="powerup"?(n.type="sine",n.frequency.setValueAtTime(660,s),n.frequency.exponentialRampToValueAtTime(1320,s+.15),r.gain.setValueAtTime(.2,s),r.gain.exponentialRampToValueAtTime(.001,s+.2),n.start(),n.stop(s+.2)):t==="levelup"?(n.type="triangle",n.frequency.setValueAtTime(440,s),n.frequency.setValueAtTime(660,s+.1),n.frequency.setValueAtTime(880,s+.2),r.gain.setValueAtTime(.2,s),r.gain.exponentialRampToValueAtTime(.001,s+.35),n.start(),n.stop(s+.35)):(n.type="square",n.frequency.setValueAtTime(330,s),r.gain.setValueAtTime(.03,s),r.gain.exponentialRampToValueAtTime(.001,s+.04),n.start(),n.stop(s+.04))}catch{}}function Ho(t,e=1){return Math.max(Z1,bu*Math.pow(nk,Math.floor(t/rk))*e)}function vk(t,e){return(bu/Ho(t,e?1.4:1)).toFixed(1)+"×"}function _k(t){return Math.max(4,(bu-Ho(t))/(bu-Z1)*96)}const wk=[{type:"medpack",weight:7},{type:"shield",weight:5},{type:"freeze",weight:4},{type:"multiplier",weight:5}];function xk(t,e,n,r,s,i=0){const o=n??wa[Math.min(t,wa.length-1)],{mask:l}=o,u=o.cols*o.rows,d=l?[...l]:Array.from({length:u},(V,F)=>F),f=d.length,m=Math.min(2+Math.floor(t*.4),f-1),v=Math.min(2+Math.floor(t*.6),Math.min(f-1,5)),I=Math.max(1,m+Math.floor(Math.random()*(v-m+1))),A=[...d];for(let V=0;V<I;V++){const F=V+Math.floor(Math.random()*(A.length-V));[A[V],A[F]]=[A[F],A[V]]}const P=A.slice(0,I);let M=null;if(r?t>=2:!0){const V=wk.map(y=>y.type==="medpack"&&e<tp?{...y,weight:y.weight+10}:y),F=V.reduce((y,_)=>y+_.weight,0),B=r?F:F*.4,w=Math.random()*100;if(w<B){let y=0;for(const _ of V)if(y+=_.weight,w<y){M=_.type;break}}}let x=null;if(r&&t>=3){const V=Math.random();V<.1?x="ice":V<.17&&(x="hold")}return P.map((V,F)=>{if(F===0&&M)return{idx:V,clicked:!1,type:M};if(F===0&&x==="ice")return{idx:V,clicked:!1,type:"ice",iceCount:2+Math.floor(Math.random()*3)};if(F===0&&x==="hold")return{idx:V,clicked:!1,type:"hold",holdRequired:700+Math.random()*500};const B=gk(i,!r);return s&&B==="purple"?{idx:V,clicked:!1,type:s}:{idx:V,clicked:!1,type:B}})}function Ek(t,e,n){var o;const r=Jt.map((l,u)=>({p:l,i:u})).filter(({p:l})=>l.minStage<=t).filter(({p:l})=>n<20?l.cols<=2&&l.rows<=2:n<50?l.cols<=3&&l.rows<=3:n<120?l.cols<=3&&l.rows<=4:n<250?l.cols<=4&&l.rows<=4:!0);if(r.length<=1)return((o=r[0])==null?void 0:o.i)??0;const s=r.filter(({i:l})=>l!==e),i=s[Math.floor(Math.random()*s.length)];return(i==null?void 0:i.i)??r[0].i}function _l(t,e){const{cols:n,rows:r,mask:s}=e,i=n*r,o=Array(25).fill("inactive");if(s){const l=new Set(s);for(let u=0;u<i;u++)l.has(u)||(o[u]="void")}return t.forEach(l=>{l.clicked||(o[l.idx]=l.type)}),o}function yh(){try{const t=localStorage.getItem(i_);if(t)return JSON.parse(t)}catch{}return{freeze:0,shield:0}}function wl(t){try{localStorage.setItem(i_,JSON.stringify(t))}catch{}}function xr(){const t=yh();return{cells:Array(25).fill("inactive"),active:[],score:0,streak:0,alive:!0,anim:{},health:tp,shield:!1,shieldCount:0,freezeEnd:0,multiplierEnd:0,gridStage:0,stageProgress:0,patternIdx:0,storedFreezeCharges:t.freeze,storedShieldCharges:t.shield}}const Tk={medpack:"♥",shield:"◈",freeze:"❄",multiplier:"⚡"},bk={white:"●",blue:"■",red:"▲",orange:"◆",yellow:"★",green:"✚",cyan:"⬟",lime:"⬡",teal:"⬢",pink:"♦",rose:"▼",magenta:"❋",purple:"✕",medpack:"♥",shield:"◈",freeze:"❄",multiplier:"⚡"};function Sk(t){return{white:"#c7d9f5",blue:"#3b82f6",red:"#ef4444",orange:"#f97316",yellow:"#eab308",green:"#22c55e",cyan:"#06b6d4",lime:"#84cc16",teal:"#14b8a6",pink:"#ec4899",rose:"#f43f5e",magenta:"#d946ef",purple:"#a855f7",medpack:"#f59e0b",shield:"#06b6d4",freeze:"#60a5fa",multiplier:"#f97316"}[t]||"#fff"}function kk({type:t,animState:e,keyLabel:n,showKey:r,pressing:s,onTap:i,onHoldStart:o,onHoldEnd:l,colorblind:u,cellShape:d,counterSpinDur:f,iceCount:m,holdRequired:v,holdStart:I,cellIdx:A}){const[P,M]=D.useState([]),[S,x]=D.useState([]),[k,V]=D.useState(0),[F,B]=D.useState(0),w=u?t!=="inactive"?bk[t]??null:null:Tk[t]??null,y=["cell",t,e,s&&t!=="inactive"?"cell--press":null].filter(Boolean).join(" ");D.useEffect(()=>{if(e!=="pop"||t==="inactive")return;V(Math.round(Math.random()*16-8));const J=Sk(t),Pe=Array.from({length:5},(Et,je)=>{const H=je/5*Math.PI*2+Math.random()*.8,Y=28+Math.random()*22;return{id:Date.now()+je,dx:`${Math.round(Math.cos(H)*Y)}px`,dy:`${Math.round(Math.sin(H)*Y)}px`,dr:`${Math.round(120+Math.random()*240)}deg`,color:J}});x(Pe),setTimeout(()=>x([]),420)},[e]),D.useEffect(()=>{if(t!=="hold"||!I||!v){B(0);return}const J=setInterval(()=>B(Math.min(100,(Date.now()-I)/v*100)),50);return()=>clearInterval(J)},[t,I,v]);const _=J=>{if(t==="inactive")return;J.preventDefault();const Pe=J.currentTarget.getBoundingClientRect(),Et=J.clientX-Pe.left,je=J.clientY-Pe.top;if(M(H=>[...H,{id:Date.now()+Math.random(),x:Et,y:je}]),t==="hold"){o();return}i(Et,je)},T=J=>{t==="hold"&&(J.preventDefault(),l())},b=f?{animation:`cellCounterSpin ${f} linear infinite`}:{},C=d==="triangle",E={};return d==="circle"&&(E.borderRadius="50%"),p.jsxs("button",{className:y,"data-cell-idx":A,onPointerDown:_,onPointerUp:T,onPointerLeave:T,onContextMenu:J=>J.preventDefault(),style:{touchAction:"none",userSelect:"none",WebkitUserSelect:"none",...E,...b,...e==="pop"?{"--tilt":`${k}deg`}:{}},"aria-label":`${t} cell`,children:[C&&p.jsx("span",{className:"cell-tri-shape"}),t==="ice"&&m!=null&&p.jsxs("span",{className:"cell-overlay-ice",children:["❄",m]}),t==="hold"&&p.jsxs("span",{className:"cell-overlay-hold",children:[p.jsx("span",{className:"hold-btn-outer",children:p.jsx("span",{className:`hold-btn-inner${F>0?" hold-btn-pressed":""}`,children:F>0?"⬤":"HOLD"})}),F>0&&p.jsx("span",{className:"hold-progress",style:{width:F+"%"}})]}),w&&t!=="ice"&&t!=="hold"&&p.jsx("span",{className:"sym",children:w}),r&&t!=="inactive"&&p.jsx("span",{className:"kbadge",children:l_(n)}),P.map(J=>p.jsx("span",{className:"ripple",style:{left:J.x,top:J.y},onAnimationEnd:()=>M(Pe=>Pe.filter(Et=>Et.id!==J.id))},J.id)),S.map(J=>p.jsx("span",{className:"shard",style:{background:J.color,"--dx":J.dx,"--dy":J.dy,"--dr":J.dr,top:"50%",left:"50%",marginTop:"-3px",marginLeft:"-3px"}},J.id))]})}function c_({health:t,anim:e,shieldCount:n}){const r=n??0,s=Math.max(tp,Math.ceil(t));return p.jsx("div",{className:"hearts",children:Array.from({length:s},(i,o)=>{const l=o<t,u=r>0&&l&&o>=s-r;return p.jsx("span",{className:["heart",l?u?"heart--shield":"heart--full":"heart--empty",e&&o===Math.ceil(t)?"heart--loss":""].filter(Boolean).join(" "),children:"♥"},o)})})}function d_({shield:t,freezeEnd:e,multiplierEnd:n}){const[,r]=D.useState(0);D.useEffect(()=>{if(!(t||e>Date.now()||n>Date.now()))return;const u=setInterval(()=>r(d=>d+1),250);return()=>clearInterval(u)},[t,e,n]);const s=Date.now(),i=e>s?Math.ceil((e-s)/1e3):0,o=n>s?Math.ceil((n-s)/1e3):0;return!t&&i===0&&o===0?null:p.jsxs("div",{className:"pwr-pills",children:[t&&p.jsxs("div",{className:"pwr-chip pwr-chip--shield",children:[p.jsx("span",{className:"pwr-chip-icon",children:"◈"}),p.jsx("span",{className:"pwr-chip-lbl",children:"Shield"})]}),i>0&&p.jsxs("div",{className:"pwr-chip pwr-chip--freeze",children:[p.jsx("span",{className:"pwr-chip-icon",children:"❄"}),p.jsxs("span",{className:"pwr-chip-lbl",children:[i,"s"]})]}),o>0&&p.jsxs("div",{className:"pwr-chip pwr-chip--mult",children:[p.jsx("span",{className:"pwr-chip-icon",children:"⚡"}),p.jsxs("span",{className:"pwr-chip-lbl",children:["2× ",o,"s"]})]})]})}function Ik({direction:t,visible:e}){if(!e)return null;const n=t===1;return p.jsxs("div",{className:"rot-arrows-container","aria-hidden":!0,children:[p.jsxs("svg",{className:`rot-arrow rot-arrow--cw${n?" rot-arrow--active":""}`,viewBox:"0 0 140 140",xmlns:"http://www.w3.org/2000/svg",children:[p.jsx("path",{d:"M 70 10 A 60 60 0 1 1 16 95",fill:"none",stroke:"currentColor",strokeWidth:"14",strokeLinecap:"round"}),p.jsx("polygon",{points:"0,-14 12,10 -12,10",fill:"currentColor",transform:"translate(16,95) rotate(220)"})]}),p.jsxs("svg",{className:`rot-arrow rot-arrow--ccw${n?"":" rot-arrow--active"}`,viewBox:"0 0 140 140",xmlns:"http://www.w3.org/2000/svg",children:[p.jsx("path",{d:"M 70 10 A 60 60 0 1 0 124 95",fill:"none",stroke:"currentColor",strokeWidth:"14",strokeLinecap:"round"}),p.jsx("polygon",{points:"0,-14 12,10 -12,10",fill:"currentColor",transform:"translate(124,95) rotate(140)"})]})]})}function Ak(t,e,n){const r=Math.max(t,e);return n?"clamp(38px, 9vw, 56px)":r<=2?"clamp(100px, 28vw, 140px)":r<=3?"clamp(80px, 22vw, 110px)":r<=4?"clamp(60px, 16vw, 84px)":"clamp(48px, 13vw, 66px)"}function Gg({ps:t,anim:e,onTap:n,onHoldStart:r,onHoldEnd:s,keyLabels:i,showKeys:o,pressing:l,label:u,heartAnim:d,mode:f,colorblind:m,cbFilter:v,is2P:I,shakeGrid:A,cellShape:P,rareMode:M,onPause:S,isFS:x,spinLevel:k,gameSeed:V}){const F=Date.now(),B=f==="evolve"?Jt[t.patternIdx]??wa[0]:{cols:3,rows:3,mask:null},{cols:w,rows:y,mask:_}=B,T=w*y,b=t.freezeEnd>F,C=_?new Set(_):null,E=f==="evolve"&&k>=3,J=E?$g(k,V):null,Pe=J?{animation:`gpanelSpinContinuous${J.direction===1?"CW":"CCW"} ${J.duration.toFixed(2)}s linear infinite`}:{},Et=E&&k%gh===gh-1,je=E?$g(k+1,V):null,H=Et&&J&&je&&J.direction!==je.direction,Y=k>=20&&J?`${(J.duration*1.4).toFixed(2)}s`:null;return p.jsxs("div",{className:`ppanel${t.alive?"":" ppanel--dead"}`,children:[u&&p.jsx("div",{className:"plabel-row",children:p.jsx("div",{className:"plabel",children:u})}),I&&p.jsxs("div",{className:"phud",children:[p.jsxs("div",{className:"phud-score-row",children:[p.jsx("div",{className:"phud-score",children:t.score}),t.streak>=3&&p.jsxs("div",{className:"combo-wrap combo-wrap--sm",children:["×",t.streak]})]}),p.jsx(c_,{health:t.health,anim:d,shieldCount:t.shieldCount})]}),I&&p.jsx("div",{className:"pwr-zone",children:p.jsx(d_,{shield:t.shield,freezeEnd:t.freezeEnd,multiplierEnd:t.multiplierEnd})}),p.jsxs("div",{className:"gpanel-wrap",style:{"--cell":Ak(w,y,I)},children:[H&&je&&p.jsx(Ik,{direction:je.direction,visible:!0}),p.jsx("div",{className:`gpanel${A?" shake-grid":""}`,style:{gridTemplateColumns:`repeat(${w}, var(--cell))`,gridTemplateRows:`repeat(${y}, var(--cell))`,...b?{outline:"2px solid #60a5fa"}:{},...v?{filter:v}:{},...M.active?{outline:`2px solid ${M.cssColor}`}:{},...Pe},children:Array.from({length:T},(ne,ie)=>{if(C&&!C.has(ie))return p.jsx("div",{className:"cell-void"},ie);const ln=t.cells[ie]??"inactive",be=t.active.find(ir=>ir.idx===ie),un=P==="mixed"?["square","circle","triangle"][ie%3]:P,Tt=Math.floor(ie/w),qt=ie%w,es=Tt*4+qt;return p.jsx(kk,{type:ln,animState:e[ie]||null,keyLabel:i[es]||"",showKey:o,pressing:l.has(ie),onTap:()=>n(ie),onHoldStart:()=>r(ie),onHoldEnd:()=>s(ie),colorblind:m,cellShape:f==="evolve"?un:"square",counterSpinDur:Y,iceCount:be==null?void 0:be.iceCount,holdRequired:be==null?void 0:be.holdRequired,holdStart:be==null?void 0:be.holdStart,cellIdx:ie},ie)})})]})]})}function Ck({mode:t,onClose:e}){const[n,r]=D.useState([]),[s,i]=D.useState(!0),[o,l]=D.useState(!1),u=D.useCallback(async()=>{i(!0);try{const d=await ZS();r(d),l(!0)}catch{try{const f=localStorage.getItem(e_),m=localStorage.getItem(t_),v=f?JSON.parse(f).map(P=>({...P,mode:"classic"})):[],I=m?JSON.parse(m).map(P=>({...P,mode:"evolve"})):[],A=[...v,...I].sort((P,M)=>M.score-P.score).slice(0,20);r(A)}catch{r([])}l(!1)}finally{i(!1)}},[]);return D.useEffect(()=>{u()},[u]),p.jsxs("div",{className:"lb-wrap screen-slide",children:[p.jsxs("div",{className:"lb-header",children:[p.jsxs("span",{className:"lb-title",children:["🏆 ",o?"Global":"Local"," Leaderboard"]}),p.jsx("span",{className:"lb-sub",style:{fontSize:10,opacity:.55},children:o?"🌐 Live":"📴 Offline"})]}),s?p.jsx("div",{className:"lb-empty",style:{padding:"32px 0",opacity:.6},children:"Loading..."}):n.length===0?p.jsx("p",{className:"lb-empty",children:"No scores yet. Be the first!"}):p.jsx("div",{className:"lb-list",children:n.map((d,f)=>p.jsxs("div",{className:`lb-row ${f===0?"lb-row--gold":f===1?"lb-row--silver":f===2?"lb-row--bronze":""}`,children:[p.jsx("span",{className:"lb-rank",children:f===0?"🥇":f===1?"🥈":f===2?"🥉":`#${f+1}`}),p.jsx("span",{className:"lb-ini",children:d.initials}),p.jsx("span",{className:"lb-score",children:d.score}),p.jsx("span",{className:"lb-mode-chip",style:{background:d.mode==="evolve"?"rgba(192,38,211,0.18)":"rgba(96,165,250,0.18)",color:d.mode==="evolve"?"#f0abfc":"#93c5fd",fontSize:9,padding:"1px 5px",borderRadius:4,fontWeight:800,fontFamily:"var(--font-ui)"},children:d.mode==="evolve"?"∞ Evolve":"⊞ Classic"}),p.jsx("span",{className:"lb-date",children:d.date})]},f))}),p.jsxs("div",{style:{display:"flex",gap:8,marginTop:12},children:[p.jsx("button",{className:"btn-ghost",style:{flex:1},onClick:e,children:"← Back"}),p.jsx("button",{className:"btn-ghost",style:{flex:1},onClick:u,children:"↻ Refresh"})]})]})}function vh(){try{return parseInt(localStorage.getItem(n_)||"0",10)||0}catch{return 0}}function np(t){try{localStorage.setItem(n_,String(Math.max(0,t)))}catch{}}function Kg(t){const e=vh()+t;return np(e),e}function rp(){try{const t=localStorage.getItem(r_);if(t)return JSON.parse(t)}catch{}return{count:Fn,lastRegen:Date.now()}}function sp(t){try{localStorage.setItem(r_,JSON.stringify(t))}catch{}}function Po(){const t=rp();if(t.count>=Fn)return{count:Fn,lastRegen:Date.now()};const e=Date.now()-t.lastRegen,n=Math.floor(e/Su);if(n>0){const r=Math.min(Fn,t.count+n),s=t.lastRegen+n*Su,i={count:r,lastRegen:s};return sp(i),i}return t}function Rk(){const t=Po();return t.count<=0?!1:(sp({count:t.count-1,lastRegen:t.lastRegen}),!0)}function Iu(){const t=rp();if(t.count>=Fn)return 0;const e=Date.now()-t.lastRegen;return Su-e%Su}function Pk({energy:t,nextRegenMs:e,onRefill:n,dust:r}){const[s,i]=D.useState(e);D.useEffect(()=>{if(t>=Fn)return;const u=setInterval(()=>i(Iu()),1e3);return()=>clearInterval(u)},[t]);const o=Math.floor(s/6e4),l=Math.floor(s%6e4/1e3);return p.jsxs("div",{className:"energy-bar-wrap",children:[p.jsx("div",{className:"energy-pips",children:Array.from({length:Fn},(u,d)=>p.jsx("span",{className:`energy-pip${d<t?" energy-pip--full":""}`,children:"⚡"},d))}),t<Fn&&p.jsxs("div",{className:"energy-regen-row",children:[p.jsxs("span",{className:"energy-timer",children:["+1 in ",o,":",String(l).padStart(2,"0")]}),r>=pi&&p.jsxs("button",{className:"energy-refill-btn",onClick:n,children:["💜 ",pi," → +1"]})]})]})}function _h(){try{const t=localStorage.getItem(s_);if(t)return JSON.parse(t)}catch{}return{unlockedThemes:["default"],equippedTheme:"default"}}function Qg(t){try{localStorage.setItem(s_,JSON.stringify(t))}catch{}}function Nk({dust:t,onDustChange:e,onClose:n}){const[r,s]=D.useState(()=>_h()),[i,o]=D.useState("themes"),[l,u]=D.useState(null),d=A=>{if(t<A)return!1;const P=t-A;return np(P),e(P),!0},f=(A,P)=>{if(!d(P))return;const M={...r,unlockedThemes:[...r.unlockedThemes,A]};s(M),Qg(M),u(A),setTimeout(()=>u(null),600)},m=A=>{const P={...r,equippedTheme:A};s(P),Qg(P)},v=(A,P)=>{if(!d(P))return;const M=yh();A==="freeze1"&&wl({...M,freeze:M.freeze+1}),A==="freeze2"&&wl({...M,freeze:M.freeze+2}),A==="shield1"&&wl({...M,shield:M.shield+1}),A==="shield2"&&wl({...M,shield:M.shield+2}),u(A),setTimeout(()=>u(null),600)},I=yh();return p.jsxs("div",{className:"lb-wrap screen-slide",children:[p.jsxs("div",{className:"lb-header",children:[p.jsx("span",{className:"lb-title",children:"🛒 Shop"}),p.jsxs("span",{style:{fontSize:13,color:"var(--accent)",fontWeight:800,fontFamily:"var(--font-ui)"},children:["💜 ",t.toLocaleString()]})]}),p.jsxs("div",{className:"shop-tabs",children:[p.jsx("button",{className:`shop-tab${i==="themes"?" shop-tab--on":""}`,onClick:()=>o("themes"),children:"🎨 Themes"}),p.jsx("button",{className:`shop-tab${i==="powerups"?" shop-tab--on":""}`,onClick:()=>o("powerups"),children:"⚡ Power-ups"})]}),i==="themes"&&p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"shop-hint",children:"Cosmetic themes — affects colors & background"}),p.jsx("div",{className:"shop-grid",children:ph.map(A=>{const P=r.unlockedThemes.includes(A.id),M=r.equippedTheme===A.id;return p.jsxs("div",{className:`shop-item${M?" shop-item--equipped":""}${l===A.id?" shop-item--bought":""}`,children:[p.jsx("div",{className:"shop-swatch",style:{background:`linear-gradient(135deg, ${A.colors.bg} 0%, ${A.colors.purple}88 100%)`},children:p.jsx("span",{style:{fontSize:22,filter:"drop-shadow(0 2px 6px rgba(0,0,0,0.5))"},children:"🎨"})}),p.jsx("div",{className:"shop-name",children:A.name}),A.cost===0||P?p.jsx("button",{className:M?"btn-primary btn-sm":"btn-ghost btn-sm",style:{fontSize:11,padding:"4px 12px"},onClick:()=>m(A.id),children:M?"✓ On":"Equip"}):p.jsxs("button",{className:"btn-ghost btn-sm",style:{fontSize:11,padding:"4px 12px",opacity:t>=A.cost?1:.4},onClick:()=>f(A.id,A.cost),disabled:t<A.cost,children:["💜 ",A.cost]})]},A.id)})})]}),i==="powerups"&&p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"shop-hint",children:"Saved charges carry into your next game — tap to activate mid-round"}),I.freeze>0||I.shield>0?p.jsxs("div",{className:"shop-inventory",children:[p.jsx("span",{className:"shop-inv-lbl",children:"In your bag:"}),I.freeze>0&&p.jsxs("span",{className:"shop-inv-chip",children:["❄ ×",I.freeze]}),I.shield>0&&p.jsxs("span",{className:"shop-inv-chip",children:["◈ ×",I.shield]})]}):null,p.jsx("div",{className:"shop-pwr-list",children:ik.map(A=>p.jsxs("div",{className:`shop-pwr-item${l===A.id?" shop-item--bought":""}`,children:[p.jsx("div",{className:"shop-pwr-icon",children:A.icon.split("").map((P,M)=>p.jsx("span",{children:P},M))}),p.jsxs("div",{className:"shop-pwr-info",children:[p.jsx("div",{className:"shop-pwr-name",children:A.name}),p.jsx("div",{className:"shop-pwr-desc",children:A.desc})]}),p.jsxs("button",{className:"btn-ghost btn-sm",style:{fontSize:12,padding:"5px 14px",flexShrink:0,opacity:t>=A.cost?1:.4},onClick:()=>v(A.id,A.cost),disabled:t<A.cost,children:["💜 ",A.cost]})]},A.id))})]}),p.jsx("button",{className:"btn-ghost",style:{width:"100%",marginTop:14},onClick:n,children:"← Back"})]})}function Vk({dust:t}){return p.jsxs("div",{className:"dust-widget",children:[p.jsx("span",{className:"dust-icon",children:"💜"}),p.jsx("span",{className:"dust-val",children:t.toLocaleString()})]})}function Dk({onClose:t}){return p.jsxs("div",{className:"how-wrap screen-slide",children:[p.jsx("h2",{className:"how-title",children:"How to Play"}),p.jsxs("div",{className:"how-grid",children:[p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#dde4ee"},children:"⬜"}),p.jsxs("div",{children:[p.jsx("b",{children:"Safe colors"}),p.jsx("br",{}),"Tap as fast as you can for +1 point"]})]}),p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#a855f7"},children:"🟣"}),p.jsxs("div",{children:[p.jsx("b",{children:"Purple = danger"}),p.jsx("br",{}),"Never tap purple — you lose a heart"]})]}),p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#fcd34d"},children:"♥"}),p.jsxs("div",{children:[p.jsx("b",{children:"Medpack"}),p.jsx("br",{}),"Restores one heart"]})]}),p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#67e8f9"},children:"◈"}),p.jsxs("div",{children:[p.jsx("b",{children:"Shield"}),p.jsx("br",{}),"Blocks the next damage"]})]}),p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#bfdbfe"},children:"❄"}),p.jsxs("div",{children:[p.jsx("b",{children:"Freeze"}),p.jsx("br",{}),"Slows time by 40% for 5 seconds"]})]}),p.jsxs("div",{className:"how-row",children:[p.jsx("span",{className:"how-icon",style:{color:"#fb923c"},children:"⚡"}),p.jsxs("div",{children:[p.jsx("b",{children:"Multiplier"}),p.jsx("br",{}),"Double points for 8 seconds"]})]})]}),p.jsxs("div",{className:"how-modes",children:[p.jsxs("div",{className:"how-mode",children:[p.jsx("b",{children:"⊞ Classic"})," — Fixed 3×3 grid, pure speed challenge"]}),p.jsxs("div",{className:"how-mode",children:[p.jsx("b",{children:"∞ Evolve Mode"})," — Grid grows from 2×2 to 5×5 as you improve"]})]}),p.jsx("p",{className:"how-tip",children:"⚡ Miss a safe cell = lose a heart · Tap purple = lose a heart · Survive = glory"}),p.jsx("button",{className:"btn-ghost",onClick:t,children:"← Back"})]})}function Mk({initP1:t,initP2:e,numPlayers:n,onSave:r,onCancel:s}){const[i,o]=D.useState(1),[l,u]=D.useState([...t]),[d,f]=D.useState([...e]),[m,v]=D.useState(null),I=D.useRef(null);I.current=m;const A=i===1?l:d,P=i===1?u:f;return D.useEffect(()=>{const M=new Set(["control","alt","meta","shift","tab","capslock","f1","f2","f3","f4","f5","f6","f7","f8","f9","f10","f11","f12"]),S=x=>{if(I.current===null)return;const k=x.key.toLowerCase();if(!M.has(k)){if(x.preventDefault(),k==="escape"){v(null);return}P(V=>{const F=[...V],B=F.indexOf(k);return B!==-1&&B!==I.current&&(F[B]=""),F[I.current]=k,F}),v(null)}};return window.addEventListener("keydown",S),()=>window.removeEventListener("keydown",S)},[P]),p.jsx("div",{className:"kb-overlay",children:p.jsxs("div",{className:"kb-panel",children:[p.jsx("h2",{className:"kb-title",children:"Customize Keys"}),n===2&&p.jsx("div",{className:"kb-tabs",children:[1,2].map(M=>p.jsxs("button",{className:`kb-tab ${i===M?"kb-tab--on":""}`,onClick:()=>{o(M),v(null)},children:["Player ",M]},M))}),p.jsx("p",{className:"kb-hint",children:m!==null?`Press a key for Row ${Math.floor(m/4)+1}, Col ${m%4+1} (Esc = cancel)`:"Tap a cell to select it, then press the key you want"}),p.jsx("div",{className:"kb-grid",children:A.map((M,S)=>p.jsx("button",{className:["kb-cell",m===S?"kb-cell--on":"",M?"":"kb-cell--empty"].filter(Boolean).join(" "),onClick:()=>v(x=>x===S?null:S),children:l_(M)||"—"},S))}),p.jsxs("div",{className:"kb-footer",children:[p.jsx("button",{className:"btn-ghost",onClick:()=>{i===1?u([...o_]):f([...a_]),v(null)},children:"Reset"}),p.jsxs("div",{style:{display:"flex",gap:8},children:[p.jsx("button",{className:"btn-ghost",onClick:s,children:"Cancel"}),p.jsx("button",{className:"btn-primary btn-sm",onClick:()=>r(l,d),children:"Save"})]})]})]})})}function Lk({score:t,mode:e,onClose:n}){const[r,s]=D.useState(!1),i="https://game.mscarabia.com",o=e==="classic"?"Classic":"Evolve",l=`🎮 I scored ${t} in Don't Touch the Purple — ${o} Mode!
Can you beat me? 👇
${i}`,u=encodeURIComponent(l),d=`https://twitter.com/intent/tweet?text=${u}`,f=`https://wa.me/?text=${u}`,m=()=>{var I;const v=()=>{const A=document.createElement("textarea");A.value=l,A.style.position="fixed",A.style.opacity="0",document.body.appendChild(A),A.select(),document.execCommand("copy"),document.body.removeChild(A),s(!0),setTimeout(()=>s(!1),2e3)};(I=navigator.clipboard)!=null&&I.writeText?navigator.clipboard.writeText(l).then(()=>{s(!0),setTimeout(()=>s(!1),2e3)}).catch(v):v()};return p.jsxs("div",{className:"share-card",children:[p.jsxs("div",{className:"share-inner",children:[p.jsxs("div",{className:"share-logo",children:["Don't Touch the ",p.jsx("span",{style:{color:"#c026d3"},children:"Purple"})]}),p.jsx("div",{className:"share-score",children:t}),p.jsxs("div",{className:"share-mode",children:[o," Mode"]}),p.jsx("div",{className:"share-invite",children:"Think you can beat that? 👀"}),p.jsx("div",{className:"share-url",children:i})]}),p.jsxs("div",{className:"share-btns",children:[p.jsxs("a",{className:"share-social share-social--x",href:d,target:"_blank",rel:"noopener",children:[p.jsx("span",{className:"share-social-icon",children:"𝕏"})," Post on X"]}),p.jsxs("a",{className:"share-social share-social--wa",href:f,target:"_blank",rel:"noopener",children:[p.jsx("span",{className:"share-social-icon",children:"📱"})," WhatsApp"]}),p.jsxs("button",{className:"share-social share-social--copy",onClick:m,children:[p.jsx("span",{className:"share-social-icon",children:r?"✓":"📋"})," ",r?"Copied!":"Copy Link"]})]}),p.jsx("button",{className:"btn-ghost",style:{width:"100%",marginTop:8},onClick:n,children:"← Back"})]})}function Ts({options:t,value:e,onChange:n}){const r=t.findIndex(l=>l.value===e),s=D.useRef(null),i=D.useRef(null),o=D.useCallback(()=>{const l=i.current,u=s.current;if(!l||!u)return;const f=l.querySelectorAll(".pill-opt")[r];f&&(u.style.left=f.offsetLeft+"px",u.style.width=f.offsetWidth+"px")},[r]);return D.useEffect(()=>{o();let l,u;l=requestAnimationFrame(()=>{u=requestAnimationFrame(o)});const d=i.current;if(!d||typeof ResizeObserver>"u")return()=>{cancelAnimationFrame(l),cancelAnimationFrame(u)};const f=new ResizeObserver(()=>{o(),requestAnimationFrame(o)});return f.observe(d),d.parentElement&&f.observe(d.parentElement),()=>{f.disconnect(),cancelAnimationFrame(l),cancelAnimationFrame(u)}},[o,r]),p.jsxs("div",{className:"pill-row",ref:i,children:[p.jsx("div",{className:"pill-thumb",ref:s}),t.map((l,u)=>p.jsx("button",{className:`pill-opt${u===r?" pill-opt--on":""}`,onClick:()=>n(l.value),children:l.label},l.value))]})}function jk({colorblindMode:t,setColorblindMode:e,theme:n,setTheme:r,muted:s,setMuted:i,isFS:o,toggleFS:l,onClose:u}){return p.jsx("div",{className:"drawer-overlay",onClick:u,children:p.jsxs("div",{className:"drawer-panel",onClick:d=>d.stopPropagation(),children:[p.jsxs("div",{className:"drawer-header",children:[p.jsx("span",{className:"drawer-title",children:"⚙ Settings"}),p.jsx("button",{className:"btn-icon",onClick:u,children:"✕"})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"🌙 Appearance"}),p.jsx(Ts,{options:[{value:"dark",label:"🌑 Dark"},{value:"light",label:"☀️ Light"}],value:n,onChange:r})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"🔊 Sound"}),p.jsx(Ts,{options:[{value:"on",label:"🔊 On"},{value:"off",label:"🔇 Off"}],value:s?"off":"on",onChange:d=>i(d==="off")})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"⊞ Display"}),p.jsx(Ts,{options:[{value:"window",label:"⊟ Window"},{value:"full",label:"⊞ Fullscreen"}],value:o?"full":"window",onChange:()=>l()})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"👁 Colorblind Mode"}),p.jsx(Ts,{options:[{value:"none",label:"None"},{value:"deuteranopia",label:"Deuter"},{value:"protanopia",label:"Protan"},{value:"tritanopia",label:"Tritan"},{value:"monochrome",label:"Mono"}],value:t,onChange:e})]})]})})}function Ok({onDismiss:t}){return p.jsxs("div",{className:"privacy-banner",children:[p.jsxs("span",{className:"privacy-txt",children:["This game stores scores locally and on a global leaderboard."," ",p.jsx("a",{href:"/privacy.html",target:"_blank",rel:"noopener noreferrer",className:"privacy-link-inline",children:"Privacy Policy"})]}),p.jsx("button",{className:"privacy-dismiss",onClick:t,"aria-label":"Dismiss",children:"✕"})]})}function Fk(){return p.jsx("svg",{style:{position:"absolute",width:0,height:0,overflow:"hidden"},"aria-hidden":!0,children:p.jsxs("defs",{children:[p.jsx("filter",{id:"deuteranopia",children:p.jsx("feColorMatrix",{type:"matrix",values:`
            0.625 0.375 0     0 0
            0.7   0.3   0     0 0
            0     0.3   0.7   0 0
            0     0     0     1 0`})}),p.jsx("filter",{id:"protanopia",children:p.jsx("feColorMatrix",{type:"matrix",values:`
            0.567 0.433 0     0 0
            0.558 0.442 0     0 0
            0     0.242 0.758 0 0
            0     0     0     1 0`})}),p.jsx("filter",{id:"tritanopia",children:p.jsx("feColorMatrix",{type:"matrix",values:`
            0.95  0.05  0     0 0
            0     0.433 0.567 0 0
            0     0.475 0.525 0 0
            0     0     0     1 0`})})]})})}function zk(t){return t==="deuteranopia"?"url('#deuteranopia')":t==="protanopia"?"url('#protanopia')":t==="tritanopia"?"url('#tritanopia')":t==="monochrome"?"grayscale(1)":""}function Yg(t){try{t()}catch(e){console.warn("[DTP-005]",e)}}function Uk({p1:t,p2:e,tick:n,gameMode:r,numPlayers:s,rareMode:i,cellShape:o,paused:l,screen:u,onClose:d}){const f=(m,v)=>p.jsxs("div",{className:"dev-row",children:[p.jsx("span",{className:"dev-key",children:m}),p.jsx("span",{className:"dev-val",children:String(v)})]},m);return p.jsx("div",{className:"dev-overlay",onClick:d,children:p.jsxs("div",{className:"dev-panel",onClick:m=>m.stopPropagation(),children:[p.jsx("div",{className:"dev-title",children:"🛠 DEV — Press Ctrl+Shift+D to close"}),p.jsx("div",{className:"dev-section",children:"GAME"}),f("screen",u),f("mode",r),f("players",s),f("tick",n),f("paused",l),f("cellShape",o),f("rareMode.active",i.active),i.active&&f("rareMode.color",i.color),i.active&&f("rareMode.turnsLeft",i.turnsLeft),p.jsx("div",{className:"dev-section",children:"PLAYER 1"}),f("score",t.score),f("health",t.health),f("stage",t.gridStage),f("patternIdx",t.patternIdx),f("streak",t.streak),f("shield",t.shield),f("alive",t.alive),f("active cells",t.active.length),t.active.map((m,v)=>f(`  [${v}] idx:${m.idx} type`,`${m.type}${m.iceCount!=null?` ice×${m.iceCount}`:""}${m.holdRequired!=null?" hold":""} clicked:${m.clicked}`)),s===2&&p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"dev-section",children:"PLAYER 2"}),f("score",e.score),f("health",e.health),f("stage",e.gridStage),f("patternIdx",e.patternIdx),f("alive",e.alive)]}),p.jsx("div",{className:"dev-section",children:"FORCE STAGE (click)"}),wa.map((m,v)=>p.jsx("span",{className:"dev-btn",onClick:()=>{window.dispatchEvent(new CustomEvent("dtp-dev-stage",{detail:v}))},children:m.name},v)),p.jsx("div",{className:"dev-section",children:"FORCE PATTERN (click)"}),Jt.slice(0,12).map((m,v)=>p.jsxs("span",{className:"dev-btn",onClick:()=>{window.dispatchEvent(new CustomEvent("dtp-dev-pattern",{detail:v}))},children:["P",v," ",m.cols,"×",m.rows,m.mask?"m":""]},v)),p.jsx("div",{className:"dev-section",children:"RARE MODE"}),mh.map(m=>p.jsx("span",{className:"dev-btn",style:{color:m.cssColor},onClick:()=>{window.dispatchEvent(new CustomEvent("dtp-dev-rare",{detail:m}))},children:m.color},m.color)),p.jsx("span",{className:"dev-btn",onClick:()=>window.dispatchEvent(new CustomEvent("dtp-dev-rare",{detail:null})),children:"clear rare"})]})})}function Bk({progress:t,done:e,showNameEntry:n,onNameSubmit:r}){const[s,i]=D.useState(""),[o,l]=D.useState(""),u=()=>{const d=ku(s.trim()||"Player");if(d==="Player"&&s.trim().length>0){l("That name isn't allowed. Try another!");return}r(d||"Player")};return p.jsxs("div",{className:`loading-screen${e&&!n?" loading-screen--out":""}`,style:{background:"linear-gradient(145deg,#0d0820,#1a0a3e)",fontFamily:"'Fredoka One',system-ui,sans-serif"},children:[p.jsx("div",{className:"loading-orb loading-orb-1"}),p.jsx("div",{className:"loading-orb loading-orb-2"}),p.jsx("div",{className:"loading-orb loading-orb-3"}),p.jsxs("div",{className:"loading-logo",style:{textShadow:"0 0 40px rgba(192,38,211,0.8)"},children:["Don't Touch the ",p.jsx("span",{className:"loading-purple",children:"Purple"})]}),p.jsx("div",{className:"loading-sub",children:"Get your fingers ready..."}),e?n?p.jsxs("div",{className:"loading-name-entry",style:{background:"rgba(255,255,255,0.05)",padding:"24px",borderRadius:"24px",border:"1px solid rgba(192,38,211,0.3)",backdropFilter:"blur(10px)",marginTop:20,width:"min(320px, 90vw)"},children:[p.jsx("div",{className:"loading-name-label",style:{marginBottom:12},children:"What should we call you?"}),p.jsx("input",{className:"go-input",maxLength:8,placeholder:"Your name",value:s,autoFocus:!0,style:{width:"100%",marginBottom:12},onChange:d=>{i(d.target.value.replace(/[^a-zA-Z0-9_ ]/g,"").slice(0,8)),l("")},onKeyDown:d=>d.key==="Enter"&&u()}),p.jsx("button",{className:"btn-primary",style:{width:"100%",padding:"12px"},onClick:u,children:"Let's Go!"}),o&&p.jsx("div",{style:{color:"#f87171",fontSize:12,marginTop:8,fontFamily:"var(--font-ui)"},children:o})]}):p.jsxs("div",{style:{width:"min(280px, 80vw)",marginTop:20},children:[p.jsx("div",{className:"loading-bar-track",children:p.jsx("div",{className:"loading-bar-fill",style:{width:"100%"}})}),p.jsx("div",{className:"loading-pct",style:{marginTop:8},children:"100%"})]}):p.jsxs("div",{style:{width:"min(280px, 80vw)",marginTop:20},children:[p.jsx("div",{className:"loading-bar-track",children:p.jsx("div",{className:"loading-bar-fill",style:{width:`${t}%`}})}),p.jsxs("div",{className:"loading-pct",style:{marginTop:8},children:[Math.round(t),"%"]})]})]})}function $k(){const[t,e]=D.useState(0),[n,r]=D.useState(!1),[s,i]=D.useState(!1),[o,l]=D.useState(()=>{try{return localStorage.getItem(To)}catch{return null}}),[u,d]=D.useState(!1),[f,m]=D.useState(()=>vh()),[v,I]=D.useState(()=>Po()),A=v.count;D.useEffect(()=>{const z=()=>I(Po());window.addEventListener("focus",z);const q=setInterval(z,3e4);return()=>{window.removeEventListener("focus",z),clearInterval(q)}},[]);const[P,M]=D.useState(!1),[S,x]=D.useState(!1),[k,V]=D.useState(()=>_h()),F=ph.find(z=>z.id===k.equippedTheme)??ph[0];D.useEffect(()=>{const z=localStorage.getItem(Ug),q=new Date().toLocaleDateString();z!==q&&o&&tk(o).then(O=>{if(O>0){const Z=Kg(O);m(Z)}localStorage.setItem(Ug,q)}).catch(()=>{})},[o]),D.useEffect(()=>{let z=0;const q=setInterval(()=>{z+=8+Math.random()*12,z>=100&&(z=100,clearInterval(q),e(100),setTimeout(()=>{r(!0),localStorage.getItem(To)?setTimeout(()=>i(!0),600):d(!0)},300)),e(z)},80);return()=>clearInterval(q)},[]);const B=z=>{try{localStorage.setItem(To,z)}catch{}l(z),d(!1),setTimeout(()=>i(!0),400)},[w,y]=D.useState(!1);D.useEffect(()=>{const z=q=>{q.ctrlKey&&q.shiftKey&&q.key==="D"&&(q.preventDefault(),y(O=>!O))};return window.addEventListener("keydown",z),()=>window.removeEventListener("keydown",z)},[]);const[_,T]=D.useState("menu"),[b,C]=D.useState("classic"),[E,J]=D.useState(1),[Pe,Et]=D.useState("touch"),[je,H]=D.useState(!1),[Y,ne]=D.useState(!1),[ie,Te]=D.useState(null),[ln,be]=D.useState(!1),[un,Tt]=D.useState(""),[qt,es]=D.useState("classic"),[ir,Pa]=D.useState(""),[oc,Ki]=D.useState(!1),[zs,Us]=D.useState(null),[Na,Qi]=D.useState("dark"),[Yi,Xi]=D.useState(!1),[et,tt]=D.useState(!1),[or,ac]=D.useState("none"),[Va,Ji]=D.useState(!1),[ts,Da]=D.useState(()=>{try{return!localStorage.getItem(zg)}catch{return!1}}),[_e,Sn]=D.useState(xr()),[ar,Bs]=D.useState(xr()),[Zi,eo]=D.useState(!1),[ns,$s]=D.useState(!1),[to,kn]=D.useState(new Set),[Ma,rs]=D.useState(new Set),[qs,ss]=D.useState(0),[no,Qe]=D.useState(null),[ro,is]=D.useState(0),[Hs,lc]=D.useState(0),[os,lr]=D.useState(()=>qg(Og,o_)),[as,uc]=D.useState(()=>qg(Fg,a_)),[ur,so]=D.useState("square"),[nt,cn]=D.useState({active:!1,color:"",cssColor:"",turnsLeft:0}),[dn,cr]=D.useState(null),[Un,io]=D.useState(0),[oo,ls]=D.useState(0),[dr,La]=D.useState(()=>Bg()),[ja,us]=D.useState(!1),ce=D.useRef(xr()),Se=D.useRef(xr()),Ht=D.useRef(0),Wt=D.useRef("menu"),Ue=D.useRef(1),In=D.useRef("touch"),Bn=D.useRef("classic"),Oa=D.useRef(os),ao=D.useRef(as),Ct=D.useRef(null),cs=D.useRef(1),qe=D.useRef({active:!1,color:"",cssColor:"",turnsLeft:0}),ds=D.useRef(0),$n=D.useRef(!1),hr=D.useRef(!0);D.useEffect(()=>{Wt.current=_},[_]),D.useEffect(()=>{Ue.current=E},[E]),D.useEffect(()=>{In.current=Pe},[Pe]),D.useEffect(()=>{Bn.current=b},[b]),D.useEffect(()=>{Oa.current=os},[os]),D.useEffect(()=>{ao.current=as},[as]),D.useEffect(()=>{u_=je},[je]),D.useEffect(()=>()=>{hr.current=!1},[]);const Gt=D.useCallback(()=>{hr.current&&(Sn({...ce.current}),Bs({...Se.current}),ss(Ht.current))},[]),lo=D.useRef(null),Ce=D.useCallback(z=>{lo.current&&clearTimeout(lo.current),Te(z),lo.current=setTimeout(()=>Te(null),2200)},[]),Oe=D.useCallback((z,q,O,Z)=>{z.current.anim={...z.current.anim,[O]:Z},q({...z.current}),setTimeout(()=>{if(!hr.current)return;const W={...z.current.anim};delete W[O],z.current.anim=W,q({...z.current})},Z==="pop"?300:420)},[]),hn=D.useCallback(z=>{z===1?(eo(!0),setTimeout(()=>eo(!1),420)):($s(!0),setTimeout(()=>$s(!1),420))},[]),fn=D.useCallback(z=>{z===1?(Xi(!0),setTimeout(()=>Xi(!1),400)):(tt(!0),setTimeout(()=>tt(!1),400))},[]),qn=D.useCallback(z=>{Ct.current&&clearTimeout(Ct.current),$n.current=!1,setTimeout(()=>{if(!hr.current)return;const q=ce.current.score,O=Se.current.score,Z=Ue.current===1?q:Math.max(q,O),W=Kg(Z);if(m(W),Z>0){const te=localStorage.getItem(To)||"Player";ek(te,W).catch(()=>{})}is(te=>Math.max(te,q)),lc(te=>Math.max(te,O)),Qe(z),Tt(dk(Ue.current===1?q:Math.max(q,O))),Wt.current="gameover",T("gameover")},400)},[]),ge=D.useCallback((z,q)=>{if(Wt.current!=="playing")return;const O=z===1?ce:Se,Z=z===1?Sn:Bs;if(!O.current||!O.current.alive){console.warn("[DTP-004]");return}const W=O.current.active.find(Ne=>Ne.idx===q);if(!W||W.clicked)return;const de=Bn.current==="evolve",Fe=O.current.patternIdx,rt=de?Jt[Fe]??Jt[0]:{cols:3,rows:3,mask:null};if(!(rt.mask??Array.from({length:rt.cols*rt.rows},(Ne,bt)=>bt)).includes(q))return;const pe=qe.current.active?qe.current.color:"purple";if(W.type==="ice"){const Ne=(W.iceCount??1)-1;if(Oe(O,Z,q,Ne<=0?"pop":"shake"),Xt(Ne<=0?"ok":"tick"),Ne<=0){W.clicked=!0;const bt=Date.now()<O.current.multiplierEnd?2:1;O.current.score+=bt,O.current.streak+=1,O.current.stageProgress+=1}else W.iceCount=Ne;O.current.cells=_l(O.current.active,rt),Z({...O.current});return}if(W.type==="hold")return;W.clicked=!0;const yr=de?.5:1;if(W.type===pe||W.type==="purple"&&pe!=="purple"){if(O.current.shieldCount>0)O.current.shieldCount-=1,O.current.shield=O.current.shieldCount>0,Xt("ok"),Oe(O,Z,q,"pop");else if(O.current.health=Math.max(0,O.current.health-yr),O.current.shield=!1,O.current.streak=0,Xt("bad"),Oe(O,Z,q,"shake"),hn(z),fn(z),O.current.health<=0){O.current.alive=!1;const Ne=Ue.current===2?z===1?Se.current.alive:ce.current.alive:!1;qn(Ue.current===1?null:Ne?z===1?"p2":"p1":"tie")}}else if(W.type==="purple"){if(O.current.shieldCount>0)O.current.shieldCount-=1,O.current.shield=O.current.shieldCount>0,Xt("ok"),Oe(O,Z,q,"pop");else if(O.current.health=Math.max(0,O.current.health-yr),O.current.shield=!1,O.current.streak=0,Xt("bad"),Oe(O,Z,q,"shake"),hn(z),fn(z),O.current.health<=0){O.current.alive=!1;const Ne=Ue.current===2?z===1?Se.current.alive:ce.current.alive:!1;qn(Ue.current===1?null:Ne?z===1?"p2":"p1":"tie")}}else if(["medpack","shield","freeze","multiplier"].includes(W.type))Xt("powerup"),Oe(O,Z,q,"pop"),W.type==="medpack"&&(O.current.health+=1),W.type==="shield"&&(O.current.shieldCount+=1,O.current.shield=!0),W.type==="freeze"&&(O.current.storedFreezeCharges=(O.current.storedFreezeCharges??0)+1),W.type==="multiplier"&&(O.current.multiplierEnd=Date.now()+24e3),Ce(W.type==="medpack"?"♥ +1 Heart!":W.type==="shield"?`🛡 Shield ×${O.current.shieldCount}!`:W.type==="freeze"?"❄ Freeze saved! Tap to use":"⚡ 2× Points!");else{Xt("ok"),Oe(O,Z,q,"pop");const Ne=Date.now()<O.current.multiplierEnd?2:1;O.current.score+=Ne,O.current.streak+=1,O.current.stageProgress+=1,de&&O.current.stageProgress>=sk&&O.current.gridStage<wa.length-1&&(O.current.gridStage+=1,O.current.stageProgress=0,cs.current=1,Xt("levelup"),ls(bt=>bt+1),Us(`Stage ${O.current.gridStage}`),setTimeout(()=>Us(null),2200))}O.current.cells=_l(O.current.active,rt),Z({...O.current})},[Oe,qn,hn,fn,Ce]),hs=D.useCallback((z,q)=>{const O=z===1?ce:Se,Z=z===1?Sn:Bs;if(!O.current.alive)return;const W=O.current.active.find(te=>te.idx===q&&te.type==="hold"&&!te.clicked);W&&(W.holdStart=Date.now(),W._holding=!0,Z({...O.current}))},[]),fr=D.useCallback((z,q)=>{const O=z===1?ce:Se,Z=z===1?Sn:Bs;if(!O.current.alive)return;const W=O.current.active.find(rt=>rt.idx===q&&rt.type==="hold"&&!rt.clicked);if(!W||!W.holdStart||!W.holdRequired)return;const de=Bn.current==="evolve"?Jt[O.current.patternIdx]??Jt[0]:{cols:3,rows:3,mask:null};if(Date.now()-W.holdStart>=W.holdRequired){W.clicked=!0,W._holding=!1,Oe(O,Z,q,"pop"),Xt("powerup");const rt=Date.now()<O.current.multiplierEnd?2:1;O.current.score+=rt*2,O.current.streak+=1,O.current.stageProgress+=1,Ce("💪 Hold! +2")}else W.holdStart=void 0,Oe(O,Z,q,"shake");O.current.cells=_l(O.current.active,de),Z({...O.current})},[Oe,Ce]),pn=D.useCallback(()=>{if(!hr.current){console.warn("[DTP-001]");return}if(Wt.current!=="playing"||$n.current)return;const z=Date.now(),q=Bn.current;ds.current+=1;const O=ds.current;if(q==="evolve"&&so(ok(O)),q==="evolve")if(qe.current.active)qe.current.turnsLeft-=1,qe.current.turnsLeft<=0?(qe.current={active:!1,color:"",cssColor:"",turnsLeft:0},cn({active:!1,color:"",cssColor:"",turnsLeft:0}),Ce("🟣 Back to Purple!")):cn({...qe.current});else{const te=ce.current.score;if(te>=50&&te%50<4&&Math.random()<.35){const de=mh[Math.floor(Math.random()*mh.length)],Fe={active:!0,color:de.color,cssColor:de.cssColor,turnsLeft:5+Math.floor(Math.random()*4)};qe.current=Fe,cn(Fe),cr({color:de.color,cssColor:de.cssColor}),setTimeout(()=>cr(null),5e3),Ce(`⚠️ Don't Touch ${de.color.toUpperCase()}!`)}}[ce,Se].forEach((te,de)=>{if(!te.current.alive||de===1&&Ue.current===1)return;const Fe=te.current.gridStage,rt=te.current.patternIdx,Kt=q==="evolve"?Jt[rt]??Jt[0]:{cols:3,rows:3,mask:null};if(!Kt||Kt.cols===0){console.error("[DTP-002]");return}const pe=new Set(Kt.mask??Array.from({length:Kt.cols*Kt.rows},(Qt,Yt)=>Yt)),yr=qe.current.active?qe.current.color:"purple";if(te.current.active.forEach(Qt=>{if(!pe.has(Qt.idx)||Qt.clicked)return;const Yt=["medpack","shield","freeze","multiplier","ice","hold"].includes(Qt.type),$a=Qt._holding===!0;if(Qt.type!==yr&&Qt.type!=="purple"&&!Yt&&!$a){const hc=q==="evolve"?.5:1;if(te.current.shieldCount>0)te.current.shieldCount-=1,te.current.shield=te.current.shieldCount>0;else if(te.current.health=Math.max(0,te.current.health-hc),te.current.shield=!1,hn(de+1),fn(de+1),te.current.health<=0){te.current.alive=!1;const fs=Ue.current===2?de===0?Se.current.alive:ce.current.alive:!1;qn(Ue.current===1?null:fs?de===0?"p2":"p1":"tie")}te.current.streak=0}}),!te.current.alive)return;const Ne=q==="evolve"?Ek(Fe,rt,te.current.score):0;te.current.patternIdx=Ne;const bt=q==="evolve"?Jt[Ne]??Jt[0]:{cols:3,rows:3,mask:null},Ks=qe.current.active?qe.current.color:void 0,Qs=xk(Fe,te.current.health,bt,q==="evolve",Ks,Ht.current);te.current.active=Qs,te.current.cells=_l(Qs,bt),Qs.length===0&&console.warn("[DTP-010]")}),Ht.current+=1,io(O),Ht.current>60&&Ht.current%20===0&&(ce.current.alive&&(ce.current.score+=2),Ue.current===2&&Se.current.alive&&(Se.current.score+=2),Ce("🔥 Survival +2!")),Gt(),Xt("tick");const Z=ce.current.freezeEnd>z||Ue.current===2&&Se.current.freezeEnd>z,W=Ho(Ht.current,Z?1.4:1)*cs.current;Ct.current=setTimeout(pn,W)},[Gt,qn,hn,fn,Ce]),pr=D.useCallback(()=>{Wt.current==="playing"&&(Ct.current&&clearTimeout(Ct.current),$n.current=!0,us(!0))},[]),uo=D.useCallback(()=>{$n.current=!1,us(!1);const z=Date.now(),q=ce.current.freezeEnd>z||Ue.current===2&&Se.current.freezeEnd>z,O=Ho(Ht.current,q?1.4:1)*cs.current;Ct.current=setTimeout(pn,O)},[pn]),Fa=D.useCallback(()=>{if(Po().count<=0){Ce("⚡ No energy! Wait or spend 💜 dust to refill.");return}if(!Rk()){Ce("⚡ No energy!");return}I(Po()),Ct.current&&clearTimeout(Ct.current),ce.current=xr(),Se.current=xr(),Ht.current=0,ds.current=0,cs.current=1,qe.current={active:!1,color:"",cssColor:"",turnsLeft:0},$n.current=!1,cn({active:!1,color:"",cssColor:"",turnsLeft:0}),so("square"),io(0),ls(0),La(Bg()),Qe(null),Pa(o||""),Ki(!1),us(!1),cr(null),Us(null),Gt(),Wt.current="playing",T("playing"),Ct.current=setTimeout(pn,Ho(0))},[pn,Gt,Ce,o]),za=D.useCallback(()=>{Ct.current&&clearTimeout(Ct.current),$n.current=!1,ce.current=xr(),Se.current=xr(),Ht.current=0,qe.current={active:!1,color:"",cssColor:"",turnsLeft:0},cn({active:!1,color:"",cssColor:"",turnsLeft:0}),cr(null),ls(0),us(!1),Gt(),Qe(null),Wt.current="menu",T("menu")},[Gt]);D.useEffect(()=>{const z=q=>{if(q.repeat||Wt.current!=="playing"||In.current!=="keyboard")return;if(q.key==="Escape"){pr();return}const O=q.key.toLowerCase(),Z=de=>{const Fe=de===1?Oa.current:ao.current,Kt=(de===1?ce:Se).current.patternIdx,pe=Bn.current==="classic"?{cols:3,rows:3,mask:null}:Jt[Kt]??{cols:3,rows:3,mask:null},yr=pe.mask??Array.from({length:pe.cols*pe.rows},(Ne,bt)=>bt);for(const Ne of yr){const bt=Math.floor(Ne/pe.cols),Ks=Ne%pe.cols;if(Fe[bt*4+Ks]===O)return Ne}return-1},W=Z(1),te=Ue.current===2?Z(2):-1;W!==-1?(q.preventDefault(),kn(de=>new Set([...de,W])),setTimeout(()=>kn(de=>{const Fe=new Set(de);return Fe.delete(W),Fe}),150),ge(1,W)):te!==-1&&(q.preventDefault(),rs(de=>new Set([...de,te])),setTimeout(()=>rs(de=>{const Fe=new Set(de);return Fe.delete(te),Fe}),150),ge(2,te))};return window.addEventListener("keydown",z),()=>window.removeEventListener("keydown",z)},[ge,pr]),D.useEffect(()=>{const z=Z=>{const W=Z.detail;ce.current.gridStage=W,ce.current.stageProgress=0,Se.current.gridStage=W,Se.current.stageProgress=0,Gt()},q=Z=>{const W=Z.detail;ce.current.patternIdx=W,Se.current.patternIdx=W,Gt()},O=Z=>{const W=Z.detail;if(!W)qe.current={active:!1,color:"",cssColor:"",turnsLeft:0},cn({active:!1,color:"",cssColor:"",turnsLeft:0});else{const te={active:!0,color:W.color,cssColor:W.cssColor,turnsLeft:10};qe.current=te,cn(te),cr({color:W.color,cssColor:W.cssColor}),setTimeout(()=>cr(null),5e3)}};return window.addEventListener("dtp-dev-stage",z),window.addEventListener("dtp-dev-pattern",q),window.addEventListener("dtp-dev-rare",O),()=>{window.removeEventListener("dtp-dev-stage",z),window.removeEventListener("dtp-dev-pattern",q),window.removeEventListener("dtp-dev-rare",O)}},[Gt]);const Ua=D.useCallback(async()=>{const z=o||ir.trim()||"Player",q=ku(z),O=b==="classic"?e_:t_,Z=Ue.current===1?ce.current.score:Math.max(ce.current.score,Se.current.score),W={score:Z,initials:q,date:new Date().toLocaleDateString(),mode:b};mk(O,Z,q),Ki(!0);try{await JS(W)}catch{}},[o,ir,b]),co=D.useCallback(()=>{var q,O,Z;if(/Mobi|Android|iPhone|iPad/i.test(navigator.userAgent)||window.innerWidth<=768){ne(W=>!W);return}document.fullscreenElement?((Z=document.exitFullscreen)==null||Z.call(document),ne(!1)):(O=(q=document.documentElement).requestFullscreen)==null||O.call(q).then(()=>ne(!0)).catch(()=>{console.warn("[DTP-008]"),ne(W=>!W)})},[]),mr=D.useCallback(()=>{const z=vh();if(z<pi)return;const q=z-pi;np(q),m(q);const O=rp(),Z={count:Math.min(Fn,O.count+1),lastRegen:O.count>=Fn-1?Date.now():O.lastRegen};sp(Z),I(Z),Ce("⚡ Energy refilled!")},[Ce]),An=zk(or),ho=or!=="none",Rt=E===2,Ws=Pe==="keyboard",Ba=_e.freezeEnd>Date.now()||ar.freezeEnd>Date.now(),Gs=_==="playing"||_==="gameover",gr=Rt?"clamp(42px, 10.5vw, 60px)":"clamp(52px, min(16vw,16vh), 80px)",cc=nt.active?{background:`radial-gradient(circle, ${nt.cssColor}bb, ${nt.cssColor}22)`}:{},dc={"--theme-purple":F.colors.purple,"--theme-accent":F.colors.accent};return p.jsxs(p.Fragment,{children:[p.jsx("style",{children:Hk}),!s&&p.jsx(Bk,{progress:t,done:n,showNameEntry:u,onNameSubmit:B}),s&&p.jsxs("div",{className:`root${Rt?" root--2p":""}${Na==="light"?" light-theme":""}`,style:{"--cell-1p":gr,...dc},children:[p.jsx("div",{className:"bg-pulse",style:nt.active?{background:`radial-gradient(ellipse at 50% 30%, ${nt.cssColor}44 0%, transparent 65%)`,opacity:1}:{}}),p.jsx("div",{className:"orb orb-1",style:nt.active?cc:{}}),p.jsx("div",{className:"orb orb-2"}),p.jsx("div",{className:"orb orb-3"}),p.jsx(Fk,{}),ie&&p.jsx("div",{className:"toast",children:ie}),ts&&p.jsx(Ok,{onDismiss:()=>{Yg(()=>localStorage.setItem(zg,"1")),Da(!1)}}),dn&&p.jsx("div",{className:"rare-splash",children:p.jsxs("span",{className:"rare-splash-text",style:{color:dn.cssColor,textShadow:`0 0 60px ${dn.cssColor}, 0 0 120px ${dn.cssColor}66`},children:["DON'T",p.jsx("br",{}),"TOUCH",p.jsx("br",{}),dn.color.toUpperCase(),"!"]})}),Va&&p.jsx(jk,{colorblindMode:or,setColorblindMode:ac,theme:Na,setTheme:Qi,muted:je,setMuted:H,isFS:Y,toggleFS:co,onClose:()=>Ji(!1)}),w&&p.jsx(Uk,{p1:_e,p2:ar,tick:qs,gameMode:b,numPlayers:E,rareMode:nt,cellShape:ur,paused:ja,screen:_,onClose:()=>y(!1)}),ja&&p.jsx("div",{className:"pause-overlay",children:p.jsxs("div",{className:"pause-card",children:[p.jsx("div",{className:"pause-title",children:"⏸ PAUSED"}),p.jsxs("div",{className:"pause-score",children:["Score: ",p.jsxs("strong",{children:[_e.score,Rt?` · ${ar.score}`:""]})]}),p.jsx("button",{className:"btn-play",onClick:uo,children:"▶ RESUME"}),p.jsxs("div",{className:"pause-settings-row",children:[p.jsxs("button",{className:"pause-setting-btn",onClick:()=>H(z=>!z),title:"Sound",children:[je?"🔇":"🔊",p.jsx("span",{children:je?"Muted":"Sound On"})]}),p.jsxs("button",{className:"pause-setting-btn",onClick:co,title:"Fullscreen",children:[Y?"⊡":"⊞",p.jsx("span",{children:Y?"Exit FS":"Fullscreen"})]}),p.jsxs("button",{className:"pause-setting-btn",onClick:()=>{uo(),setTimeout(()=>Ji(!0),100)},title:"Settings",children:["⚙",p.jsx("span",{children:"Settings"})]})]}),p.jsx("button",{className:"btn-ghost",style:{width:"100%",textAlign:"center"},onClick:za,children:"🏠 Exit to Menu"}),p.jsx("div",{style:{fontSize:11,color:"var(--muted)",textAlign:"center",fontFamily:"var(--font-ui)"},children:"Exiting will end your current game"})]})}),p.jsxs("header",{className:`hdr${Y?" hdr--hidden":""}`,children:[p.jsxs("span",{className:"logo",children:["Don't Touch the"," ",p.jsx("span",{className:"txt-p",style:nt.active?{color:nt.cssColor,textShadow:`0 0 20px ${nt.cssColor}99`,transition:"color 0.5s, text-shadow 0.5s"}:{},children:nt.active?nt.color.charAt(0).toUpperCase()+nt.color.slice(1):"Purple"})]}),p.jsxs("div",{className:"hdr-right",style:{display:"flex",alignItems:"center",gap:8},children:[p.jsx(Vk,{dust:f}),Gs&&_==="playing"?p.jsx("button",{className:"btn-icon btn-icon--pause",onClick:pr,title:"Pause",children:"⏸"}):p.jsx("button",{className:"btn-icon",onClick:()=>Ji(z=>!z),title:"Settings",children:"⚙"})]})]}),Y&&p.jsx("div",{className:"fs-pulldown",onClick:co,title:"Exit fullscreen",children:p.jsx("span",{className:"fs-pulldown-chevron",children:"⌄"})}),Y&&Gs&&p.jsx("div",{className:"fs-controls",children:_==="playing"&&p.jsx("button",{className:"btn-icon btn-icon--pause",onClick:pr,children:"⏸"})}),_==="leaderboard"&&p.jsx(Ck,{mode:qt,onClose:()=>T("menu")}),_==="howto"&&p.jsx(Dk,{onClose:()=>T("menu")}),_==="keybind"&&p.jsx(Mk,{initP1:os,initP2:as,numPlayers:E,onSave:(z,q)=>{Yg(()=>{Hg(Og,z),Hg(Fg,q)}),lr(z),uc(q),T("menu")},onCancel:()=>T("menu")}),_==="shop"&&p.jsx(Nk,{dust:f,onDustChange:z=>{m(z),V(_h())},onClose:()=>T("menu")}),_==="menu"&&p.jsxs("div",{className:"menu-card screen-slide",children:[p.jsxs("div",{className:"player-name-row",children:[p.jsxs("span",{className:"player-name-lbl",children:["👤 ",o||"Guest"]}),p.jsx("button",{className:"btn-link",style:{fontSize:11,padding:"2px 8px"},onClick:()=>x(!0),children:"Switch Player"})]}),S&&(()=>{const z=()=>{const[q,O]=D.useState(o||""),Z=()=>{const W=ku(q.trim())||"Player";try{localStorage.setItem(To,W)}catch{}l(W),x(!1)};return p.jsx("div",{className:"overlay",onClick:()=>x(!1),children:p.jsxs("div",{className:"glass-panel",onClick:W=>W.stopPropagation(),children:[p.jsx("h2",{style:{fontFamily:"var(--font-game)",fontSize:20,marginBottom:4,color:"var(--text)"},children:"Switch Player"}),p.jsx("p",{style:{fontSize:12,color:"var(--muted)",fontFamily:"var(--font-ui)",marginBottom:16},children:"Enter a name for this device's player"}),p.jsx("input",{className:"go-input",maxLength:8,placeholder:"Name (8 chars max)",autoFocus:!0,value:q,style:{width:"100%",marginBottom:14},onChange:W=>O(W.target.value.replace(/[^a-zA-Z0-9_ ]/g,"").slice(0,8)),onKeyDown:W=>W.key==="Enter"&&Z()}),p.jsxs("div",{style:{display:"flex",gap:8},children:[p.jsx("button",{className:"btn-ghost",style:{flex:1},onClick:()=>x(!1),children:"Cancel"}),p.jsx("button",{className:"btn-primary",style:{flex:1,padding:"10px"},onClick:Z,children:"Save"})]})]})})};return p.jsx(z,{})})(),p.jsx(Pk,{energy:A,nextRegenMs:Iu(),onRefill:mr,dust:f}),p.jsxs("div",{className:"menu-header",children:[p.jsxs("h1",{className:"menu-title",children:["Don't Touch the ",p.jsx("span",{className:"txt-p",children:"Purple"})]}),p.jsx("p",{className:"menu-sub",children:"⚡ Tap fast. Avoid purple. Survive."})]}),p.jsxs("div",{className:"opt-grid",children:[p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"🎮 Game Mode"}),p.jsx(Ts,{options:[{value:"classic",label:"⊞ Classic"},{value:"evolve",label:"∞ Evolve"}],value:b,onChange:C})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"👥 Players"}),p.jsx(Ts,{options:[{value:1,label:"Solo"},{value:2,label:"Duo"}],value:E,onChange:J})]}),p.jsxs("div",{className:"opt-section",children:[p.jsx("div",{className:"opt-label",children:"🕹 Input"}),p.jsx(Ts,{options:[{value:"touch",label:"👆 Touch"},{value:"keyboard",label:"⌨ Keys"}],value:Pe,onChange:Et})]})]}),A>0?p.jsx("button",{className:"btn-play",onClick:Fa,children:"▶ PLAY!"}):p.jsxs("div",{className:"no-energy-block",children:[p.jsx("div",{className:"no-energy-txt",children:"⚡ No energy"}),p.jsx(qk,{nextRegenMs:Iu()}),f>=pi&&p.jsxs("button",{className:"btn-ghost",style:{marginTop:8,fontSize:13},onClick:mr,children:["💜 Spend ",pi," dust to refill"]})]}),p.jsxs("div",{className:"menu-links",children:[p.jsx("button",{className:"btn-link",onClick:()=>T("howto"),children:"❓ How to Play"}),p.jsx("button",{className:"btn-link",onClick:()=>{es(b),T("leaderboard")},children:"🏆 Leaderboard"}),p.jsx("button",{className:"btn-link",onClick:()=>T("shop"),children:"🛒 Shop"}),Ws&&p.jsx("button",{className:"btn-link",onClick:()=>T("keybind"),children:"⌨ Keys"})]})]}),Gs&&p.jsxs(p.Fragment,{children:[!Rt&&p.jsxs("div",{className:"hud",children:[p.jsxs("div",{className:"hud-card hud-card--score",children:[p.jsx("div",{className:"hud-lbl",children:"Score"}),p.jsxs("div",{className:"hud-score-row",children:[p.jsx("div",{className:"hud-val",children:_e.score}),_e.streak>=3&&p.jsxs("div",{className:"combo-wrap",children:["×",_e.streak]})]})]}),p.jsxs("div",{className:"hud-card",children:[p.jsx("div",{className:"hud-lbl",children:"Best"}),p.jsx("div",{className:"hud-val",children:ro})]}),p.jsxs("div",{className:"hud-card",children:[p.jsx("div",{className:"hud-lbl",children:"Speed"}),p.jsx("div",{className:"hud-val hud-val--sm",children:vk(qs,Ba)})]}),p.jsx("div",{className:"hud-card hud-card--hearts",children:p.jsx(c_,{health:_e.health,anim:Zi,shieldCount:_e.shieldCount})})]}),p.jsx("div",{className:"spd-wrap",children:p.jsx("div",{className:"spd-track",children:p.jsx("div",{className:"spd-fill",style:{width:_k(qs)+"%"}})})}),!Rt&&p.jsxs("div",{className:"pwr-zone pwr-zone--1p",children:[p.jsx(d_,{shield:_e.shield,freezeEnd:_e.freezeEnd,multiplierEnd:_e.multiplierEnd}),(_e.storedFreezeCharges>0||_e.storedShieldCharges>0)&&_==="playing"&&p.jsxs("div",{className:"stored-pwr-btns",children:[_e.storedFreezeCharges>0&&p.jsxs("button",{className:"stored-pwr-btn stored-pwr-btn--freeze",onClick:()=>{ce.current.freezeEnd=Date.now()+15e3,ce.current.storedFreezeCharges=Math.max(0,(ce.current.storedFreezeCharges??1)-1),Sn({...ce.current}),Ce("❄ Freeze activated!"),Xt("powerup")},children:["❄ ×",_e.storedFreezeCharges]}),_e.storedShieldCharges>0&&p.jsxs("button",{className:"stored-pwr-btn stored-pwr-btn--shield",onClick:()=>{ce.current.shieldCount+=ce.current.storedShieldCharges??0,ce.current.shield=!0,ce.current.storedShieldCharges=0,Sn({...ce.current}),Ce(`🛡 Shield ×${ce.current.shieldCount} activated!`),Xt("powerup")},children:["◈ ×",_e.storedShieldCharges]})]}),zs&&p.jsxs("div",{className:"levelup-badge",children:["🔥 ",zs]})]}),p.jsxs("div",{className:"game-area",children:[_==="gameover"&&p.jsx("div",{className:"go-overlay",children:ln?p.jsx(Lk,{score:_e.score,mode:b,onClose:()=>be(!1)}):p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"go-eyebrow",children:Rt?"ROUND OVER":"GAME OVER"}),Rt?p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"go-winner",children:no==="p1"?"🏆 P1 Wins!":no==="p2"?"🏆 P2 Wins!":"🤝 Tie!"}),p.jsxs("div",{className:"go-pair",children:[p.jsxs("div",{className:"go-col",children:[p.jsx("div",{className:"go-plbl",style:{color:"#60a5fa"},children:"P1"}),p.jsx("div",{className:"go-score",children:_e.score})]}),p.jsx("div",{className:"go-sep"}),p.jsxs("div",{className:"go-col",children:[p.jsx("div",{className:"go-plbl",style:{color:"#f472b6"},children:"P2"}),p.jsx("div",{className:"go-score",children:ar.score})]})]})]}):p.jsxs(p.Fragment,{children:[p.jsx("div",{className:"go-num",children:_e.score}),p.jsxs("div",{className:"go-best",children:["Best: ",ro]}),p.jsxs("div",{className:"go-msg",children:['"',un,'"']}),_e.score>0&&p.jsxs("div",{className:"go-dust-earned",children:["+",_e.score," 💜 dust earned!"]}),oc?p.jsx("div",{className:"go-lb-saved",children:"✓ Saved!"}):p.jsxs("div",{className:"go-lb-form",children:[p.jsx("input",{className:"go-input",maxLength:8,placeholder:"Your name",value:ir,onChange:z=>Pa(z.target.value.replace(/[^a-zA-Z0-9_ ]/g,"").slice(0,8)),onKeyDown:z=>z.key==="Enter"&&Ua()}),p.jsx("button",{className:"btn-primary btn-sm",onClick:Ua,children:"Save"})]})]}),p.jsxs("div",{className:"go-btns",children:[p.jsx("button",{className:"btn-primary",onClick:Fa,children:"▶ Again"}),p.jsx("button",{className:"btn-ghost",onClick:()=>be(!0),children:"📤 Share"}),p.jsx("button",{className:"btn-ghost",onClick:za,children:"🏠 Menu"})]}),p.jsx("a",{className:"go-bug-btn",href:`mailto:hello@mscarabia.com?subject=DTP Bug Report (Seed: ${dr})&body=Score: ${_e.score}%0AMode: ${b}%0ASeed: ${dr}%0A%0ADescribe the bug:%0A`,target:"_blank",rel:"noopener",children:"🐛 Report a Bug"})]})}),p.jsx(Gg,{ps:_e,anim:_e.anim,onTap:z=>ge(1,z),onHoldStart:z=>hs(1,z),onHoldEnd:z=>fr(1,z),keyLabels:os,showKeys:Ws,pressing:to,label:Rt?"P1":null,heartAnim:Zi,mode:b,colorblind:ho,cbFilter:An,is2P:Rt,shakeGrid:Yi,cellShape:ur,rareMode:nt,onPause:pr,isFS:Y,spinLevel:oo,gameSeed:dr}),Rt&&p.jsx(Gg,{ps:ar,anim:ar.anim,onTap:z=>ge(2,z),onHoldStart:z=>hs(2,z),onHoldEnd:z=>fr(2,z),keyLabels:as,showKeys:Ws,pressing:Ma,label:"P2",heartAnim:ns,mode:b,colorblind:ho,cbFilter:An,is2P:Rt,shakeGrid:et,cellShape:ur,rareMode:nt,onPause:pr,isFS:Y,spinLevel:oo,gameSeed:dr})]})]}),_==="menu"&&p.jsxs("footer",{className:"credit",children:[p.jsxs("span",{children:["By Mohammed Ahmed Siddiqui · ",p.jsx("a",{href:"https://mscarabia.com",target:"_blank",rel:"noopener noreferrer",className:"credit-link",children:"mscarabia.com"})]}),p.jsx("a",{href:"/privacy.html",target:"_blank",rel:"noopener noreferrer",className:"credit-link",style:{marginLeft:6},children:"Privacy"})]})]})]})}function qk({nextRegenMs:t}){const[e,n]=D.useState(t);D.useEffect(()=>{const i=setInterval(()=>n(Iu()),1e3);return()=>clearInterval(i)},[]);const r=Math.floor(e/6e4),s=Math.floor(e%6e4/1e3);return p.jsxs("div",{className:"no-energy-timer",children:["Next energy in ",r,":",String(s).padStart(2,"0")]})}const Hk=`
@import url('https://fonts.googleapis.com/css2?family=Fredoka+One&family=Nunito:wght@700;800;900&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #0d0820;
  --bg2: rgba(255,255,255,0.06);
  --bg3: rgba(255,255,255,0.11);
  --glass: rgba(255,255,255,0.05);
  --glass-border: rgba(255,255,255,0.12);
  --text: #f0eaff;
  --muted: rgba(240,234,255,0.45);
  --purple: #c026d3;
  --purple-dark: #7e22ce;
  --accent: #f0abfc;
  --cell-1p: min(clamp(52px, 14vw, 88px), clamp(52px, 12vh, 88px));
  --cell-2p: min(clamp(38px, 9vw, 62px), clamp(38px, 9vh, 62px));
  --cell: var(--cell-1p);
  --gap: 8px;
  --r: 14px;
  --panel-blur: 18px;
  --font-game: 'Fredoka One', 'Nunito', system-ui, sans-serif;
  --font-ui: 'Nunito', system-ui, sans-serif;
}

.light-theme {
  --bg: #f5f0ff;
  --bg2: rgba(100,60,180,0.08);
  --bg3: rgba(100,60,180,0.14);
  --glass: rgba(255,255,255,0.7);
  --glass-border: rgba(140,90,210,0.22);
  --text: #1a0a2e;
  --muted: rgba(60,20,100,0.55);
  --purple: #7c3aed;
  --purple-dark: #5b21b6;
  --accent: #a855f7;
}

/* Light theme body overrides */
.light-theme body,
.light-theme .root {
  background: none;
}
.light-theme body {
  background: radial-gradient(ellipse at 20% 10%, #d8c8ff 0%, #f5f0ff 55%),
              radial-gradient(ellipse at 80% 90%, #e8d4ff 0%, transparent 55%);
}

/* Cards/panels in light mode */
.light-theme .menu-card {
  background: rgba(255,255,255,0.75);
  border-color: rgba(140,90,210,0.25);
}
.light-theme .hud-card {
  background: rgba(255,255,255,0.75);
  border-color: rgba(140,90,210,0.22);
}
.light-theme .hud-val {
  background: linear-gradient(135deg, #2d0a5e 0%, #7c3aed 100%);
  -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
}
.light-theme .hud-card--score .hud-val {
  background: linear-gradient(135deg, #1a0a2e 0%, #7c3aed 50%, #a855f7 100%);
  -webkit-background-clip: text; background-clip: text;
}
.light-theme .go-overlay {
  background: rgba(240,230,255,0.96);
}
.light-theme .go-num {
  background: linear-gradient(135deg, #1a0a2e 0%, #7c3aed 50%, #a855f7 100%);
  -webkit-background-clip: text; background-clip: text;
}
.light-theme .gpanel {
  background: rgba(255,255,255,0.55);
  border-color: rgba(140,90,210,0.2);
  box-shadow: 0 0 0 1px rgba(140,90,210,0.06) inset, 0 20px 40px rgba(100,60,180,0.15);
}
.light-theme .cell.inactive {
  background: rgba(140,90,210,0.08);
  border-color: rgba(140,90,210,0.15);
}
.light-theme .pause-card {
  background: rgba(255,255,255,0.95);
  border-color: rgba(140,90,210,0.3);
}
.light-theme .pause-score { color: var(--muted); }
.light-theme .btn-ghost {
  background: rgba(140,90,210,0.1);
  border-color: rgba(140,90,210,0.2);
  color: var(--text);
}
.light-theme .btn-ghost:hover { background: rgba(140,90,210,0.18); }
.light-theme .btn-icon { color: var(--text); background: rgba(140,90,210,0.1); border-color: rgba(140,90,210,0.2); }
.light-theme .btn-link { color: var(--muted); }
.light-theme .btn-link:hover { color: var(--text); }
.light-theme .opt-btn { background: rgba(140,90,210,0.08); border-color: rgba(140,90,210,0.18); color: var(--muted); }
.light-theme .pill-row { background: rgba(140,90,210,0.08); border-color: rgba(140,90,210,0.18); }
.light-theme .pill-opt { color: var(--muted); }
.light-theme .pill-opt--on { color: #fff; }
.light-theme .toast { background: rgba(240,230,255,0.97); border-color: rgba(124,58,237,0.4); color: var(--text); }
.light-theme .go-msg,
.light-theme .go-best { color: var(--muted); }
.light-theme .spd-track { background: rgba(140,90,210,0.12); }
.light-theme .logo { color: var(--text); }
.light-theme .pwr-zone { background: rgba(255,255,255,0.4); border-color: rgba(140,90,210,0.12); }
.light-theme .phud-score {
  background: linear-gradient(135deg, #1a0a2e 0%, #7c3aed 100%);
  -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
}
.light-theme .lb-row { background: rgba(255,255,255,0.7); }
.light-theme .how-row { background: rgba(255,255,255,0.7); }
.light-theme .go-input { background: rgba(255,255,255,0.8); color: var(--text); }
.light-theme .share-inner { background: rgba(255,255,255,0.8); }
.light-theme .share-url { color: var(--muted); }
.light-theme .share-social--copy { background: rgba(140,90,210,0.1); color: var(--text); border-color: rgba(140,90,210,0.2); }
.light-theme .kb-panel { background: #f5f0ff; color: var(--text); }
.light-theme .kb-cell { background: rgba(140,90,210,0.1); border-color: rgba(140,90,210,0.2); color: var(--text); }
.light-theme .kb-cell--on { background: var(--purple); color: #fff; border-color: var(--purple); }
.light-theme .pwr-chip--shield { background: linear-gradient(135deg,#0e7490,#06b6d4); }
.light-theme .pwr-chip--freeze { background: linear-gradient(135deg,#1d4ed8,#60a5fa); }
.light-theme .pwr-chip--mult   { background: linear-gradient(135deg,#c2410c,#f97316); }
.light-theme .pause-settings-row .pause-setting-btn { background: rgba(140,90,210,0.1); border-color: rgba(140,90,210,0.2); color: var(--text); }
.light-theme .pause-settings-row .pause-setting-btn:hover { background: rgba(140,90,210,0.2); }

html, body { height: 100%; background: var(--bg); overflow: hidden; touch-action: none; }
body {
  font-family: var(--font-ui);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  background: radial-gradient(ellipse at 20% 10%, #2d1060 0%, #0d0820 55%),
              radial-gradient(ellipse at 80% 90%, #1a0a3e 0%, transparent 55%);
  user-select: none;
}

/* ── Root layout ── */
.root {
  display: flex; flex-direction: column; align-items: center;
  width: 100%; max-width: 520px; margin: 0 auto;
  padding: 8px 10px 12px; min-height: 100dvh; gap: 8px;
  position: relative; z-index: 10; overflow: hidden;
}
.root--2p { --cell: var(--cell-2p); }

/* ── Background orbs ── */
.bg-pulse {
  position: fixed; inset: 0; z-index: -1; pointer-events: none;
  background: radial-gradient(circle at 50% 50%, var(--purple) 0%, transparent 60%);
  opacity: 0.04; transition: opacity 0.8s, background 1s;
}
.orb {
  position: fixed; border-radius: 50%; filter: blur(80px);
  z-index: -2; pointer-events: none;
}
.orb-1 {
  width: 480px; height: 480px; opacity: 0.20;
  background: radial-gradient(circle at 35% 35%, #e879f9, #7c3aed 55%, #4c1d95);
  top: calc(50% - 240px); left: calc(50% - 240px);
  animation: orbFloat1 20s ease-in-out infinite;
  transition: background 1s;
}
.orb-2 {
  width: 320px; height: 320px; opacity: 0.12;
  background: radial-gradient(circle at 60% 40%, #60a5fa, #2563eb);
  top: calc(50% - 160px); left: calc(50% - 160px);
  animation: orbFloat2 14s ease-in-out infinite;
}
.orb-3 {
  width: 240px; height: 240px; opacity: 0.10;
  background: radial-gradient(circle at 50% 30%, #f9a8d4, #be185d);
  top: calc(50% - 120px); left: calc(50% - 120px);
  animation: orbFloat3 10s ease-in-out infinite;
}
@keyframes orbFloat1 {
  0%,100% { transform: translate(-140px,-160px) scale(1); }
  25%  { transform: translate(160px,-120px) scale(1.08); }
  50%  { transform: translate(120px,160px) scale(0.96); }
  75%  { transform: translate(-160px,120px) scale(1.04); }
}
@keyframes orbFloat2 {
  0%,100% { transform: translate(160px,80px) scale(1); }
  33%  { transform: translate(-80px,140px) scale(1.1); }
  66%  { transform: translate(-140px,-80px) scale(0.9); }
}
@keyframes orbFloat3 {
  0%,100% { transform: translate(60px,-120px) scale(1); }
  50%  { transform: translate(-120px,80px) scale(1.15); }
}
@keyframes orbFloat {
  0%,100% { transform: translate(0,0) scale(1); }
  33%  { transform: translate(-30px, 20px) scale(1.05); }
  66%  { transform: translate(20px,-15px) scale(0.97); }
}

/* ── Rare color splash ── */
.rare-splash {
  position: fixed; inset: 0; z-index: 999; pointer-events: none;
  display: flex; align-items: center; justify-content: center;
  animation: rareSplashAnim 5s cubic-bezier(0.22,1,0.36,1) forwards;
}
.rare-splash-text {
  font-family: var(--font-game);
  font-size: clamp(36px, 12vw, 72px);
  font-weight: 900; text-align: center; line-height: 1.1;
  text-transform: uppercase; letter-spacing: 2px;
  animation: rareSplashText 5s cubic-bezier(0.22,1,0.36,1) forwards;
}
@keyframes rareSplashAnim {
  0%   { background: rgba(0,0,0,0.75); }
  15%  { background: rgba(0,0,0,0.6); }
  60%  { background: rgba(0,0,0,0.35); }
  85%  { background: rgba(0,0,0,0.1); }
  100% { background: rgba(0,0,0,0); opacity: 0; }
}
@keyframes rareSplashText {
  0%   { transform: scale(0.1) rotate(-10deg); opacity: 0; }
  12%  { transform: scale(1.15) rotate(2deg);  opacity: 1; }
  25%  { transform: scale(1) rotate(0deg); }
  70%  { transform: scale(1) rotate(0deg); opacity: 1; }
  100% { transform: scale(1.6) rotate(5deg); opacity: 0; }
}

/* ── Screen shake ── */
.shake-screen { animation: screenShake 0.45s cubic-bezier(.36,.07,.19,.97) both; }
@keyframes screenShake {
  0%,100% { transform: translate(0,0) rotate(0deg); }
  15%  { transform: translate(-6px, 4px) rotate(-0.4deg); }
  30%  { transform: translate(6px,-4px) rotate(0.4deg); }
  45%  { transform: translate(-8px, 5px) rotate(-0.5deg); }
  60%  { transform: translate(8px,-5px) rotate(0.5deg); }
  75%  { transform: translate(4px,-3px) rotate(0.2deg); }
  90%  { transform: translate(-3px, 2px) rotate(-0.1deg); }
}

/* ── Toast ── */
.toast {
  position: fixed; top: 158px; bottom: auto;
  left: 50%; transform: translateX(-50%);
  background: rgba(15,8,35,0.97); border: 2px solid rgba(192,38,211,0.5);
  backdrop-filter: blur(20px); border-radius: 99px;
  padding: 9px 24px; font-family: var(--font-game); font-size: 15px;
  color: var(--text); z-index: 500; white-space: nowrap;
  animation: toastIn 0.3s cubic-bezier(0.22,1,0.36,1);
  pointer-events: none;
  box-shadow: 0 4px 24px rgba(192,38,211,0.35);
}
@keyframes toastIn { from { opacity:0; transform: translateX(-50%) translateY(-10px) scale(0.9); } }

/* ── Header ── */
.hdr {
  width: 100%; display: flex; align-items: center; justify-content: space-between;
  transition: height 0.3s, opacity 0.3s; min-height: 44px;
}
.hdr--hidden { height: 0 !important; overflow: hidden; opacity: 0; pointer-events: none; min-height: 0; }
.logo {
  font-family: var(--font-game); font-size: 16px; letter-spacing: 0.3px;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
}
.txt-p {
  color: var(--purple); text-shadow: 0 0 20px rgba(192,38,211,0.6);
  transition: color 0.5s, text-shadow 0.5s;
}
.hdr-right { display: flex; gap: 6px; }

/* ── Fullscreen floating controls ── */
.fs-controls {
  position: fixed; top: 10px; right: 10px; z-index: 600;
  display: flex; gap: 6px; flex-direction: column;
}

/* ── Fullscreen pull-down tab — tap to restore header ── */
.fs-pulldown {
  position: fixed; top: 0; left: auto; right: 16px; transform: none;
  z-index: 601; cursor: pointer;
  background: linear-gradient(180deg, rgba(45,16,96,0.92), rgba(13,8,32,0.85));
  border: 2px solid rgba(192,38,211,0.35); border-top: none;
  border-radius: 0 0 18px 18px;
  padding: 2px 22px 6px;
  display: flex; align-items: center; justify-content: center;
  backdrop-filter: blur(12px);
  box-shadow: 0 4px 16px rgba(0,0,0,0.4), 0 0 12px rgba(192,38,211,0.15);
  transition: padding-bottom 0.2s, box-shadow 0.2s;
  animation: pulldownIn 0.4s cubic-bezier(0.34,1.56,0.64,1);
}
.fs-pulldown:hover { padding-bottom: 10px; box-shadow: 0 6px 24px rgba(0,0,0,0.5), 0 0 18px rgba(192,38,211,0.3); }
.fs-pulldown:active { transform: scale(0.96); }
@keyframes pulldownIn { from { transform: translateY(-100%); } to { transform: translateY(0); } }
.fs-pulldown-chevron {
  font-size: 20px; color: var(--accent); line-height: 1;
  animation: chevronBounce 1.8s ease-in-out infinite;
  display: block;
}
@keyframes chevronBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(3px)} }

/* ── Icon buttons ── */
.btn-icon {
  background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15);
  border-radius: 12px; width: 38px; height: 38px; font-size: 16px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  color: var(--text); transition: all 0.15s ease;
  backdrop-filter: blur(10px); box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}
.btn-icon:hover, .btn-icon:active { background: rgba(192,38,211,0.25); border-color: var(--purple); transform: scale(0.95); }

/* ── Pause inline button (in HUD / 2P panel) ── */
.btn-pause-inline {
  background: rgba(255,255,255,0.08); border: 2px solid rgba(255,255,255,0.15);
  border-radius: 10px; width: 34px; height: 34px; font-size: 14px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  color: var(--text); transition: all 0.15s; flex-shrink: 0;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3);
}
.btn-pause-inline:active { transform: scale(0.9); background: rgba(192,38,211,0.3); }

/* ── Pause overlay ── */
.pause-overlay {
  position: fixed; inset: 0; z-index: 800;
  background: rgba(5,2,18,0.85); backdrop-filter: blur(14px);
  display: flex; align-items: center; justify-content: center; padding: 20px;
  animation: fadeIn 0.25s ease;
}
.pause-card {
  background: linear-gradient(145deg, rgba(45,16,96,0.9), rgba(13,8,32,0.95));
  border: 2px solid rgba(192,38,211,0.4); border-radius: 28px;
  padding: 32px 28px; width: 100%; max-width: 340px;
  display: flex; flex-direction: column; gap: 16px; align-items: center;
  box-shadow: 0 0 60px rgba(192,38,211,0.2), 0 32px 64px rgba(0,0,0,0.5);
}
.pause-title {
  font-family: var(--font-game); font-size: 32px; letter-spacing: 2px;
  background: linear-gradient(135deg, #f0abfc, #c026d3);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.pause-score { font-family: var(--font-ui); font-size: 14px; color: var(--muted); }

/* ── Settings Drawer ── */
.drawer-overlay {
  position: fixed; inset: 0; z-index: 700;
  background: rgba(0,0,0,0.5); backdrop-filter: blur(6px);
  display: flex; align-items: flex-start; justify-content: flex-end;
}
.drawer-panel {
  width: 290px; height: 100%; max-height: 100dvh; overflow-y: auto;
  background: linear-gradient(180deg, #1a0a3e 0%, #0d0820 100%);
  border-left: 2px solid rgba(192,38,211,0.3);
  padding: 24px 18px; display: flex; flex-direction: column; gap: 22px;
  box-shadow: -20px 0 60px rgba(0,0,0,0.6);
  animation: slideInRight 0.28s cubic-bezier(0.22,1,0.36,1);
}
.light-theme .drawer-panel { background: linear-gradient(180deg, #f0e8ff, #e8d8ff); border-left-color: rgba(124,58,237,0.3); }
@keyframes slideInRight { from { transform: translateX(100%); } }
.drawer-header { display: flex; align-items: center; justify-content: space-between; }
.drawer-title { font-family: var(--font-game); font-size: 18px; color: var(--accent); }

/* ── Menu card ── */
.menu-card {
  width: 100%;
  background: linear-gradient(145deg, rgba(45,16,96,0.7), rgba(13,8,32,0.8));
  border: 2px solid rgba(192,38,211,0.25); border-radius: 28px; padding: 24px;
  backdrop-filter: blur(var(--panel-blur)) saturate(160%);
  display: flex; flex-direction: column; gap: 20px;
  box-shadow: 0 0 0 1px rgba(255,255,255,0.04) inset, 0 32px 64px rgba(0,0,0,0.5), 0 0 40px rgba(192,38,211,0.08);
}
.menu-header { display: flex; flex-direction: column; gap: 4px; }
.menu-title {
  font-family: var(--font-game); font-size: clamp(26px, 8vw, 42px);
  line-height: 1.05; letter-spacing: 0.5px;
  text-shadow: 0 3px 12px rgba(0,0,0,0.5), 0 0 30px rgba(192,38,211,0.2);
}
.menu-sub { font-size: 13px; color: var(--muted); font-weight: 700; letter-spacing: 0.3px; }
.menu-links { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }

/* ── Buttons ── */
.btn-play {
  width: 100%;
  background: linear-gradient(135deg, #a21caf, #c026d3, #7c3aed);
  color: #fff; border: none; border-radius: 16px; padding: 16px;
  font-family: var(--font-game); font-size: 18px; letter-spacing: 1px;
  cursor: pointer; transition: all 0.18s;
  box-shadow: 0 6px 0 #6b21a8, 0 8px 24px rgba(192,38,211,0.4);
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}
.btn-play:hover { transform: translateY(-2px); box-shadow: 0 8px 0 #6b21a8, 0 12px 32px rgba(192,38,211,0.5); }
.btn-play:active { transform: translateY(3px); box-shadow: 0 3px 0 #6b21a8, 0 6px 16px rgba(192,38,211,0.3); }

.btn-primary {
  background: linear-gradient(135deg, #9333ea, #c026d3);
  color: #fff; border: none; border-radius: 14px; padding: 12px 20px;
  font-family: var(--font-game); font-size: 15px; cursor: pointer;
  box-shadow: 0 4px 0 #6b21a8, 0 6px 16px rgba(192,38,211,0.35);
  transition: all 0.15s;
}
.btn-primary:hover { transform: translateY(-1px); }
.btn-primary:active { transform: translateY(2px); box-shadow: 0 2px 0 #6b21a8; }
.btn-sm { padding: 9px 14px; font-size: 13px; }

.btn-ghost {
  background: rgba(255,255,255,0.07); border: 2px solid rgba(255,255,255,0.12);
  color: var(--text); padding: 10px 18px; border-radius: 14px;
  font-family: var(--font-game); font-size: 14px; cursor: pointer; transition: all 0.15s;
  box-shadow: 0 3px 0 rgba(0,0,0,0.3);
}
.btn-ghost:hover { background: rgba(255,255,255,0.12); transform: translateY(-1px); }
.btn-ghost:active { transform: translateY(2px); box-shadow: none; }

.btn-link {
  background: none; border: none; color: var(--muted); font-family: var(--font-ui);
  font-size: 13px; font-weight: 800; cursor: pointer; padding: 4px 10px;
  border-radius: 8px; transition: color 0.15s;
}
.btn-link:hover { color: var(--text); }

/* ── Options ── */
.opt-grid { display: flex; flex-direction: column; gap: 12px; width: 100%; }
.opt-section { display: flex; flex-direction: column; gap: 6px; }
.opt-label { font-family: var(--font-ui); font-size: 10px; font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; color: var(--muted); }
.opt-row { display: flex; gap: 6px; }
.opt-btn {
  flex: 1; padding: 9px 6px; background: var(--bg2); border: 2px solid var(--glass-border);
  border-radius: 10px; color: var(--muted); font-family: var(--font-ui); font-size: 13px;
  font-weight: 800; cursor: pointer; transition: all 0.15s;
}
.opt-btn--on { background: var(--purple); color: #fff; border-color: var(--purple); box-shadow: 0 3px 0 var(--purple-dark); }

/* ── Pill toggle ── */
.pill-row { position: relative; display: flex; background: var(--bg2); border: 2px solid var(--glass-border); border-radius: 14px; padding: 3px; }
.pill-thumb {
  position: absolute; top: 3px; bottom: 3px;
  background: linear-gradient(135deg, var(--purple), var(--purple-dark));
  border-radius: 11px; box-shadow: 0 3px 0 var(--purple-dark), 0 4px 12px rgba(192,38,211,0.4);
  transition: left 0.2s cubic-bezier(0.34,1.56,0.64,1), width 0.2s; pointer-events: none; z-index: 0;
}
.pill-opt {
  flex: 1; position: relative; z-index: 1; padding: 8px 4px;
  border: none; background: transparent; font-family: var(--font-ui); font-size: 12px;
  font-weight: 800; cursor: pointer; border-radius: 11px; color: var(--muted);
  transition: color 0.18s; text-align: center; white-space: nowrap;
}
.pill-opt--on { color: #fff; text-shadow: 0 1px 4px rgba(0,0,0,0.4); }

/* ── HUD ── */
.hud {
  width: 100%; display: flex; gap: 7px; align-items: stretch;
}
.hud-card {
  flex: 1; background: linear-gradient(145deg, rgba(45,16,96,0.6), rgba(13,8,32,0.7));
  border: 2px solid rgba(192,38,211,0.2); border-radius: 14px; padding: 8px 10px;
  display: flex; flex-direction: column; gap: 1px;
  box-shadow: 0 3px 0 rgba(0,0,0,0.4), 0 4px 12px rgba(0,0,0,0.2);
  transition: border-color 0.3s;
}
.hud-card--hearts { display: flex; flex-direction: column; justify-content: center; gap: 3px; flex: none; }
.hud-lbl { font-family: var(--font-ui); font-size: 8px; font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; color: var(--muted); }
.hud-val {
  font-family: var(--font-game); font-size: 24px; line-height: 1; letter-spacing: -0.5px;
  font-variant-numeric: tabular-nums;
  background: linear-gradient(135deg, #f0eaff 0%, #c084fc 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.hud-val--sm { font-size: 18px; }
.hud-card--score .hud-val {
  background: linear-gradient(135deg, #fff 0%, #f0abfc 50%, #c026d3 100%);
  -webkit-background-clip: text; background-clip: text;
}

/* ── HUD score row — combo inline ── */
.hud-score-row { display: flex; align-items: center; gap: 6px; line-height: 1; flex-wrap: nowrap; }
.hud-card--score { gap: 2px; min-width: 80px; }
.hud-card--score .hud-val { font-size: 26px; }
.combo-wrap { flex-shrink: 0; }

/* ── Speed bar ── */
.spd-wrap { width: 100%; padding: 0 2px; }
.spd-track { width: 100%; height: 5px; background: rgba(255,255,255,0.08); border-radius: 99px; overflow: hidden; }
.spd-fill {
  height: 100%; border-radius: 99px;
  background: linear-gradient(90deg, #c026d3, #f0abfc, #fbbf24);
  transition: width 0.6s cubic-bezier(0.4,0,0.2,1);
  box-shadow: 0 0 10px rgba(192,38,211,0.7);
}

/* ── Game area ── */
.game-area {
  position: relative; width: 100%;
  display: flex; justify-content: center; align-items: center;
  gap: 16px; flex: 1; min-height: 0;
  /* Extra top padding so a spinning evolve grid never clips the HUD/speed bar */
  padding-top: 8px;
}

/* Duo mode side-by-side layout is handled above */

/* gpanel gets overflow-visible so spin doesn't clip to panel bounds */
.gpanel { overflow: visible; }

/* Wrapper that keeps the rotating gpanel from affecting document flow */
.ppanel { overflow: visible; }

/* ── Game Over overlay ── */
.go-overlay {
  position: absolute; inset: 0; z-index: 50; border-radius: 22px;
  background: rgba(5,2,18,0.92); backdrop-filter: blur(16px);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; padding: 20px; text-align: center; animation: fadeIn 0.4s ease;
}
@keyframes fadeIn { from { opacity: 0; } }
.go-eyebrow { font-family: var(--font-ui); font-size: 10px; font-weight: 900; letter-spacing: 3px; text-transform: uppercase; color: var(--muted); }
.go-num {
  font-family: var(--font-game); font-size: clamp(52px, 18vw, 76px); line-height: 1;
  letter-spacing: -2px; font-variant-numeric: tabular-nums;
  background: linear-gradient(135deg, #fff 0%, #f0abfc 50%, #c026d3 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.go-best { font-family: var(--font-ui); font-size: 13px; color: var(--muted); font-weight: 700; }
.go-msg { font-family: var(--font-ui); font-size: 12px; color: var(--muted); font-style: italic; max-width: 240px; }
.go-winner { font-family: var(--font-game); font-size: 22px; }
.go-pair { display: flex; align-items: center; gap: 16px; }
.go-col { display: flex; flex-direction: column; align-items: center; gap: 3px; }
.go-plbl { font-family: var(--font-ui); font-size: 11px; font-weight: 900; letter-spacing: 1px; text-transform: uppercase; }
.go-score { font-family: var(--font-game); font-size: 38px; }
.go-sep { width: 1px; height: 50px; background: var(--glass-border); }
.go-btns { display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; width: 100%; }
.go-lb-form { display: flex; gap: 8px; width: 100%; max-width: 300px; flex-wrap: wrap; justify-content: center; }
.go-input {
  flex: 1 1 80px; background: rgba(255,255,255,0.08); border: 2px solid rgba(192,38,211,0.3);
  border-radius: 12px; padding: 10px 12px; color: var(--text);
  font-family: var(--font-game); font-size: 18px; text-transform: uppercase;
  text-align: center; letter-spacing: 5px; outline: none;
}
.go-input:focus { border-color: var(--purple); box-shadow: 0 0 0 3px rgba(192,38,211,0.2); }
.go-lb-saved { font-family: var(--font-ui); font-size: 13px; font-weight: 900; color: #4ade80; }
.go-bug-btn {
  font-family: var(--font-ui); font-size: 11px; font-weight: 800; color: var(--muted);
  text-decoration: none; opacity: 0.55; transition: opacity 0.15s; letter-spacing: 0.3px;
  padding: 4px 10px; border-radius: 8px;
}
.go-bug-btn:hover { opacity: 1; color: var(--text); }

/* ── Player panel ── */
.ppanel { display: flex; flex-direction: column; align-items: center; gap: 8px; }
.ppanel--dead { opacity: 0.4; pointer-events: none; filter: grayscale(0.6); }
.plabel-row { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 0 4px; }
.plabel { font-family: var(--font-game); font-size: 13px; letter-spacing: 1px; text-transform: uppercase; color: var(--muted); }

/* ── 2P in-panel HUD ── */
.phud { display: flex; justify-content: space-between; align-items: center; width: 100%; padding: 0 4px; min-height: 36px; }
.phud-score {
  font-family: var(--font-game); font-size: 26px; line-height: 1; letter-spacing: -0.5px; font-variant-numeric: tabular-nums;
  background: linear-gradient(135deg, #fff 0%, #f0abfc 50%, #c026d3 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}

/* ── Hearts ── */
.hearts { display: flex; gap: 3px; }
.heart { font-size: 18px; transition: all 0.2s; line-height: 1; }
.heart--full  { color: #c026d3; filter: drop-shadow(0 0 7px rgba(192,38,211,0.7)); }
.heart--shield{ color: #60a5fa; filter: drop-shadow(0 0 8px rgba(96,165,250,0.8)); animation: shieldPulse 1s ease-in-out infinite; }
.heart--empty { color: var(--muted); opacity: 0.22; }
.heart--loss  { animation: heartPop 0.4s cubic-bezier(0.22,1,0.36,1); }
@keyframes heartPop { 0%,100%{transform:scale(1)} 50%{transform:scale(1.6)} }
@keyframes shieldPulse { 0%,100%{filter:drop-shadow(0 0 6px rgba(96,165,250,0.7))} 50%{filter:drop-shadow(0 0 12px rgba(96,165,250,1))} }

/* ── Combo — sits inside score hud-card ── */
.combo-wrap {
  font-family: var(--font-game); font-size: 11px; letter-spacing: 0.5px;
  color: #fff; background: linear-gradient(135deg, var(--purple), var(--purple-dark));
  border-radius: 20px; padding: 1px 8px; align-self: flex-start;
  box-shadow: 0 2px 0 var(--purple-dark), 0 3px 8px rgba(192,38,211,0.4);
  animation: comboPop 0.25s cubic-bezier(0.22,1,0.36,1);
}
@keyframes comboPop { 0%{transform:scale(0.5);opacity:0} 60%{transform:scale(1.15)} 100%{transform:scale(1);opacity:1} }

/* ── Power-up chips (match level-up badge style) ── */
.pwr-pills { display: flex; gap: 6px; align-items: center; flex-wrap: nowrap; justify-content: center; min-height: 26px; }
.pwr-chip {
  display: inline-flex; align-items: center; gap: 5px;
  border-radius: 99px; padding: 4px 10px 4px 7px;
  font-family: var(--font-game); font-size: 13px; font-weight: 800;
  box-shadow: 0 2px 0 rgba(0,0,0,0.3), 0 4px 10px rgba(0,0,0,0.2);
  animation: chipPop 0.25s cubic-bezier(0.22,1,0.36,1);
}
@keyframes chipPop { 0%{transform:scale(0.6);opacity:0} 60%{transform:scale(1.1)} 100%{transform:scale(1);opacity:1} }
.pwr-chip--shield { background: linear-gradient(135deg,#0e7490,#06b6d4); color:#fff; box-shadow: 0 2px 0 #164e63, 0 4px 10px rgba(6,182,212,0.4); }
.pwr-chip--freeze { background: linear-gradient(135deg,#1d4ed8,#60a5fa); color:#fff; box-shadow: 0 2px 0 #1e3a8a, 0 4px 10px rgba(96,165,250,0.4); }
.pwr-chip--mult   { background: linear-gradient(135deg,#c2410c,#f97316); color:#fff; box-shadow: 0 2px 0 #7c2d12, 0 4px 10px rgba(249,115,22,0.4); }
.pwr-chip-icon { font-size: 15px; line-height: 1; }
.pwr-chip-lbl  { font-size: 12px; letter-spacing: 0.3px; }

/* ── Level-up side badge ── */
.levelup-badge {
  display: inline-flex; align-items: center; gap: 4px;
  border-radius: 99px; padding: 4px 12px;
  background: linear-gradient(135deg, #a21caf, #c026d3);
  color: #fff; font-family: var(--font-game); font-size: 13px;
  box-shadow: 0 2px 0 #6b21a8, 0 4px 12px rgba(192,38,211,0.45);
  animation: chipPop 0.3s cubic-bezier(0.22,1,0.36,1);
}

/* ── Grid panel ── */
.gpanel {
  background: transparent; border: none; box-shadow: none;
  border-radius: 20px; padding: 6px; display: grid; gap: var(--gap);
  transform-origin: center center;
  overflow: visible;
  transition: grid-template-columns 0.35s cubic-bezier(0.34,1.56,0.64,1),
              grid-template-rows 0.35s cubic-bezier(0.34,1.56,0.64,1);
}
.gpanel.shake-grid { animation: gridShake 0.4s cubic-bezier(.36,.07,.19,.97) both; animation-fill-mode: none; }
@keyframes gridShake { 0%,100%{translate:0 0} 20%{translate:-5px 3px} 40%{translate:5px -3px} 60%{translate:-4px 2px} 80%{translate:3px -2px} }

/* ── Void cell ── */
.cell-void { width: var(--cell); height: var(--cell); background: transparent; border: none; pointer-events: none; opacity: 0; }

/* ── Cells ── */
.cell {
  width: var(--cell); height: var(--cell); border-radius: var(--r);
  border: none; cursor: pointer; position: relative; overflow: hidden;
  display: flex; align-items: center; justify-content: center;
  transition: transform 0.08s cubic-bezier(0.4,0,0.2,1), box-shadow 0.1s;
  -webkit-tap-highlight-color: transparent;
}
.cell:active { transform: scale(0.9) !important; }
.cell.inactive { background: rgba(255,255,255,0.04); border: 2px solid rgba(255,255,255,0.07); cursor: default; }
.cell.inactive::before { display: none; }
.cell--press { transform: scale(0.88) !important; }

/* Cell glossy shine */
.cell::before {
  content: ''; position: absolute; inset: 0; border-radius: inherit;
  background: linear-gradient(145deg, rgba(255,255,255,0.25) 0%, transparent 55%);
  pointer-events: none; z-index: 1;
}

/* Cell inner content wrapper */
.cell > span:first-child { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; }

.sym { position: relative; z-index: 3; font-size: 22px; line-height: 1; filter: drop-shadow(0 1px 3px rgba(0,0,0,0.5)); }

/* Cell colors */
.cell { clip-path: none !important; }
.cell-tri-shape {
  position: absolute; inset: 0; border-radius: inherit;
  clip-path: polygon(50% 6%, 94% 92%, 6% 92%);
  pointer-events: none;
}
/* Triangle color overlays */
.cell.triangle-white .cell-tri-shape,
.cell.white.triangle .cell-tri-shape   { background: linear-gradient(145deg,#fff,#c7d2e8); }
.cell.triangle-blue .cell-tri-shape,
.cell.blue.triangle .cell-tri-shape    { background: linear-gradient(145deg,#60a5fa,#2563eb); }
.cell.triangle-red .cell-tri-shape,
.cell.red.triangle .cell-tri-shape     { background: linear-gradient(145deg,#f87171,#dc2626); }
.cell.triangle-orange .cell-tri-shape,
.cell.orange.triangle .cell-tri-shape  { background: linear-gradient(145deg,#fb923c,#ea580c); }
.cell.triangle-yellow .cell-tri-shape,
.cell.yellow.triangle .cell-tri-shape  { background: linear-gradient(145deg,#fde047,#ca8a04); }
.cell.triangle-green .cell-tri-shape,
.cell.green.triangle .cell-tri-shape   { background: linear-gradient(145deg,#4ade80,#16a34a); }
.cell.triangle-cyan .cell-tri-shape,
.cell.cyan.triangle .cell-tri-shape    { background: linear-gradient(145deg,#22d3ee,#0891b2); }
.cell.triangle-lime .cell-tri-shape,
.cell.lime.triangle .cell-tri-shape    { background: linear-gradient(145deg,#a3e635,#65a30d); }
.cell.triangle-teal .cell-tri-shape,
.cell.teal.triangle .cell-tri-shape    { background: linear-gradient(145deg,#2dd4bf,#0f766e); }
.cell.triangle-pink .cell-tri-shape,
.cell.pink.triangle .cell-tri-shape    { background: linear-gradient(145deg,#f472b6,#db2777); }
.cell.triangle-rose .cell-tri-shape,
.cell.rose.triangle .cell-tri-shape    { background: linear-gradient(145deg,#fb7185,#e11d48); }
.cell.triangle-magenta .cell-tri-shape,
.cell.magenta.triangle .cell-tri-shape { background: linear-gradient(145deg,#e879f9,#a21caf); }
.cell.triangle-purple .cell-tri-shape,
.cell.purple.triangle .cell-tri-shape  { background: linear-gradient(145deg,#d946ef,#7c3aed); }
.cell.white   { background: linear-gradient(145deg,#fff,#c7d2e8); box-shadow: 0 4px 0 #8fa0bb, 0 5px 14px rgba(200,210,230,0.4); }
.cell.blue    { background: linear-gradient(145deg,#60a5fa,#2563eb); box-shadow: 0 4px 0 #1e40af, 0 5px 14px rgba(59,130,246,0.5); }
.cell.red     { background: linear-gradient(145deg,#f87171,#dc2626); box-shadow: 0 4px 0 #991b1b, 0 5px 14px rgba(239,68,68,0.5); }
.cell.orange  { background: linear-gradient(145deg,#fb923c,#ea580c); box-shadow: 0 4px 0 #9a3412, 0 5px 14px rgba(249,115,22,0.5); }
.cell.yellow  { background: linear-gradient(145deg,#fde047,#ca8a04); box-shadow: 0 4px 0 #854d0e, 0 5px 14px rgba(234,179,8,0.5); }
.cell.green   { background: linear-gradient(145deg,#4ade80,#16a34a); box-shadow: 0 4px 0 #14532d, 0 5px 14px rgba(34,197,94,0.5); }
.cell.cyan    { background: linear-gradient(145deg,#22d3ee,#0891b2); box-shadow: 0 4px 0 #164e63, 0 5px 14px rgba(6,182,212,0.5); }
.cell.lime    { background: linear-gradient(145deg,#a3e635,#65a30d); box-shadow: 0 4px 0 #365314, 0 5px 14px rgba(132,204,22,0.5); }
.cell.teal    { background: linear-gradient(145deg,#2dd4bf,#0f766e); box-shadow: 0 4px 0 #134e4a, 0 5px 14px rgba(20,184,166,0.5); }
.cell.pink    { background: linear-gradient(145deg,#f472b6,#db2777); box-shadow: 0 4px 0 #831843, 0 5px 14px rgba(236,72,153,0.5); }
.cell.rose    { background: linear-gradient(145deg,#fb7185,#e11d48); box-shadow: 0 4px 0 #881337, 0 5px 14px rgba(244,63,94,0.5); }
.cell.magenta { background: linear-gradient(145deg,#e879f9,#a21caf); box-shadow: 0 4px 0 #701a75, 0 5px 14px rgba(217,70,239,0.5); }
.cell.purple  {
  background: linear-gradient(145deg,#d946ef,#7c3aed);
  box-shadow: 0 4px 0 #4c1d95, 0 5px 16px rgba(192,38,211,0.5);
  animation: purplePulse 1.5s ease-in-out infinite;
}
@keyframes purplePulse {
  0%,100% { box-shadow: 0 4px 0 #4c1d95, 0 5px 16px rgba(192,38,211,0.5); }
  50%      { box-shadow: 0 4px 0 #4c1d95, 0 5px 28px rgba(192,38,211,0.8), 0 0 0 3px rgba(192,38,211,0.2); }
}

/* Power-up cells */
.cell.medpack    { background: linear-gradient(145deg,#fcd34d,#d97706); box-shadow: 0 4px 0 #92400e, 0 5px 14px rgba(251,191,36,0.5); }
.cell.shield     { background: linear-gradient(145deg,#67e8f9,#0891b2); box-shadow: 0 4px 0 #164e63, 0 5px 14px rgba(6,182,212,0.5); }
.cell.freeze     { background: linear-gradient(145deg,#bfdbfe,#3b82f6); box-shadow: 0 4px 0 #1e3a8a, 0 5px 14px rgba(147,197,253,0.5); }
.cell.multiplier { background: linear-gradient(145deg,#fb923c,#ea580c); box-shadow: 0 4px 0 #9a3412, 0 5px 14px rgba(249,115,22,0.5); }

/* Ice, Hold, Slider cells */
.cell.ice {
  background: linear-gradient(145deg,#e0f2fe,#7dd3fc,#2563eb);
  box-shadow: 0 4px 0 #1e40af, 0 5px 14px rgba(96,165,250,0.6);
}
.cell.hold {
  background: radial-gradient(circle at 50% 35%, #ff6b6b, #cc0000);
  box-shadow: 0 5px 0 #7f0000, 0 6px 20px rgba(220,0,0,0.5);
}
/* ── Cell animations ── */
.cell.pop   { animation: pop   0.32s cubic-bezier(0.22,1,0.36,1) forwards; }
.cell.shake { animation: shake 0.42s cubic-bezier(0.36,0.07,0.19,0.97) forwards; }
@keyframes pop {
  0%   { transform: scale(1); opacity: 1; }
  40%  { transform: scale(1.3) rotate(var(--tilt,0deg)); }
  70%  { transform: scale(0.85) rotate(calc(var(--tilt,0deg)*-0.5)); opacity: 0.7; }
  100% { transform: scale(0) rotate(var(--tilt,0deg)); opacity: 0; }
}
@keyframes shake {
  0%,100% { transform: translateX(0) rotate(0deg); }
  20%     { transform: translateX(-10px) rotate(-1.5deg); }
  35%     { transform: translateX(9px)  rotate(1deg); }
  50%     { transform: translateX(-7px) rotate(-0.8deg); }
  65%     { transform: translateX(5px)  rotate(0.5deg); }
  80%     { transform: translateX(-3px) rotate(-0.3deg); }
}
@keyframes newcell { from { transform: scale(0); opacity: 0; } to { transform: scale(1); opacity: 1; } }
.cell.newcell { animation: newcell 0.3s cubic-bezier(0.22,1,0.36,1); }

/* ── Ripple ── */
.ripple {
  position: absolute; width: 8px; height: 8px; border-radius: 50%;
  background: rgba(255,255,255,0.65); transform: translate(-50%,-50%) scale(0);
  animation: rippleAnim 0.5s ease-out forwards; pointer-events: none; z-index: 10;
}
@keyframes rippleAnim { to { transform: translate(-50%,-50%) scale(6); opacity: 0; } }

/* ── Shard ── */
.shard {
  position: absolute; width: 6px; height: 6px; border-radius: 2px;
  animation: shardFly 0.42s cubic-bezier(0.22,1,0.36,1) forwards;
  pointer-events: none; z-index: 20;
}
@keyframes shardFly {
  0%   { transform: translate(0,0) rotate(0deg) scale(1); opacity: 1; }
  100% { transform: translate(var(--dx,20px),var(--dy,-20px)) rotate(var(--dr,180deg)) scale(0); opacity: 0; }
}

/* ── Ice overlay ── */
.cell-overlay-ice {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  font-family: var(--font-game); font-size: 16px; color: #fff; z-index: 4;
  text-shadow: 0 2px 4px rgba(0,0,0,0.5); pointer-events: none; letter-spacing: -1px;
}

/* ── Hold button design ── */
.cell-overlay-hold {
  position: absolute; inset: 0; display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 2px; z-index: 4; pointer-events: none;
}
.hold-btn-outer {
  width: 78%; aspect-ratio: 1; border-radius: 50%;
  background: radial-gradient(circle at 40% 30%, #ff9999, #cc0000);
  border: 3px solid rgba(255,150,150,0.5);
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 0 #7f0000, 0 0 12px rgba(255,0,0,0.4), inset 0 2px 4px rgba(255,200,200,0.3);
  transition: transform 0.1s, box-shadow 0.1s;
}
.hold-btn-inner {
  width: 72%; aspect-ratio: 1; border-radius: 50%;
  background: radial-gradient(circle at 40% 30%, #ff4444, #990000);
  border: 2px solid rgba(255,100,100,0.4);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-game); font-size: 10px; color: #ffcccc;
  letter-spacing: 0.3px; text-shadow: 0 1px 2px rgba(0,0,0,0.6);
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.3);
}
.hold-btn-pressed .hold-btn-outer { transform: scaleY(0.88); box-shadow: 0 2px 0 #7f0000, 0 0 18px rgba(255,50,50,0.6); }
.hold-btn-pressed .hold-btn-inner { font-size: 12px; color: #fff; }
.hold-progress {
  position: absolute; bottom: 5px; left: 6px; right: 6px; height: 3px; border-radius: 99px;
  background: rgba(255,255,255,0.25);
}
.hold-progress::after {
  content: ''; position: absolute; inset: 0; border-radius: 99px;
  background: linear-gradient(90deg, #ff6b6b, #fff);
  width: inherit; transition: width 0.05s linear;
}

/* ── Stage badge (removed per item 14, but kept for potential future use) ── */
.stage-badge { display: none; }

/* ── Share card ── */
.share-card { width: 100%; display: flex; flex-direction: column; align-items: center; gap: 12px; }
.share-inner {
  width: 100%;
  background: linear-gradient(135deg, rgba(192,38,211,0.12), rgba(59,130,246,0.08));
  border: 2px solid rgba(192,38,211,0.2); border-radius: 18px; padding: 18px;
  display: flex; flex-direction: column; align-items: center; gap: 4px;
}
.share-logo { font-family: var(--font-game); font-size: 11px; color: var(--muted); }
.share-score {
  font-family: var(--font-game); font-size: 52px; font-weight: 900; line-height: 1; letter-spacing: -2px;
  background: linear-gradient(135deg,#fff,#f0abfc,#c026d3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
}
.share-mode { font-family: var(--font-ui); font-size: 10px; font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; color: var(--purple); }
.share-invite { font-family: var(--font-game); font-size: 14px; color: var(--text); margin-top: 2px; }
.share-url { font-size: 10px; color: var(--muted); margin-top: 3px; }
.share-btns { display: flex; gap: 7px; width: 100%; flex-wrap: wrap; }
.share-social {
  flex: 1; min-width: 80px; display: flex; align-items: center; justify-content: center; gap: 5px;
  padding: 10px 6px; border-radius: 12px; font-family: var(--font-ui); font-size: 12px; font-weight: 800;
  cursor: pointer; border: none; text-decoration: none; transition: all 0.15s;
}
.share-social-icon { font-size: 13px; }
.share-social--x   { background: #000; color: #fff; }
.share-social--wa  { background: #25d366; color: #fff; }
.share-social--copy { background: var(--bg2); color: var(--text); border: 2px solid var(--glass-border); }
.share-social:hover { transform: translateY(-1px); }

/* ── Powerup zone — fixed height slot between top UI and grid ── */
.pwr-zone {
  width: 100%; min-height: 40px; display: flex; align-items: center;
  justify-content: center; gap: 6px; flex-wrap: wrap;
}
.pwr-zone--1p { margin-bottom: 2px; }

/* ── 2P phud score row with inline combo ── */
.phud-score-row { display: flex; align-items: center; gap: 6px; }
.combo-wrap--sm { font-size: 10px; padding: 1px 6px; }

/* ── Pause settings row ── */
.pause-settings-row {
  display: flex; gap: 8px; width: 100%; justify-content: center;
}
.pause-setting-btn {
  flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px;
  background: rgba(255,255,255,0.07); border: 2px solid rgba(255,255,255,0.12);
  border-radius: 14px; padding: 10px 8px; cursor: pointer; color: var(--text);
  font-family: var(--font-ui); font-size: 11px; font-weight: 800;
  transition: all 0.15s;
}
.pause-setting-btn:hover { background: rgba(192,38,211,0.18); border-color: rgba(192,38,211,0.4); transform: translateY(-2px); }
.pause-setting-btn > span { color: var(--muted); font-size: 10px; }

/* ── Keyboard cell vibrancy ── */
.kb-cell {
  padding: 10px 4px; background: var(--bg2); border: 2px solid var(--glass-border);
  border-radius: 9px; color: var(--text); font-family: var(--font-ui); font-size: 13px;
  font-weight: 800; cursor: pointer; transition: all 0.15s; text-align: center;
}
.kb-cell:not(.kb-cell--on):not(.kb-cell--empty) {
  background: linear-gradient(145deg, rgba(140,90,210,0.18), rgba(80,40,160,0.1));
  border-color: rgba(192,38,211,0.28);
  color: var(--text);
  box-shadow: 0 2px 0 rgba(0,0,0,0.3);
}
.kb-cell:not(.kb-cell--on):hover {
  background: linear-gradient(145deg, rgba(192,38,211,0.3), rgba(124,58,237,0.2));
  border-color: rgba(192,38,211,0.55);
  transform: translateY(-1px);
}
.kb-cell--on { background: linear-gradient(135deg, #a21caf, #c026d3); color: #fff; border-color: var(--purple); box-shadow: 0 3px 0 var(--purple-dark), 0 4px 12px rgba(192,38,211,0.4); }
.kb-cell--empty { color: var(--muted); opacity: 0.5; }

/* ── Hover gradient animations on UI cells/cards ── */
.hud-card, .menu-card, .btn-ghost, .btn-primary, .pill-opt, .opt-btn, .lb-row, .how-row {
  position: relative; overflow: hidden;
}
.hud-card::after, .menu-card::after {
  content: ''; position: absolute; inset: 0; border-radius: inherit;
  background: radial-gradient(circle at var(--mx,50%) var(--my,50%), rgba(192,38,211,0.12) 0%, transparent 60%);
  opacity: 0; transition: opacity 0.3s; pointer-events: none; z-index: 0;
}
.hud-card:hover::after, .menu-card:hover::after { opacity: 1; }

/* Cell hover — gradient shimmer */
.cell:not(.inactive):hover {
  filter: brightness(1.18) saturate(1.15);
  transform: scale(1.04) !important;
  transition: transform 0.1s, filter 0.1s, box-shadow 0.1s !important;
}

/* Btn-ghost hover gradient shift */
.btn-ghost::after {
  content: ''; position: absolute; inset: 0; border-radius: inherit;
  background: linear-gradient(135deg, rgba(192,38,211,0.12), rgba(124,58,237,0.08));
  opacity: 0; transition: opacity 0.2s; pointer-events: none;
}
.btn-ghost:hover::after { opacity: 1; }

/* Pill option hover */
.pill-opt:not(.pill-opt--on):hover {
  color: var(--text);
  background: rgba(192,38,211,0.12);
}

/* LB row hover */
.lb-row { transition: transform 0.15s, box-shadow 0.15s, border-color 0.15s; }
.lb-row:hover { transform: translateX(3px); border-color: rgba(192,38,211,0.3); box-shadow: 0 4px 14px rgba(192,38,211,0.12); }

/* Btn-icon hover */
.btn-icon:hover {
  background: rgba(192,38,211,0.2) !important;
  border-color: rgba(192,38,211,0.45) !important;
  transform: scale(1.08);
}
.btn-icon--pause:hover {
  background: rgba(192,38,211,0.28) !important;
  box-shadow: 0 0 12px rgba(192,38,211,0.35);
}

/* ── Key badge ── */
.kbadge { position: absolute; bottom: 3px; right: 3px; font-size: 7px; font-weight: 900; background: rgba(0,0,0,0.4); color: #fff; padding: 1px 3px; border-radius: 4px; z-index: 5; letter-spacing: 0.5px; }

/* ── Screen slide ── */
.screen-slide { animation: screenSlide 0.3s cubic-bezier(0.22,1,0.36,1); }
@keyframes screenSlide { from { opacity:0; transform:translateX(18px); } }

/* ── Leaderboard ── */
.lb-wrap { width: 100%; display: flex; flex-direction: column; gap: 14px; }
.lb-header { display: flex; align-items: baseline; gap: 10px; }
.lb-title { font-family: var(--font-game); font-size: 22px; }
.lb-sub { font-family: var(--font-ui); font-size: 11px; color: var(--muted); font-weight: 700; }
.lb-empty { font-family: var(--font-ui); font-size: 14px; color: var(--muted); text-align: center; padding: 22px 0; }
.lb-list { display: flex; flex-direction: column; gap: 6px; }
.lb-row { display: flex; align-items: center; gap: 10px; padding: 10px 14px; background: var(--bg2); border: 2px solid var(--glass-border); border-radius: 14px; }
.lb-row--gold   { border-color: rgba(250,204,21,0.4); background: rgba(250,204,21,0.06); }
.lb-row--silver { border-color: rgba(148,163,184,0.3); }
.lb-row--bronze { border-color: rgba(180,120,60,0.3); }
.lb-rank { font-size: 16px; width: 22px; text-align: center; }
.lb-ini  { font-family: var(--font-game); font-size: 15px; flex: 1; }
.lb-score { font-family: var(--font-game); font-size: 18px; color: var(--purple); }
.lb-date  { font-family: var(--font-ui); font-size: 10px; color: var(--muted); }

/* ── How to play ── */
.how-wrap { width: 100%; display: flex; flex-direction: column; gap: 14px; }
.how-title { font-family: var(--font-game); font-size: 22px; }
.how-grid { display: flex; flex-direction: column; gap: 8px; }
.how-row { display: flex; align-items: flex-start; gap: 10px; padding: 10px 14px; background: var(--bg2); border: 2px solid var(--glass-border); border-radius: 14px; }
.how-icon { font-size: 20px; flex-shrink: 0; }
.how-modes { display: flex; flex-direction: column; gap: 5px; }
.how-mode { font-family: var(--font-ui); font-size: 13px; color: var(--muted); }
.how-tip { font-family: var(--font-ui); font-size: 12px; color: var(--muted); background: var(--bg2); border-radius: 10px; padding: 8px 12px; }

/* ── Key binder ── */
.kb-overlay { position: fixed; inset: 0; z-index: 600; background: rgba(0,0,0,0.55); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; padding: 20px; }
.kb-panel { background: #0d0820; border: 2px solid rgba(192,38,211,0.3); border-radius: 22px; padding: 22px; width: 100%; max-width: 350px; display: flex; flex-direction: column; gap: 14px; }
.light-theme .kb-panel { background: #f0e8ff; }
.kb-title { font-family: var(--font-game); font-size: 18px; }
.kb-hint { font-family: var(--font-ui); font-size: 12px; color: var(--muted); }
.kb-tabs { display: flex; gap: 7px; }
.kb-tab { flex: 1; padding: 8px; background: var(--bg2); border: 2px solid var(--glass-border); border-radius: 10px; color: var(--muted); font-family: var(--font-ui); font-weight: 800; cursor: pointer; transition: all 0.15s; }
.kb-tab--on { background: var(--purple); color: #fff; border-color: var(--purple); }
.kb-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 5px; }
.kb-footer { display: flex; justify-content: space-between; align-items: center; }

/* ── Credit footer ── */
.credit { position: fixed; bottom: 8px; left: 0; right: 0; display: flex; align-items: center; justify-content: center; font-family: var(--font-ui); font-size: 10px; color: var(--muted); opacity: 0.45; flex-wrap: wrap; pointer-events: none; gap: 4px; }
.credit-link { color: var(--muted); text-decoration: none; pointer-events: all; transition: opacity 0.15s; }
.credit-link:hover { opacity: 1; }

/* ── Privacy ── */
.privacy-link { color: var(--muted); text-decoration: none; font-size: 10px; }

/* ── Overlay glass ── */
.overlay { position: fixed; inset: 0; z-index: 100; background: rgba(0,0,0,0.5); backdrop-filter: blur(12px); display: flex; align-items: center; justify-content: center; padding: 20px; }
.glass-panel { background: #0d0820; border: 2px solid rgba(192,38,211,0.25); border-radius: 26px; padding: 26px; width: 100%; max-width: 380px; box-shadow: 0 32px 64px rgba(0,0,0,0.4); }
.light-theme .glass-panel { background: #f0e8ff; }

/* ── Grid rotation wrapper ── */
.gpanel-wrap {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.35s cubic-bezier(0.34,1.56,0.64,1);
}

/* ── Rotation direction arrows — UNO-card style, only flash on direction change ── */
.rot-arrows-container {
  position: absolute;
  inset: -60px;
  pointer-events: none;
  z-index: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.rot-arrow {
  position: absolute;
  opacity: 0;
  pointer-events: none;
}
.rot-arrow--cw {
  width: clamp(160px, 55vw, 280px);
  height: clamp(160px, 55vw, 280px);
  color: rgba(192,38,211,0.9);
  filter: drop-shadow(0 0 20px rgba(192,38,211,0.7));
}
.rot-arrow--ccw {
  width: clamp(160px, 55vw, 280px);
  height: clamp(160px, 55vw, 280px);
  color: rgba(96,165,250,0.9);
  filter: drop-shadow(0 0 20px rgba(96,165,250,0.7));
}
.rot-arrow--active {
  animation: unoArrowFlash 2.4s cubic-bezier(0.22,1,0.36,1) forwards;
}
.rot-arrow--cw.rot-arrow--active {
  animation: unoArrowFlashCW 2.4s cubic-bezier(0.22,1,0.36,1) forwards;
}
.rot-arrow--ccw.rot-arrow--active {
  animation: unoArrowFlashCCW 2.4s cubic-bezier(0.22,1,0.36,1) forwards;
}
@keyframes unoArrowFlashCW {
  0%   { opacity: 0;    transform: scale(0.5) rotate(-30deg); }
  15%  { opacity: 0.75; transform: scale(1.12) rotate(8deg); }
  35%  { opacity: 0.55; transform: scale(1.0)  rotate(0deg); }
  60%  { opacity: 0.45; transform: scale(1.0)  rotate(0deg); }
  80%  { opacity: 0.25; transform: scale(1.0)  rotate(0deg); }
  100% { opacity: 0;    transform: scale(0.9)  rotate(-5deg); }
}
@keyframes unoArrowFlashCCW {
  0%   { opacity: 0;    transform: scale(0.5) rotate(30deg); }
  15%  { opacity: 0.75; transform: scale(1.12) rotate(-8deg); }
  35%  { opacity: 0.55; transform: scale(1.0)  rotate(0deg); }
  60%  { opacity: 0.45; transform: scale(1.0)  rotate(0deg); }
  80%  { opacity: 0.25; transform: scale(1.0)  rotate(0deg); }
  100% { opacity: 0;    transform: scale(0.9)  rotate(5deg); }
}

/* ── Continuous grid spin (CSS-only, duration set via inline style) ── */
@keyframes gpanelSpinContinuousCW  { to { transform: rotate(360deg);  } }
@keyframes gpanelSpinContinuousCCW { to { transform: rotate(-360deg); } }

/* ── Grid entry animations (one-shot, triggered on grid change) ── */
.gpanel--spin-cw    { animation: gpanelEntryCW    0.55s cubic-bezier(0.22,1,0.36,1); }
.gpanel--spin-ccw   { animation: gpanelEntryCCW   0.55s cubic-bezier(0.22,1,0.36,1); }
.gpanel--spin-jiggle{ animation: gpanelJiggle     0.55s cubic-bezier(0.22,1,0.36,1); }
@keyframes gpanelEntryCW   { 0%{transform:scale(0.82) rotate(-90deg);opacity:0.3} 60%{transform:scale(1.03) rotate(4deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
@keyframes gpanelEntryCCW  { 0%{transform:scale(0.82) rotate(90deg);opacity:0.3}  60%{transform:scale(1.03) rotate(-4deg);opacity:1} 100%{transform:scale(1) rotate(0deg);opacity:1} }
@keyframes gpanelJiggle    { 0%{transform:scale(0.86) rotate(-8deg);opacity:0.4} 20%{transform:scale(1.06) rotate(6deg);opacity:1} 40%{transform:scale(0.97) rotate(-3deg)} 60%{transform:scale(1.02) rotate(2deg)} 80%{transform:scale(0.99) rotate(-1deg)} 100%{transform:scale(1) rotate(0deg)} }

/* Cell counter-spin at high evolve stages */
@keyframes cellCounterSpin { to { transform: rotate(-360deg); } }

/* ── Duo mode: wide spacing so fingers don't overlap ── */
.root--2p .game-area {
  align-items: center;
  justify-content: space-around;
  gap: 0;
  padding: 8px 4px;
}
.root--2p .ppanel {
  flex: 1;
  align-items: center;
}

/* On narrow/phone screens: stack vertically with generous gap */
@media (max-width: 600px) {
  .root--2p .game-area {
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
    gap: 0;
    padding: 4px 0 16px;
  }
  .root--2p .ppanel {
    width: 100%;
    max-width: 300px;
  }
  .root--2p {
    --cell: clamp(48px, 13vw, 66px);
  }
}

/* On wider screens keep side-by-side with max separation */
@media (min-width: 601px) {
  .root--2p { max-width: 740px; }
  .root--2p .game-area { gap: 24px; }
}

/* ── Screen transitions ── */
* { transition: background-color 0.4s ease, border-color 0.3s ease, color 0.3s ease; }
.root, .menu-card, .hud-card, .gpanel, .ppanel { transition: all 0.35s cubic-bezier(0.34,1.56,0.64,1); }

/* ── Loading screen ── */
.loading-screen {
  position: fixed; inset: 0; z-index: 9999;
  width: 100vw; height: 100dvh;
  background: linear-gradient(145deg, #0d0820, #1a0a3e);
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 20px;
  transition: opacity 0.6s ease, transform 0.6s ease;
  text-align: center;
}
.loading-screen--out { opacity: 0; transform: scale(1.05); pointer-events: none; }
.loading-logo { font-family: 'Fredoka One', system-ui, sans-serif; font-size: clamp(26px,8vw,44px); color: #f0eaff; text-align: center; letter-spacing: 0.5px; }
.loading-purple { color: #c026d3; text-shadow: 0 0 24px rgba(192,38,211,0.7); }
.loading-sub { font-family: 'Nunito', system-ui, sans-serif; font-size: 13px; color: rgba(240,234,255,0.45); font-weight: 700; letter-spacing: 0.3px; }
.loading-bar-track { width: min(280px, 80vw); height: 10px; background: rgba(255,255,255,0.07); border-radius: 99px; overflow: hidden; border: 1px solid rgba(192,38,211,0.25); }
.loading-bar-fill { height: 100%; border-radius: 99px; background: linear-gradient(90deg, #7c3aed, #c026d3, #f0abfc); transition: width 0.25s ease; box-shadow: 0 0 14px rgba(192,38,211,0.6); }
.loading-pct { font-family: 'Fredoka One', system-ui, sans-serif; font-size: 13px; color: rgba(192,38,211,0.65); }

/* ── Dev overlay ── */
.dev-overlay { position: fixed; inset: 0; z-index: 9000; background: rgba(0,0,0,0.65); backdrop-filter: blur(4px); display: flex; align-items: stretch; justify-content: flex-end; }
.dev-panel { width: min(340px,95vw); height: 100%; overflow-y: auto; background: #050212; border-left: 1px solid rgba(192,38,211,0.3); padding: 16px; display: flex; flex-direction: column; gap: 3px; }
.dev-title { font-family: monospace; font-size: 11px; font-weight: 900; color: #f0abfc; margin-bottom: 8px; border-bottom: 1px solid rgba(192,38,211,0.2); padding-bottom: 6px; }
.dev-section { font-family: monospace; font-size: 9px; font-weight: 900; color: rgba(192,38,211,0.7); letter-spacing: 1.5px; text-transform: uppercase; margin-top: 8px; margin-bottom: 2px; }
.dev-row { display: flex; justify-content: space-between; gap: 8px; font-family: monospace; font-size: 10px; color: #c0b8e0; padding: 1px 0; }
.dev-key { color: rgba(192,200,255,0.55); flex-shrink: 0; }
.dev-val { color: #88f0a0; word-break: break-all; text-align: right; }
.dev-btn { display: inline-block; background: rgba(192,38,211,0.12); border: 1px solid rgba(192,38,211,0.28); border-radius: 4px; padding: 2px 7px; margin: 2px; cursor: pointer; transition: background 0.12s; font-family: monospace; font-size: 10px; color: #c0b8e0; }
.dev-btn:hover { background: rgba(192,38,211,0.32); color: #fff; }

/* ── Dust widget ── */
.dust-widget { display:flex; align-items:center; gap:4px; background:rgba(192,38,211,0.12); border:1px solid rgba(192,38,211,0.25); border-radius:99px; padding:3px 10px; font-family:var(--font-ui); font-size:13px; font-weight:800; color:var(--accent); cursor:default; }
.dust-icon { font-size:14px; }
.dust-val { letter-spacing:0.3px; }

/* ── Energy bar ── */
.energy-bar-wrap { display:flex; flex-direction:column; align-items:center; gap:4px; margin-bottom:8px; }
.energy-pips { display:flex; gap:4px; }
.energy-pip { font-size:18px; opacity:0.2; transition:opacity 0.25s; filter:grayscale(1); }
.energy-pip--full { opacity:1; filter:none; }
.energy-regen-row { display:flex; align-items:center; gap:8px; }
.energy-timer { font-family:var(--font-ui); font-size:11px; color:var(--muted); }
.energy-refill-btn { background:rgba(192,38,211,0.12); border:1px solid rgba(192,38,211,0.28); border-radius:99px; padding:2px 10px; font-family:var(--font-ui); font-size:11px; font-weight:800; color:var(--accent); cursor:pointer; transition:background 0.15s; }
.energy-refill-btn:hover { background:rgba(192,38,211,0.28); }

/* ── No energy block ── */
.no-energy-block { display:flex; flex-direction:column; align-items:center; gap:4px; padding:14px; background:rgba(255,255,255,0.04); border:1px dashed rgba(192,38,211,0.2); border-radius:16px; margin:4px 0; }
.no-energy-txt { font-family:var(--font-ui); font-size:15px; font-weight:800; color:var(--muted); }
.no-energy-timer { font-family:var(--font-ui); font-size:22px; font-weight:900; color:var(--accent); letter-spacing:1px; }

/* ── Player name row ── */
.player-name-row { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:6px; padding:6px 12px; background:rgba(255,255,255,0.04); border-radius:12px; }
.player-name-lbl { font-family:var(--font-ui); font-size:13px; font-weight:800; color:var(--text); }

/* ── Shop ── */
.shop-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; }
.shop-item { background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); border-radius:14px; padding:12px; display:flex; flex-direction:column; align-items:center; gap:6px; transition:border-color 0.2s; }
.shop-item--equipped { border-color:var(--theme-purple,var(--purple)); background:rgba(192,38,211,0.1); }
.shop-swatch { width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; border:1px solid rgba(255,255,255,0.1); }
.shop-name { font-family:var(--font-ui); font-size:13px; font-weight:800; color:var(--text); }

/* ── Loading orbs ── */
.loading-orb { position:absolute; border-radius:50%; filter:blur(60px); pointer-events:none; }
.loading-orb-1 { width:280px; height:280px; background:rgba(192,38,211,0.25); top:-60px; left:-80px; animation:orbFloat 7s ease-in-out infinite; }
.loading-orb-2 { width:200px; height:200px; background:rgba(124,58,237,0.2); bottom:-40px; right:-60px; animation:orbFloat 9s ease-in-out infinite reverse; }
.loading-orb-3 { width:140px; height:140px; background:rgba(240,171,252,0.15); top:50%; left:50%; transform:translate(-50%,-50%); animation:orbFloat 5s ease-in-out infinite; }

/* ── Loading name entry ── */
.loading-name-entry { display:flex; flex-direction:column; align-items:center; gap:10px; margin-top:8px; }
.loading-name-label { font-family:var(--font-ui); font-size:14px; font-weight:800; color:rgba(240,234,255,0.7); }
.loading-name-row { display:flex; gap:8px; align-items:center; }

/* ── Leaderboard mode chip ── */
.lb-mode-chip { flex-shrink:0; }

/* ── Game over dust earned ── */
.go-dust-earned { font-family:var(--font-ui); font-size:14px; font-weight:800; color:var(--accent); background:rgba(192,38,211,0.12); border:1px solid rgba(192,38,211,0.2); border-radius:99px; padding:4px 14px; margin:4px 0; }

.shop-tabs { display:flex; gap:6px; margin-bottom:12px; }
.shop-tab { flex:1; padding:8px; border-radius:12px; border:1px solid rgba(255,255,255,0.1); background:rgba(255,255,255,0.05); font-family:var(--font-ui); font-size:13px; font-weight:800; color:var(--muted); cursor:pointer; transition:all 0.15s; }
.shop-tab--on { background:rgba(192,38,211,0.2); border-color:rgba(192,38,211,0.4); color:var(--text); }
.shop-hint { font-size:11px; color:var(--muted); margin-bottom:10px; font-family:var(--font-ui); }
.shop-inventory { display:flex; align-items:center; gap:8px; padding:8px 12px; background:rgba(192,38,211,0.1); border-radius:10px; margin-bottom:10px; }
.shop-inv-lbl { font-size:11px; color:var(--muted); font-family:var(--font-ui); }
.shop-inv-chip { font-size:13px; font-weight:800; font-family:var(--font-ui); color:var(--accent); background:rgba(192,38,211,0.15); padding:2px 8px; border-radius:99px; }
.shop-pwr-list { display:flex; flex-direction:column; gap:8px; }
.shop-pwr-item { display:flex; align-items:center; gap:10px; padding:10px 12px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:14px; }
.shop-pwr-icon { font-size:20px; min-width:36px; text-align:center; }
.shop-pwr-info { flex:1; }
.shop-pwr-name { font-family:var(--font-ui); font-size:13px; font-weight:800; color:var(--text); }
.shop-pwr-desc { font-family:var(--font-ui); font-size:11px; color:var(--muted); }
.shop-item--bought { animation: shopBought 0.5s ease; }
@keyframes shopBought { 0%{transform:scale(1)} 50%{transform:scale(1.06)} 100%{transform:scale(1)} }
.stored-pwr-btns { display:flex; gap:6px; justify-content:center; margin-top:4px; }
.stored-pwr-btn { border-radius:99px; border:none; padding:5px 14px; font-family:var(--font-ui); font-size:13px; font-weight:900; cursor:pointer; transition:transform 0.1s, box-shadow 0.1s; }
.stored-pwr-btn:active { transform:scale(0.94); }
.stored-pwr-btn--freeze { background:linear-gradient(135deg,#1d4ed8,#60a5fa); color:#fff; box-shadow:0 4px 14px rgba(96,165,250,0.4); }
.stored-pwr-btn--shield { background:linear-gradient(135deg,#0e7490,#22d3ee); color:#fff; box-shadow:0 4px 14px rgba(34,211,238,0.4); }
`;ed.createRoot(document.getElementById("root")).render(p.jsx(C_.StrictMode,{children:p.jsx($k,{})}));
